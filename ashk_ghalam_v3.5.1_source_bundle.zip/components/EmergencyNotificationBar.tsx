import React, { useState, useEffect } from 'react';
import { AppView, EmergencyBannerConfig } from '../types';
import { AlertOctagon, Megaphone, X, ExternalLink, Cpu, ShieldCheck } from 'lucide-react';

interface EmergencyNotificationBarProps {
  currentView: AppView;
  config?: EmergencyBannerConfig;
  onNavigate?: (view: AppView) => void;
}

export const EmergencyNotificationBar: React.FC<EmergencyNotificationBarProps> = ({
  currentView,
  config = {
    enabled: true,
    message: 'واحد فناوری اطلاعات اشک قلم: کلیه موتورهای طراحی جعبه، کاتالوگ و ابزارهای تحلیلی بدون قطعی و کاملاً آفلاین دردسترس می‌باشند.',
    targetView: 'ALL',
    linkText: 'کاتالوگ نرم‌افزارها',
    linkUrl: '',
    urgency: 'critical',
    dismissible: true
  },
  onNavigate
}) => {
  const [isDismissed, setIsDismissed] = useState<boolean>(() => {
    try {
      const savedDismissed = localStorage.getItem('ashk_emergency_dismissed_msg');
      return savedDismissed === config.message;
    } catch (_) {
      return false;
    }
  });

  if (!config || !config.enabled || isDismissed) {
    return null;
  }

  // Check target view filter
  const shouldDisplay = config.targetView === 'ALL' || config.targetView === currentView;
  if (!shouldDisplay) {
    return null;
  }

  const handleDismiss = () => {
    setIsDismissed(true);
    try {
      localStorage.setItem('ashk_emergency_dismissed_msg', config.message);
    } catch (_) {}
  };

  const handleAction = () => {
    if (config.linkUrl && config.linkUrl.startsWith('http')) {
      window.open(config.linkUrl, '_blank');
    } else if (onNavigate) {
      onNavigate(AppView.SOFTWARE_STORE);
    }
  };

  const isItMessage = config.message?.includes('IT') || config.message?.includes('فناوری') || config.message?.includes('نرم‌افزار');

  return (
    <div className={`${isItMessage ? 'bg-gradient-to-r from-slate-900 via-indigo-900 to-slate-950 border-b border-indigo-500/40 text-indigo-100' : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white border-b border-red-500/40'} py-2.5 px-4 text-xs sm:text-sm font-medium shadow-lg relative z-50 flex items-center justify-between gap-3 animate-in slide-in-from-top duration-300 font-sans dir-rtl`}>
      <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className={`flex-shrink-0 ${isItMessage ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-400/30' : 'bg-white/20 text-white'} p-1.5 rounded-xl backdrop-blur-sm`}>
            {isItMessage ? <Cpu className="w-4 h-4 animate-pulse" /> : <AlertOctagon className="w-4 h-4" />}
          </span>
          {isItMessage && (
            <span className="bg-indigo-500/30 text-indigo-200 text-[10px] font-black px-2 py-0.5 rounded-full border border-indigo-400/30 hidden sm:inline-block">
              واحد IT اشک قلم
            </span>
          )}
          <span className="font-extrabold tracking-tight leading-snug">
            {config.message}
          </span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto flex-shrink-0">
          {config.linkText && (
            <button
              onClick={handleAction}
              className={`${isItMessage ? 'bg-indigo-500 hover:bg-indigo-400 text-white border-indigo-400/40' : 'bg-white text-red-700 hover:bg-red-50 border-white/50'} px-3 py-1 rounded-xl font-black text-xs shadow-sm transition-all active:scale-95 flex items-center gap-1.5 border cursor-pointer`}
            >
              <span>{config.linkText}</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}

          {config.dismissible !== false && (
            <button
              onClick={handleDismiss}
              className="text-white/80 hover:text-white hover:bg-white/10 p-1 rounded-md transition-colors cursor-pointer"
              title="بستن اعلان"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

