import{c as s,j as e,C as a,ay as t,l}from"./index-BozimEE4.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],r=s("shield",c);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]],x=s("user-plus",n),i=()=>e.jsxs(a,{className:"p-6",children:[e.jsxs("div",{className:"flex items-center justify-between mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2.5 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20",children:e.jsx(t,{className:"w-5 h-5"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-base font-bold text-slate-100",children:"مدیریت تیم و دسترسی‌ها"}),e.jsx("p",{className:"text-xs text-slate-400",children:"تنظیم سطوح دسترسی اپراتور لیتوگرافی، حسابداری و مدیران"})]})]}),e.jsxs(l,{variant:"primary",size:"sm",children:[e.jsx(x,{className:"w-3.5 h-3.5 ml-1.5"}),"افزودن کاربر"]})]}),e.jsx("div",{className:"space-y-2 pt-2 border-t border-slate-800",children:e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-slate-800/40 text-xs",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(r,{className:"w-4 h-4 text-amber-400"}),e.jsx("span",{className:"font-bold text-slate-200",children:"مدیر سیستم (Admin)"})]}),e.jsx("span",{className:"text-emerald-400 font-bold",children:"دسترسی کامل"})]})})]});export{i as TeamManagementPanel};
