const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-BozimEE4.js","assets/index-CrvTMhWh.css","assets/ImageUploaderPanel-Bby3BNR_.js","assets/AdminTools-5jYlBqHF.js","assets/impositionService-CUAmo866.js","assets/NumericFormatInput-BcD03XjS.js","assets/server-nEF_YqCw.js","assets/terminal-D8TQRvGJ.js","assets/refresh-cw-BhN1xve2.js","assets/copy-D5FbLNQ4.js","assets/file-text-Cr_SYn3S.js","assets/upload-DxmUW0NB.js","assets/plus-gsCymyjX.js","assets/rotate-cw-BMr9-ENg.js","assets/save-DkASyjMq.js","assets/CoverDesignerPanel-nJdVsm5c.js","assets/eye-off-DH826gRL.js","assets/AdminPanel-D4fn15LQ.js","assets/sliders-vertical-G0eETqxB.js","assets/monitor-C5FmLi-g.js","assets/share-2-CIJfFUKU.js","assets/WebOptimizerPanel-_dBI82sg.js","assets/WordpressExportPanel-DYvgqSzy.js","assets/file-code-corner-BDyiPoq9.js","assets/external-link-CpnX-DjR.js"])))=>i.map(i=>d[i]);
import{c as Et,aU as Pt,r,aV as pe,aW as Lt,aX as Ve,aY as $t,aZ as zt,a_ as Dt,a$ as _t,j as e,ag as Oe,Y as Be,as as F,aw as Tt,E as ee,am as At,an as Mt,p as U,ab as Rt,ac as Ot,S as Bt,ar as xe,q as Ft,L as Ut,aE as P,R as Vt,az as Wt}from"./index-BozimEE4.js";import{E as Ht}from"./eye-off-DH826gRL.js";import{S as qt}from"./save-DkASyjMq.js";import{P as We}from"./AdminPanel-D4fn15LQ.js";import{S as Xt}from"./sliders-vertical-G0eETqxB.js";import{R as Yt}from"./refresh-cw-BhN1xve2.js";import{P as Qt}from"./plus-gsCymyjX.js";import{C as Gt}from"./copy-D5FbLNQ4.js";import{S as Jt}from"./share-2-CIJfFUKU.js";import{T as Zt}from"./upload-DxmUW0NB.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=[["path",{d:"M12 10v6",key:"1bos4e"}],["path",{d:"M9 13h6",key:"1uhe8q"}],["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]],Fe=Et("folder-plus",Kt),ya=[{id:"editorial-minimal",name:"گالری مینیمال",description:"ساده، مدرن و متمرکز بر تایپوگرافی و کادر خطی",primaryColor:"#fafaf9",accentColor:"#b45309",textColor:"#1c1917"},{id:"luxury-foil",name:"لوکس طلاکوب",description:"پس‌زمینه تیره با قاب و خطوط طلایی سلطنتی",primaryColor:"#111827",accentColor:"#d4af37",textColor:"#f9fafb"},{id:"modern-grid",name:"صنعتی مدرن",description:"ساختار مهندسی با نوار رنگی و تیتر جسورانه",primaryColor:"#0f172a",accentColor:"#0ea5e9",textColor:"#f8fafc"},{id:"artisan-warm",name:"بوتیک دست‌ساز",description:"الهام‌گرفته از کاغذ کتان گرم و سبک کلاسیک",primaryColor:"#292524",accentColor:"#e07a5f",textColor:"#f5f5f4"},{id:"full-image",name:"تمام‌تصویر اختصاصی",description:"استفاده از تصویر آپلودی به عنوان پس‌زمینه تمام‌صفحه جلد",primaryColor:"#18181b",accentColor:"#f59e0b",textColor:"#ffffff"}];function ue(){return{id:`cat-${Date.now()}`,name:"کاتالوگ جدید محصولات",flipDirection:"rtl",optimization:{quality:.82,maxDimension:1200},cover:{templateId:"luxury-foil",primaryColor:"#111827",accentColor:"#d4af37",textColor:"#f9fafb",title:"کاتالوگ جامع محصولات",subtitle:"مجموعه طراحی صنعتی، بسته‌بندی و خدمات چاپ تخصصی",brandName:"صنایع چاپ و بسته‌بندی اشک قلم",editionLabel:"نسخه اختصاصی",yearLabel:"۱۴۰۵",backHeadline:"سفارش عمده و مشاوره خرید",backDescription:"تمامی محصولات این کاتالوگ با ضمانت کیفیت، بسته‌بندی اختصاصی و ارسال سریع به سراسر کشور عرضه می‌شوند.",backContactInfo:"تلفن: 09153108763",backWebsite:"https://ashkghalam.ir",showPageNumbers:!0},pages:[],updatedAt:new Date().toISOString()}}function k(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Ue(s,o={}){const m=o.width||"100%",x=o.height||"680px",v=k(o.title||"کاتالوگ دیجیتال محصول"),w=k(s);return`<!-- کاتالوگ دیجیتال سه‌بعدی (ورق‌نگار) -->
<div style="width:${k(m)};max-width:100%;margin:0 auto;border-radius:16px;overflow:hidden;box-shadow:0 20px 45px rgba(0,0,0,0.14);background:#111318;">
  <iframe
    src="${w}"
    title="${v}"
    width="100%"
    height="${k(x)}"
    style="width:100%;height:${k(x)};border:0;display:block;"
    loading="lazy"
    allowfullscreen
  ></iframe>
</div>`}function ja(s,o){const m=(o.cover.title||"کاتالوگ دیجیتال").replace(/'/g,"\\'");return`<?php
/**
 * کد شورتکد کاتالوگ دیجیتال سه‌بعدی برای فایل functions.php قالب وردپرس
 * استفاده در نوشته‌ها و برگه‌ها: [digital_catalog]
 */
function varaghnegar_digital_catalog_shortcode( $atts ) {
    $a = shortcode_atts( array(
        'url'    => '${s.replace(/'/g,"\\'")}',
        'height' => '680px',
        'title'  => '${m}',
    ), $atts );

    return sprintf(
        '<div class="varaghnegar-flipbook-wrap" style="width:100%%;max-width:100%%;margin:24px auto;border-radius:16px;overflow:hidden;box-shadow:0 20px 45px rgba(0,0,0,0.14);background:#111318;"><iframe src="%s" title="%s" style="width:100%%;height:%s;border:0;display:block;" loading="lazy" allowfullscreen></iframe></div>',
        esc_url( $a['url'] ),
        esc_attr( $a['title'] ),
        esc_attr( $a['height'] )
    );
}
add_shortcode( 'digital_catalog', 'varaghnegar_digital_catalog_shortcode' );`}function Ca(s){const o=s.pages.filter(d=>(d.width||d.originalWidth)>(d.height||d.originalHeight)*1.05).length,m=s.pages.length-o,x=s.pageOrientation==="landscape"||s.pageOrientation!=="portrait"&&o>m,v=x?"540px":"400px",w=x?"405px":"545px",N={title:s.cover.title,subtitle:s.cover.subtitle,brandName:s.cover.brandName,editionLabel:s.cover.editionLabel,yearLabel:s.cover.yearLabel,primaryColor:s.cover.primaryColor,accentColor:s.cover.accentColor,textColor:s.cover.textColor,logoDataUrl:s.cover.logoDataUrl||"",frontCustomImageUrl:s.cover.frontCustomImageUrl||"",backCustomImageUrl:s.cover.backCustomImageUrl||"",backHeadline:s.cover.backHeadline,backDescription:s.cover.backDescription,backContactInfo:s.cover.backContactInfo,backWebsite:s.cover.backWebsite,flipDirection:s.flipDirection,pages:s.pages.map(d=>({title:d.title,description:d.description,category:d.category,tags:d.tags,sku:d.sku||"",priceLabel:d.priceLabel||"",img:d.optimizedDataUrl||d.originalDataUrl}))},y=JSON.stringify(N).replace(/</g,"\\u003c");return`<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${k(s.cover.title||"کاتالوگ دیجیتال محصول")}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;700;800&display=swap" rel="stylesheet" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Vazirmatn', Tahoma, sans-serif;
      background: #111318;
      color: #f4f4f5;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
    }
    .vn-shell {
      display: flex;
      flex-direction: column;
      height: 100vh;
      max-height: 100vh;
      width: 100%;
    }
    .vn-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 10px 16px;
      background: #181a20;
      border-bottom: 1px solid rgba(255,255,255,0.08);
      flex-wrap: wrap;
    }
    .vn-brand { font-size: 14px; font-weight: 700; color: #fafafa; }
    .vn-controls { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .vn-btn {
      background: #27272a;
      color: #f4f4f5;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 8px;
      padding: 6px 12px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s;
    }
    .vn-btn:hover:not(:disabled) { background: #3f3f46; }
    .vn-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .vn-btn.muted { color: #a1a1aa; }
    .vn-stage {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
      overflow: auto;
      perspective: 2200px;
    }
    .vn-book {
      display: flex;
      gap: 2px;
      transform-origin: center center;
      transition: transform 0.25s ease;
      box-shadow: 0 28px 65px rgba(0,0,0,0.6);
      border-radius: 8px;
      overflow: hidden;
      background: #1f2229;
    }
    .vn-page {
      width: ${v};
      max-width: 90vw;
      height: ${w};
      max-height: 76vh;
      background: #ffffff;
      color: #18181b;
      display: flex;
      flex-direction: column;
      position: relative;
      overflow: hidden;
      animation: vnFlipIn 0.36s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes vnFlipIn {
      from { opacity: 0.45; transform: rotateY(-12deg) scale(0.985); }
      to { opacity: 1; transform: rotateY(0deg) scale(1); }
    }
    .vn-page-img-wrap {
      width: 100%;
      height: ${x?"62%":"60%"};
      background: #f4f4f5;
      border-bottom: 1px solid #e4e4e7;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 8px;
      flex-shrink: 0;
    }
    .vn-page-img { max-width: 100%; max-height: 100%; width: 100%; height: 100%; object-fit: contain; }
    .vn-page-body { padding: 12px 16px; display: flex; flex-direction: column; gap: 6px; flex: 1; justify-content: space-between; min-height: 0; }
    .vn-meta { font-size: 11px; color: #b45309; font-weight: 700; }
    .vn-title { font-size: 14px; font-weight: 800; color: #18181b; line-height: 1.4; }
    .vn-desc { font-size: 11.5px; color: #52525b; line-height: 1.65; overflow: hidden; }
    .vn-footer { display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #71717a; border-top: 1px solid #e4e4e7; padding-top: 6px; }
    .vn-cover {
      width: 100%;
      height: 100%;
      padding: 28px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      text-align: center;
      background-size: cover;
      background-position: center;
    }
    .vn-jump {
      width: 52px;
      background: #27272a;
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 8px;
      color: #fff;
      text-align: center;
      padding: 5px;
      font-family: inherit;
      font-size: 12px;
    }
    @media (max-width: 768px) {
      .vn-page { width: 92vw; height: ${x?"54vh":"68vh"}; }
    }
  </style>
</head>
<body>
  <div class="vn-shell" id="vn-app">
    <div class="vn-toolbar">
      <div class="vn-brand">${k(s.cover.title||"کاتالوگ دیجیتال")}</div>
      <div class="vn-controls">
        <button class="vn-btn" id="vn-prev">صفحه قبلی</button>
        <input class="vn-jump" id="vn-jump" type="number" min="1" value="1" aria-label="شماره صفحه" />
        <span id="vn-counter" style="font-size:12px;color:#a1a1aa;"></span>
        <button class="vn-btn" id="vn-next">صفحه بعدی</button>
        <button class="vn-btn" id="vn-zoom-out">کوچک‌نمایی</button>
        <button class="vn-btn" id="vn-zoom-in">بزرگ‌نمایی</button>
        <button class="vn-btn" id="vn-sound">صدا روشن</button>
        <button class="vn-btn" id="vn-fs">تمام‌صفحه</button>
      </div>
    </div>
    <div class="vn-stage" id="vn-stage">
      <div class="vn-book" id="vn-book"></div>
    </div>
  </div>
  <script>
    (function() {
      var data = ${y};
      var items = [{ type: 'front' }].concat(
        data.pages.map(function(p, idx) { return { type: 'page', page: p, num: idx + 1 }; }),
        [{ type: 'back' }]
      );
      var current = 0;
      var zoom = 1;
      var isMuted = false;
      var audioCtx = null;
      var isMobile = window.innerWidth < 768;
      var bookEl = document.getElementById('vn-book');
      var counterEl = document.getElementById('vn-counter');
      var jumpEl = document.getElementById('vn-jump');
      var prevBtn = document.getElementById('vn-prev');
      var nextBtn = document.getElementById('vn-next');
      var soundBtn = document.getElementById('vn-sound');

      function playFlipSound() {
        if (isMuted) return;
        try {
          var Ctx = window.AudioContext || window.webkitAudioContext;
          if (!Ctx) return;
          if (!audioCtx) audioCtx = new Ctx();
          if (audioCtx.state === 'suspended') audioCtx.resume();
          var dur = 0.14;
          var len = Math.floor(audioCtx.sampleRate * dur);
          var buf = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
          var ch = buf.getChannelData(0);
          for (var i = 0; i < len; i++) {
            ch[i] = (Math.random() * 2 - 1) * 0.25 * Math.sin((i / len) * Math.PI);
          }
          var src = audioCtx.createBufferSource();
          src.buffer = buf;
          var flt = audioCtx.createBiquadFilter();
          flt.type = 'bandpass';
          flt.frequency.value = 1400;
          var g = audioCtx.createGain();
          g.gain.value = 0.18;
          src.connect(flt); flt.connect(g); g.connect(audioCtx.destination);
          src.start();
        } catch(e) {}
      }

      soundBtn.onclick = function() {
        isMuted = !isMuted;
        soundBtn.textContent = isMuted ? 'حالت سایلنت' : 'صدا روشن';
        soundBtn.className = isMuted ? 'vn-btn muted' : 'vn-btn';
        if (!isMuted) playFlipSound();
      };

      function esc(s) {
        return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      }

      function renderCard(entry) {
        if (entry.type === 'front') {
          var bg = data.frontCustomImageUrl
            ? 'background-image:linear-gradient(to top,rgba(0,0,0,0.78),rgba(0,0,0,0.25)),url(' + esc(data.frontCustomImageUrl) + ');color:#fff;'
            : 'background:' + esc(data.primaryColor) + ';color:' + esc(data.textColor) + ';';
          return '<div class="vn-page"><div class="vn-cover" style="' + bg + '">' +
            '<div style="font-size:12px;opacity:0.85;">' + esc(data.brandName) + ' · ' + esc(data.yearLabel) + '</div>' +
            '<div>' +
              (data.logoDataUrl ? '<img src="' + esc(data.logoDataUrl) + '" style="max-height:54px;margin:0 auto 14px;display:block;" alt="لوگو"/>' : '') +
              '<h1 style="font-size:22px;font-weight:800;margin-bottom:10px;line-height:1.4;">' + esc(data.title) + '</h1>' +
              '<p style="font-size:13px;opacity:0.85;line-height:1.7;">' + esc(data.subtitle) + '</p>' +
            '</div>' +
            '<div style="font-size:11px;color:' + esc(data.accentColor) + ';font-weight:700;">' + esc(data.editionLabel) + '</div>' +
          '</div></div>';
        }
        if (entry.type === 'back') {
          var bBg = data.backCustomImageUrl
            ? 'background-image:linear-gradient(to top,rgba(0,0,0,0.82),rgba(0,0,0,0.35)),url(' + esc(data.backCustomImageUrl) + ');color:#fff;'
            : 'background:' + esc(data.primaryColor) + ';color:' + esc(data.textColor) + ';';
          return '<div class="vn-page"><div class="vn-cover" style="' + bBg + '">' +
            '<div style="font-size:12px;opacity:0.8;">' + esc(data.brandName) + '</div>' +
            '<div>' +
              '<h2 style="font-size:18px;font-weight:800;margin-bottom:10px;">' + esc(data.backHeadline) + '</h2>' +
              '<p style="font-size:12px;opacity:0.85;line-height:1.8;">' + esc(data.backDescription) + '</p>' +
            '</div>' +
            '<div style="font-size:11px;opacity:0.85;line-height:1.8;">' + esc(data.backContactInfo) + '<br/>' + esc(data.backWebsite) + '</div>' +
          '</div></div>';
        }
        var p = entry.page;
        var tagsHtml = (p.tags || []).slice(0, 4).map(esc).join(' · ');
        return '<div class="vn-page">' +
          '<div class="vn-page-img-wrap"><img class="vn-page-img" src="' + esc(p.img) + '" alt="' + esc(p.title) + '" loading="lazy" /></div>' +
          '<div class="vn-page-body">' +
            '<div>' +
              '<div class="vn-meta">' + esc(p.category) + (p.sku ? ' · کد ' + esc(p.sku) : '') + '</div>' +
              '<h3 class="vn-title">' + esc(p.title) + '</h3>' +
              '<p class="vn-desc">' + esc(p.description) + '</p>' +
            '</div>' +
            '<div class="vn-footer">' +
              '<span>' + tagsHtml + '</span>' +
              '<span style="font-weight:700;color:#18181b;">' + (p.priceLabel ? esc(p.priceLabel) : 'صفحه ' + entry.num) + '</span>' +
            '</div>' +
          '</div>' +
        '</div>';
      }

      function render() {
        isMobile = window.innerWidth < 768;
        var html = '';
        if (isMobile || current === 0 || current >= items.length - 1) {
          html = renderCard(items[current]);
        } else {
          var first = items[current];
          var second = items[current + 1];
          html = data.flipDirection === 'rtl'
            ? renderCard(first) + (second ? renderCard(second) : '')
            : (second ? renderCard(second) : '') + renderCard(first);
        }
        bookEl.innerHTML = html;
        bookEl.style.transform = 'scale(' + zoom + ')';
        counterEl.textContent = 'از ' + items.length;
        jumpEl.max = items.length;
        jumpEl.value = current + 1;
        prevBtn.disabled = current <= 0;
        nextBtn.disabled = current >= items.length - 1;
      }

      function stepNext() {
        if (current >= items.length - 1) return;
        var step = (!isMobile && current > 0 && current + 2 < items.length) ? 2 : 1;
        current = Math.min(items.length - 1, current + step);
        playFlipSound();
        render();
      }
      function stepPrev() {
        if (current <= 0) return;
        var step = (!isMobile && current > 2 && current < items.length - 1) ? 2 : 1;
        current = Math.max(0, current - step);
        playFlipSound();
        render();
      }

      prevBtn.onclick = stepPrev;
      nextBtn.onclick = stepNext;
      jumpEl.onchange = function() {
        var val = parseInt(jumpEl.value, 10) || 1;
        current = Math.max(0, Math.min(items.length - 1, val - 1));
        playFlipSound();
        render();
      };
      document.getElementById('vn-zoom-in').onclick = function() { zoom = Math.min(1.8, +(zoom + 0.15).toFixed(2)); render(); };
      document.getElementById('vn-zoom-out').onclick = function() { zoom = Math.max(0.7, +(zoom - 0.15).toFixed(2)); render(); };
      document.getElementById('vn-fs').onclick = function() {
        var el = document.getElementById('vn-app');
        if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen();
        else if (document.exitFullscreen) document.exitFullscreen();
      };
      window.addEventListener('keydown', function(e) {
        if (data.flipDirection === 'rtl') {
          if (e.key === 'ArrowLeft') stepNext();
          if (e.key === 'ArrowRight') stepPrev();
        } else {
          if (e.key === 'ArrowRight') stepNext();
          if (e.key === 'ArrowLeft') stepPrev();
        }
      });
      var touchX = 0;
      bookEl.addEventListener('touchstart', function(e) { touchX = e.touches[0].clientX; }, { passive: true });
      bookEl.addEventListener('touchend', function(e) {
        var dx = e.changedTouches[0].clientX - touchX;
        if (Math.abs(dx) < 40) return;
        if (data.flipDirection === 'rtl') {
          if (dx > 0) stepNext(); else stepPrev();
        } else {
          if (dx < 0) stepNext(); else stepPrev();
        }
      }, { passive: true });
      window.addEventListener('resize', render);
      render();
    })();
  <\/script>
</body>
</html>`}const ea=r.lazy(()=>P(()=>import("./index-BozimEE4.js").then(s=>s.bg),__vite__mapDeps([0,1])).then(s=>({default:s.FlipbookViewer}))),ta=r.lazy(()=>P(()=>import("./ImageUploaderPanel-Bby3BNR_.js"),__vite__mapDeps([2,0,1,3,4,5,6,7,8,9,10,11,12,13,14])).then(s=>({default:s.ImageUploaderPanel}))),aa=r.lazy(()=>P(()=>import("./CoverDesignerPanel-nJdVsm5c.js"),__vite__mapDeps([15,0,1,3,4,5,6,7,8,9,10,11,12,13,14,16,17,18,19,20])).then(s=>({default:s.CoverDesignerPanel}))),sa=r.lazy(()=>P(()=>import("./WebOptimizerPanel-_dBI82sg.js"),__vite__mapDeps([21,0,1,18,8])).then(s=>({default:s.WebOptimizerPanel}))),ra=r.lazy(()=>P(()=>import("./WordpressExportPanel-DYvgqSzy.js"),__vite__mapDeps([22,0,1,14,11,23,24,9,16,17,5,18,8,19,10,12,20])).then(s=>({default:s.WordpressExportPanel}))),na=r.lazy(()=>P(()=>import("./index-BozimEE4.js").then(s=>s.bf),__vite__mapDeps([0,1])).then(s=>({default:s.CatalogSpreadModal})));function oa(s,o){return s.trim().toLowerCase().replace(/[^\w\u0600-\u06FF\s-]+/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"").slice(0,48)||o}const la=({label:s="در حال بارگذاری..."})=>e.jsxs("div",{className:"p-8 rounded-xl border border-stone-200 bg-white/70 flex items-center justify-center gap-2.5 text-xs text-stone-500",children:[e.jsx(U,{className:"w-4 h-4 animate-spin text-amber-600"}),e.jsx("span",{children:s})]}),He=Vt.memo(({catalog:s,categories:o,isEditingThis:m,isToggling:x,isConfirmingDel:v,onToggleStatus:w,onCategoryChange:N,onEdit:y,onPreview:d,onOpenEmbed:V,onRequestDelete:b,onConfirmDelete:W})=>{const L=r.useMemo(()=>Ve(s.coverImage,s.id),[s.coverImage,s.id]),g=s.isPublished!==!1,$=r.useMemo(()=>Array.from(new Set([...o,s.category].filter(Boolean))),[o,s.category]);return e.jsxs("div",{className:`border rounded-2xl overflow-hidden flex flex-col sm:flex-row transition-colors ${g?"bg-slate-950/75 border-slate-800":"bg-slate-950/40 border-slate-800/60 opacity-85"}`,children:[e.jsx("div",{className:"sm:w-40 aspect-[4/3] sm:aspect-auto bg-slate-900 border-b sm:border-b-0 sm:border-l border-slate-800 shrink-0 overflow-hidden flex items-center justify-center relative",children:L?e.jsx("img",{src:L,alt:s.title,loading:"lazy",decoding:"async",referrerPolicy:"no-referrer",className:`w-full h-full object-cover ${g?"":"grayscale-[60%]"}`}):e.jsx(xe,{className:"w-9 h-9 text-slate-600"})}),e.jsxs("div",{className:"flex-1 p-4 flex flex-col justify-between gap-3 min-w-0",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2 mb-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("button",{type:"button",dir:"ltr",role:"switch","aria-checked":g,"aria-label":g?`غیرفعال کردن موقت ${s.title}`:`فعال کردن ${s.title}`,disabled:x,onClick:()=>w(s),className:`relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus:outline-none ${g?"bg-emerald-500":"bg-slate-700"} ${x?"opacity-70":""}`,title:g?"فعال در سایت (کلیک برای مخفی‌سازی موقت)":"غیرفعال موقت (کلیک برای نمایش در سایت)",children:e.jsx("span",{className:`pointer-events-none inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${g?"translate-x-5":"translate-x-0.5"}`})}),e.jsx("span",{className:`text-[11px] font-extrabold ${g?"text-emerald-300":"text-slate-400"}`,children:g?"فعال در سایت":"غیرفعال (مخفی)"})]}),e.jsx("select",{value:s.category||"",onChange:f=>N(s,f.target.value),"aria-label":"تغییر دسته‌بندی کاتالوگ",className:"bg-slate-900 border border-slate-700/80 rounded-lg px-2 py-1 text-[11px] text-amber-300 font-semibold focus:outline-none focus:border-amber-500 max-w-[165px]",children:$.map(f=>e.jsx("option",{value:f,children:f},f))})]}),e.jsx("h3",{className:"text-sm font-extrabold text-slate-100 truncate mt-1",children:s.title}),e.jsxs("div",{className:"flex items-center gap-2 text-[11px] text-slate-400 mt-1 tabular-nums",children:[e.jsx("span",{children:s.flipbookId?"فلیپ‌بوک سه‌بعدی":"کاتالوگ فنی"}),s.pageCount?e.jsxs(e.Fragment,{children:[e.jsx("span",{"aria-hidden":"true",children:"·"}),e.jsxs("span",{children:[s.pageCount.toLocaleString("fa-IR")," صفحه"]})]}):null]})]}),v?e.jsxs("div",{className:"flex items-center justify-between gap-2 pt-2 border-t border-rose-500/30 text-xs",children:[e.jsx("span",{className:"text-rose-300 font-bold",children:"آیا از حذف مطمئنید؟"}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx("button",{type:"button",onClick:()=>W(s),className:"px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer",children:"بله، حذف شود"}),e.jsx("button",{type:"button",onClick:()=>b(null),className:"px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 font-bold cursor-pointer",children:"انصراف"})]})]}):e.jsxs("div",{className:"flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80",children:[e.jsxs("button",{type:"button",onClick:()=>y(s),disabled:m,className:"px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 text-xs font-extrabold flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0",children:[m?e.jsx(U,{className:"w-3.5 h-3.5 animate-spin"}):e.jsx(We,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:"ویرایش"})]}),e.jsxs("button",{type:"button",onClick:()=>d(s),className:"px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0",children:[e.jsx(ee,{className:"w-3.5 h-3.5 text-sky-400"}),e.jsx("span",{children:"پیش‌نمایش"})]}),s.flipbookId&&e.jsxs("button",{type:"button",onClick:()=>V(s),className:"px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0",children:[e.jsx(Wt,{className:"w-3.5 h-3.5 text-emerald-400"}),e.jsx("span",{children:"کد وردپرس"})]}),e.jsx("button",{type:"button",onClick:()=>b(s.id),className:"p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer mr-auto",title:"حذف کاتالوگ","aria-label":"حذف کاتالوگ",children:e.jsx(Zt,{className:"w-4 h-4"})})]})]})]})});He.displayName="CatalogAdminCard";const ia=()=>{const{catalogs:s,categories:o,loading:m,hasLoadedAdmin:x,error:v,ensureLoaded:w,refreshCatalogs:N,toggleCatalogStatus:y,saveCatalogItem:d,deleteCatalogItem:V,saveCategories:b,getFlipbookProject:W,cacheFlipbookProject:L}=Pt(),[g,$]=r.useState("list"),[f,qe]=r.useState(""),[H,Xe]=r.useState("ALL"),[S,ge]=r.useState("ALL"),[Ye,me]=r.useState(!1),[q,te]=r.useState(""),[be,I]=r.useState(!1),[Qe,he]=r.useState(null),[Ge,fe]=r.useState(null),[ve,we]=r.useState(!1),[c,p]=r.useState(()=>ue()),[ye,ae]=r.useState(void 0),[je,se]=r.useState(void 0),[j,z]=r.useState("کاتالوگ دیجیتال محصول"),[E,re]=r.useState(!0),[X,D]=r.useState("pages"),[Ce,Je]=r.useState(!1),[_,Ze]=r.useState(!0),[T,ne]=r.useState(!1),[Ke,A]=r.useState(!1),[Y,M]=r.useState(""),[Q,G]=r.useState("editor"),[et,ke]=r.useState(()=>pe()),tt=r.useDeferredValue(c),[J,Ne]=r.useState(!1),[at,Se]=r.useState(null),[Ie,Ee]=r.useState(null),[C,Z]=r.useState(null),[Pe,K]=r.useState(null),[h,oe]=r.useState(null),l=r.useRef(!0),R=r.useRef(null),O=r.useRef(null);r.useEffect(()=>(l.current=!0,()=>{l.current=!1,R.current!==null&&window.clearTimeout(R.current),O.current!==null&&window.clearTimeout(O.current)}),[]),r.useEffect(()=>{w(!0)},[w]),r.useEffect(()=>{if(g!=="builder")return;const t=window.setTimeout(()=>{Lt(c)},800);return()=>window.clearTimeout(t)},[c,g]);const i=r.useCallback((t,a)=>{l.current&&(Z({type:t,text:a}),R.current!==null&&window.clearTimeout(R.current),R.current=window.setTimeout(()=>{l.current&&Z(n=>(n==null?void 0:n.text)===a?null:n)},4500))},[]),Le=r.useCallback(async()=>{we(!0);try{await N(!0),i("ok","فهرست کاتالوگ‌ها بروزرسانی شد.")}finally{l.current&&we(!1)}},[N,i]),st=r.useCallback(async t=>{t&&t.preventDefault();const a=q.trim();if(a){if(o.includes(a)){te("");return}I(!0);try{if(await b([...o,a]),!l.current)return;te(""),i("ok",`دسته‌بندی «${a}» اضافه شد.`)}catch(n){l.current&&i("err",n instanceof Error?n.message:"خطا در افزودن دسته‌بندی")}finally{l.current&&I(!1)}}},[q,o,b,i]),rt=r.useCallback(async t=>{I(!0);try{if(await b(o.filter(a=>a!==t)),!l.current)return;S===t&&ge("ALL")}catch(a){l.current&&i("err",a instanceof Error?a.message:"خطا در حذف دسته‌بندی")}finally{l.current&&I(!1)}},[o,b,S,i]),nt=r.useCallback(()=>{const t=ue();t.id=`cat-${Date.now()}`,t.publishedId=void 0,t.name="کاتالوگ جدید محصولات",t.cover={...t.cover,title:"کاتالوگ جدید محصولات",subtitle:"معرفی محصولات و مشخصات فنی"},p(t),ae(void 0),se(void 0),z(o[0]||"کاتالوگ دیجیتال محصول"),re(!0),D("pages"),G("editor"),$("builder")},[o]),ot=r.useCallback(async t=>{Se(t.id);try{if(t.flipbookId){const a=await W(t.flipbookId);if(!l.current)return;p(a)}else{const a=ue(),n=Ve(t.coverImage,t.id);p({...a,id:`cat-${t.id}`,name:t.title,publishedId:void 0,cover:{...a.cover,title:t.title,subtitle:t.description?t.description.slice(0,90):a.cover.subtitle,frontCustomImageUrl:n},pages:n?[{id:`page-seed-${Date.now()}`,fileName:"cover-preview.jpg",originalDataUrl:n,optimizedDataUrl:n,originalSizeBytes:12e4,optimizedSizeBytes:12e4,originalWidth:1200,originalHeight:900,width:1200,height:900,title:t.title,description:t.description||"معرفی و مشخصات محصول در کاتالوگ سایت",category:t.category||"کاتالوگ محصول",tags:["کاتالوگ",t.category].filter(Boolean),aiStatus:"idle"}]:[]})}if(!l.current)return;ae(t.id),se(t.slug),z(t.category||o[0]||"کاتالوگ دیجیتال محصول"),re(t.isPublished!==!1),D("pages"),G("editor"),$("builder")}catch{l.current&&i("err","بارگذاری اطلاعات این کاتالوگ از سرور ناموفق بود.")}finally{l.current&&Se(null)}},[W,o,i]),lt=r.useCallback(async t=>{fe(t.id);const a=t.isPublished===!1;try{const n=await y(t.id,{isPublished:a});if(!l.current)return;i("ok",n.isPublished?`کاتالوگ «${n.title}» به‌صورت آنی در سایت فعال شد.`:`کاتالوگ «${n.title}» موقتاً غیرفعال شد و در سایت مخفی گردید.`)}catch(n){l.current&&i("err",n instanceof Error?n.message:"خطا در تغییر وضعیت نمایش")}finally{l.current&&fe(null)}},[y,i]),it=r.useCallback(async(t,a)=>{try{const n=await y(t.id,{category:a});l.current&&i("ok",`دسته‌بندی «${n.title}» به «${a}» تغییر یافت.`)}catch(n){l.current&&i("err",n instanceof Error?n.message:"خطا در تغییر دسته‌بندی")}},[y,i]),ct=r.useCallback(async t=>{try{if(await V(t.id,t.flipbookId),!l.current)return;he(null),i("ok",`کاتالوگ «${t.title}» با موفقیت حذف شد.`)}catch(a){l.current&&i("err",a instanceof Error?a.message:"خطا در حذف کاتالوگ")}},[V,i]),le=r.useCallback(async(t,a,n)=>{var Me,Re;const u=((Me=a.pages[0])==null?void 0:Me.optimizedDataUrl)||((Re=a.pages[0])==null?void 0:Re.originalDataUrl)||void 0,B=a.cover.frontCustomImageUrl||u,Ae=(a.cover.title||a.name||"کاتالوگ دیجیتال").trim(),Ct=ye||`cat-fb-${t}`,kt=je||oa(Ae,`catalog-${t}`),Nt=`${typeof window<"u"?window.location.origin:""}/embed/${encodeURIComponent(t)}`,St=a.cover.subtitle||a.pages.slice(0,3).map(de=>de.title).filter(Boolean).join(" · ")||"کاتالوگ تعاملی محصول",It={...a,publishedId:t};L(t,It);const ce=await d({id:Ct,slug:kt,title:Ae,category:j||o[0]||"کاتالوگ دیجیتال محصول",description:St,coverImage:B,pageCount:a.pages.length,flipbookId:t,coverTemplate:a.cover.templateId,wordpressShortcode:`[digital_catalog url="${Nt}" height="680px"]`,isPublished:n,specs:{standardCode:"3D Interactive Flipbook · WebP",boardOptions:`${a.pages.length.toLocaleString("fa-IR")} صفحه محصول بهینه‌شده`,finishOptions:a.flipDirection==="rtl"?"ورق‌زدن استاندارد فارسی (RTL)":"ورق‌زدن لاتین (LTR)",applications:a.cover.brandName||"کاتالوگ آنلاین سایت و وردپرس"}});return j&&!o.includes(j)&&await b([...o,j]).catch(()=>o),l.current&&(ae(ce.id),se(ce.slug),p(de=>({...de,publishedId:t}))),ce},[ye,je,j,o,L,d,b]),dt=r.useCallback(async()=>{if(!J){Ne(!0);try{const t=await $t(c);if(l.current&&p(t.project),await le(t.id,t.project,E),!l.current)return;i("ok",E?`کاتالوگ «${t.project.cover.title||t.project.name}» با موفقیت بهینه‌سازی، ذخیره و در سایت منتشر شد.`:`کاتالوگ «${t.project.cover.title||t.project.name}» ذخیره شد (در وضعیت غیرفعال موقت — مخفی از سایت).`)}catch(t){l.current&&i("err",t instanceof Error?t.message:"ذخیره کاتالوگ با خطا مواجه شد.")}finally{l.current&&Ne(!1)}}},[J,c,le,E,i]),pt=r.useCallback(t=>{p(a=>({...a,pages:[...a.pages,...t],updatedAt:new Date().toISOString()}))},[]),ut=r.useCallback((t,a)=>{p(n=>({...n,pages:n.pages.map(u=>u.id===t?{...u,...a}:u),updatedAt:new Date().toISOString()}))},[]),xt=r.useCallback(t=>{p(a=>({...a,pages:a.pages.filter(n=>n.id!==t),updatedAt:new Date().toISOString()}))},[]),gt=r.useCallback((t,a)=>{p(n=>{if(a<0||a>=n.pages.length||t===a)return n;const u=[...n.pages],[B]=u.splice(t,1);return u.splice(a,0,B),{...n,pages:u,updatedAt:new Date().toISOString()}})},[]),$e=r.useCallback(t=>{p(a=>({...a,name:t.title!==void 0?t.title:a.name,cover:{...a.cover,...t},updatedAt:new Date().toISOString()}))},[]),mt=r.useCallback(t=>{p(a=>({...a,optimization:t,updatedAt:new Date().toISOString()}))},[]),bt=r.useCallback(t=>{p(a=>({...a,pages:t,updatedAt:new Date().toISOString()}))},[]),ze=r.useCallback(t=>{p(a=>({...a,flipDirection:t,updatedAt:new Date().toISOString()}))},[]),De=r.useCallback(t=>{p(a=>({...a,pageOrientation:t,updatedAt:new Date().toISOString()}))},[]),_e=r.useCallback(async()=>{const t=Y.trim();if(t){if(o.includes(t)){z(t),M(""),A(!1);return}I(!0);try{if(await b([...o,t]),!l.current)return;z(t),M(""),A(!1),i("ok",`دسته‌بندی جدید «${t}» ثبت و انتخاب شد.`)}catch(a){l.current&&i("err",a instanceof Error?a.message:"خطا در ثبت دسته‌بندی")}finally{l.current&&I(!1)}}},[Y,o,b,i]),ht=r.useCallback(()=>{const t=zt(c);return ke(pe()),t},[c]),ft=r.useCallback(t=>{const a=Dt(t);a&&(p(a),D("pages"))},[]),vt=r.useCallback(t=>{_t(t),ke(pe())},[]),wt=r.useCallback(async(t,a)=>{const u=`${typeof window<"u"?window.location.origin:""}/embed/${encodeURIComponent(t)}`,B=Ue(u,{height:"680px",title:a});try{if(await navigator.clipboard.writeText(B),!l.current)return;Ee(t),O.current!==null&&window.clearTimeout(O.current),O.current=window.setTimeout(()=>{l.current&&Ee(null)},2e3)}catch{}},[]),ie=r.useMemo(()=>{const t=s.filter(a=>a.isPublished!==!1).length;return{all:s.length,active:t,inactive:s.length-t}},[s]),Te=r.useMemo(()=>{const t=f.trim().toLowerCase();return s.filter(a=>{const n=a.isPublished!==!1;return!(H==="ACTIVE"&&!n||H==="INACTIVE"&&n||S!=="ALL"&&(a.category||"")!==S||t&&!`${a.title} ${a.category||""} ${a.description||""}`.toLowerCase().includes(t))})},[s,H,S,f]),yt=r.useMemo(()=>Array.from(new Set([...o,j].filter(Boolean))),[o,j]);if(g==="builder"){const t=[{id:"pages",label:"۱. تصاویر و متن صفحات",icon:e.jsx(Ut,{className:"w-4 h-4"})},{id:"cover",label:"۲. ظاهر جلد و جهت ورق‌زدن",icon:e.jsx(xe,{className:"w-4 h-4"})},{id:"export",label:"۳. کد وردپرس و فایل پروژه",icon:e.jsx(Jt,{className:"w-4 h-4"})}];return e.jsxs("div",{className:"space-y-4",dir:"rtl",children:[C&&e.jsxs("div",{className:`px-4 py-3 rounded-xl border text-xs font-bold flex items-center justify-between gap-3 ${C.type==="ok"?"bg-emerald-500/15 border-emerald-500/40 text-emerald-200":"bg-rose-500/15 border-rose-500/40 text-rose-200"}`,children:[e.jsxs("div",{className:"flex items-center gap-2",children:[C.type==="ok"?e.jsx(Oe,{className:"w-4 h-4 text-emerald-400 shrink-0"}):e.jsx(Be,{className:"w-4 h-4 text-rose-400 shrink-0"}),e.jsx("span",{children:C.text})]}),e.jsx("button",{type:"button",onClick:()=>Z(null),className:"text-slate-300 hover:text-white cursor-pointer",children:e.jsx(F,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"bg-stone-100 text-stone-900 rounded-2xl border border-slate-700/70 shadow-xl overflow-hidden flex flex-col",children:[e.jsxs("div",{className:"bg-white border-b border-stone-200 p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3",children:[e.jsxs("div",{className:"flex flex-wrap items-center gap-3 flex-1 min-w-0",children:[e.jsxs("button",{type:"button",onClick:()=>$("list"),className:"px-3 py-2 rounded-lg border border-stone-200 hover:border-stone-400 bg-stone-50 text-stone-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0",children:[e.jsx(Tt,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:"بازگشت به لیست کاتالوگ‌ها"})]}),e.jsx("input",{type:"text",value:c.cover.title,onChange:a=>$e({title:a.target.value}),placeholder:"نام / عنوان کاتالوگ...",className:"flex-1 min-w-[200px] bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-sm font-bold text-stone-900 focus:outline-none focus:border-amber-500"}),e.jsxs("div",{className:"flex items-center gap-1.5 flex-wrap",children:[e.jsx("select",{value:j,onChange:a=>z(a.target.value),"aria-label":"دسته‌بندی کاتالوگ",className:"bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-xs font-bold text-stone-800 focus:outline-none focus:border-amber-500",children:yt.map(a=>e.jsxs("option",{value:a,children:["دسته: ",a]},a))}),Ke?e.jsxs("div",{className:"flex items-center gap-1 bg-stone-50 border border-amber-400 rounded-lg p-1",children:[e.jsx("input",{type:"text",value:Y,onChange:a=>M(a.target.value),onKeyDown:a=>{a.key==="Enter"?(a.preventDefault(),_e()):a.key==="Escape"&&(A(!1),M(""))},placeholder:"نام دسته جدید...",autoFocus:!0,className:"w-36 bg-white border border-stone-200 rounded px-2 py-1 text-xs text-stone-900 focus:outline-none focus:border-amber-500"}),e.jsx("button",{type:"button",disabled:be||!Y.trim(),onClick:()=>void _e(),className:"px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-[11px] font-bold cursor-pointer",children:"ثبت"}),e.jsx("button",{type:"button",onClick:()=>{A(!1),M("")},className:"p-1 text-stone-500 hover:text-stone-900 cursor-pointer","aria-label":"انصراف",children:e.jsx(F,{className:"w-3.5 h-3.5"})})]}):e.jsxs("button",{type:"button",onClick:()=>A(!0),title:"ثبت دسته‌بندی جدید برای سایت",className:"px-2.5 py-2 rounded-lg border border-stone-200 hover:border-amber-500 bg-stone-50 hover:bg-amber-50 text-stone-700 text-xs font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap",children:[e.jsx(Fe,{className:"w-3.5 h-3.5 text-amber-600"}),e.jsx("span",{children:"+ دسته جدید"})]})]})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2.5 shrink-0",children:[e.jsx("button",{type:"button",onClick:()=>re(a=>!a),className:`px-3 py-2 rounded-lg border text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap shrink-0 ${E?"bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100":"bg-stone-100 border-stone-300 text-stone-700 hover:bg-stone-200"}`,title:"تعیین اینکه این کاتالوگ الان در سایت نمایش داده شود یا موقتاً مخفی بماند",children:E?e.jsxs(e.Fragment,{children:[e.jsx(ee,{className:"w-3.5 h-3.5 text-emerald-600"}),e.jsx("span",{children:"نمایش در سایت: فعال"})]}):e.jsxs(e.Fragment,{children:[e.jsx(Ht,{className:"w-3.5 h-3.5 text-stone-500"}),e.jsx("span",{children:"غیرفعال موقت (مخفی)"})]})}),_&&e.jsxs("button",{type:"button",onClick:()=>ne(a=>!a),className:`hidden lg:flex px-3 py-2 rounded-lg border text-xs font-bold items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 transition-colors ${T?"bg-stone-900 border-stone-900 text-white":"border-stone-200 bg-white hover:bg-stone-50 text-stone-700"}`,title:"گسترش پیش‌نمایش سه‌بعدی در کل عرض صفحه",children:[T?e.jsx(At,{className:"w-3.5 h-3.5 text-amber-400"}):e.jsx(Mt,{className:"w-3.5 h-3.5 text-amber-600"}),e.jsx("span",{children:T?"بازگشت به ویرایشگر":"فضای بزرگ پیش‌نمایش"})]}),e.jsxs("button",{type:"button",onClick:()=>{Ze(a=>!a),_&&ne(!1)},className:"hidden lg:flex px-3 py-2 rounded-lg border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-semibold items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0",children:[e.jsx(ee,{className:"w-3.5 h-3.5 text-amber-600"}),e.jsx("span",{children:_?"مخفی‌کردن پیش‌نمایش":"نمایش پیش‌نمایش ۳D"})]}),e.jsxs("button",{type:"button",onClick:dt,disabled:J,className:"px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-sm",children:[J?e.jsx(U,{className:"w-3.5 h-3.5 animate-spin"}):e.jsx(qt,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:"ذخیره و ثبت کاتالوگ"})]})]})]}),e.jsxs("div",{className:"bg-stone-50 border-b border-stone-200 px-4 py-2 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar",children:[e.jsx("div",{className:"flex items-center gap-2",children:t.map(a=>{const n=X===a.id;return e.jsxs("button",{type:"button",onClick:()=>{D(a.id),T&&ne(!1)},className:`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${n?"bg-stone-900 text-white shadow-sm":"text-stone-600 hover:text-stone-900 hover:bg-stone-200/70"}`,children:[a.icon,e.jsx("span",{children:a.label})]},a.id)})}),e.jsxs("span",{className:"text-[11px] text-stone-500 tabular-nums whitespace-nowrap hidden sm:inline",children:[c.pages.length.toLocaleString("fa-IR")," صفحه آماده"]})]}),e.jsx("div",{className:"lg:hidden bg-white border-b border-stone-200 px-3 py-2",children:e.jsxs("div",{className:"grid grid-cols-2 gap-1 p-1 bg-stone-100 rounded-lg",children:[e.jsxs("button",{type:"button",onClick:()=>G("editor"),className:`py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${Q==="editor"?"bg-white text-stone-900 shadow-sm":"text-stone-600"}`,children:[e.jsx(We,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:"ویرایشگر کاتالوگ"})]}),e.jsxs("button",{type:"button",onClick:()=>G("preview"),className:`py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${Q==="preview"?"bg-white text-stone-900 shadow-sm":"text-stone-600"}`,children:[e.jsx(ee,{className:"w-3.5 h-3.5 text-amber-600"}),e.jsx("span",{children:"پیش‌نمایش سه‌بعدی"})]})]})}),e.jsxs("div",{className:"flex flex-col lg:flex-row min-h-[640px] lg:h-[calc(100vh-200px)] lg:max-h-[860px]",children:[!T&&e.jsx("aside",{className:`${_?"w-full lg:w-[410px] xl:w-[445px]":"w-full max-w-4xl mx-auto"} bg-stone-50 border-l border-stone-200 flex-col min-h-0 shrink-0 ${Q==="editor"?"flex":"hidden lg:flex"}`,children:e.jsx("div",{className:"flex-1 overflow-y-auto p-4 sm:p-5 space-y-5",children:e.jsxs(r.Suspense,{fallback:e.jsx(la,{label:"در حال بارگذاری ابزارهای ویرایش..."}),children:[X==="pages"&&e.jsxs(e.Fragment,{children:[e.jsx(ta,{pages:c.pages,optimization:c.optimization,onAddPages:pt,onUpdatePage:ut,onRemovePage:xt,onReorderPages:gt}),e.jsxs("div",{className:"rounded-xl border border-stone-200 bg-white overflow-hidden",children:[e.jsxs("button",{type:"button",onClick:()=>Je(a=>!a),className:"w-full px-4 py-3 flex items-center justify-between text-xs font-bold text-stone-800 hover:bg-stone-50 cursor-pointer",children:[e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsx(Xt,{className:"w-4 h-4 text-amber-600"}),e.jsx("span",{children:"تنظیمات فشرده‌سازی خودکار WebP (کاهش حجم وب)"})]}),Ce?e.jsx(Rt,{className:"w-4 h-4"}):e.jsx(Ot,{className:"w-4 h-4"})]}),Ce&&e.jsx("div",{className:"p-4 border-t border-stone-100",children:e.jsx(sa,{optimization:c.optimization,pages:c.pages,onChangeOptimization:mt,onReplaceAllOptimizedPages:bt})})]})]}),X==="cover"&&e.jsx(aa,{cover:c.cover,optimization:c.optimization,pageOrientation:c.pageOrientation||"auto",flipDirection:c.flipDirection,onChangeCover:$e,onChangeOrientation:De,onChangeFlipDirection:ze}),X==="export"&&e.jsx(ra,{project:c,savedProjects:et,onRenameProject:a=>p(n=>({...n,name:a})),onSaveProjectToBrowser:ht,onLoadProjectFromBrowser:ft,onDeleteProjectFromBrowser:vt,onImportProject:a=>{p(a),D("pages")},onProjectPublished:(a,n)=>p(u=>n?{...n,publishedId:a}:{...u,publishedId:a}),onPublishToSite:async(a,n)=>{await le(a,n||c,E)}})]})})}),_&&e.jsx("section",{"aria-label":"پیش‌نمایش زنده کاتالوگ سه‌بعدی",className:`flex-1 p-2.5 sm:p-4 min-h-[560px] lg:min-h-0 flex-col bg-stone-200/80 ${Q==="preview"?"flex":"hidden lg:flex"}`,children:e.jsx(r.Suspense,{fallback:e.jsxs("div",{className:"flex-1 rounded-2xl bg-[#12141a] text-stone-300 flex flex-col items-center justify-center gap-3 text-xs",children:[e.jsx(U,{className:"w-6 h-6 animate-spin text-amber-400"}),e.jsx("span",{children:"در حال آماده‌سازی نمایشگر سه‌بعدی..."})]}),children:e.jsx(ea,{project:tt,onFlipDirectionChange:ze,onOrientationChange:De})})})]})]})]})}const jt=!x&&m;return e.jsxs("div",{className:"space-y-5",dir:"rtl",children:[e.jsxs("div",{className:"bg-slate-950/70 border border-slate-800 rounded-2xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-lg font-black text-slate-100",children:"مدیریت و انتشار کاتالوگ‌های سایت"}),e.jsx("p",{className:"text-xs text-slate-400 mt-1",children:"با سوییچ فعال/غیرفعال روی هر کاتالوگ، نمایش آن را در سایت به‌صورت آنی کنترل کنید (وضعیت کاتالوگ‌ها در حافظه پایدار ذخیره می‌ماند)."})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2.5 shrink-0",children:[e.jsxs("button",{type:"button",onClick:Le,disabled:ve,className:"px-3 py-2.5 rounded-xl border border-slate-700 hover:border-slate-500 bg-slate-900 text-slate-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap disabled:opacity-50",title:"بروزرسانی فهرست از سرور",children:[e.jsx(Yt,{className:`w-3.5 h-3.5 text-emerald-400 ${ve?"animate-spin":""}`}),e.jsx("span",{children:"بروزرسانی"})]}),e.jsxs("button",{type:"button",onClick:()=>me(t=>!t),className:"px-3.5 py-2.5 rounded-xl border border-slate-700 hover:border-slate-500 bg-slate-900 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap",children:[e.jsx(Fe,{className:"w-4 h-4 text-sky-400"}),e.jsx("span",{children:"مدیریت دسته‌بندی‌ها"})]}),e.jsxs("button",{type:"button",onClick:nt,className:"px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-md",children:[e.jsx(Qt,{className:"w-4 h-4"}),e.jsx("span",{children:"ساخت کاتالوگ جدید"})]})]})]}),C&&e.jsxs("div",{className:`px-4 py-3 rounded-xl border text-xs font-bold flex items-center justify-between gap-3 ${C.type==="ok"?"bg-emerald-500/15 border-emerald-500/40 text-emerald-200":"bg-rose-500/15 border-rose-500/40 text-rose-200"}`,children:[e.jsxs("div",{className:"flex items-center gap-2",children:[C.type==="ok"?e.jsx(Oe,{className:"w-4 h-4 text-emerald-400 shrink-0"}):e.jsx(Be,{className:"w-4 h-4 text-rose-400 shrink-0"}),e.jsx("span",{children:C.text})]}),e.jsx("button",{type:"button",onClick:()=>Z(null),className:"text-slate-300 hover:text-white cursor-pointer",children:e.jsx(F,{className:"w-4 h-4"})})]}),Ye&&e.jsxs("div",{className:"bg-slate-950/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("h3",{className:"text-sm font-extrabold text-slate-100",children:"دسته‌بندی‌های کاتالوگ سایت"}),e.jsx("button",{type:"button",onClick:()=>me(!1),className:"text-xs text-slate-400 hover:text-white cursor-pointer",children:"بستن"})]}),e.jsxs("form",{onSubmit:st,className:"flex gap-2",children:[e.jsx("input",{type:"text",value:q,onChange:t=>te(t.target.value),placeholder:"نام دسته‌بندی جدید (مثلاً: جعبه‌های صادراتی زعفران)...",className:"flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"}),e.jsx("button",{type:"submit",disabled:be||!q.trim(),className:"px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-slate-950 text-xs font-extrabold cursor-pointer whitespace-nowrap",children:"افزودن دسته"})]}),e.jsx("div",{className:"flex flex-wrap gap-2",children:o.map(t=>e.jsxs("div",{className:"flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200",children:[e.jsx("span",{children:t}),e.jsx("button",{type:"button",onClick:()=>rt(t),className:"text-slate-400 hover:text-rose-400 cursor-pointer",title:"حذف این دسته‌بندی",children:e.jsx(F,{className:"w-3.5 h-3.5"})})]},t))})]}),e.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3",children:[e.jsx("div",{className:"flex items-center gap-1.5 overflow-x-auto no-scrollbar",children:[{id:"ALL",label:`همه (${ie.all.toLocaleString("fa-IR")})`},{id:"ACTIVE",label:`فعال در سایت (${ie.active.toLocaleString("fa-IR")})`},{id:"INACTIVE",label:`غیرفعال موقت (${ie.inactive.toLocaleString("fa-IR")})`}].map(t=>e.jsx("button",{type:"button",onClick:()=>Xe(t.id),className:`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 tabular-nums ${H===t.id?"bg-amber-500 text-slate-950":"bg-slate-900 text-slate-300 hover:bg-slate-800"}`,children:t.label},t.id))}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2.5",children:[e.jsxs("select",{value:S,onChange:t=>ge(t.target.value),"aria-label":"فیلتر دسته‌بندی",className:"bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 focus:outline-none focus:border-amber-500",children:[e.jsx("option",{value:"ALL",children:"همه دسته‌بندی‌ها"}),o.map(t=>e.jsx("option",{value:t,children:t},t))]}),e.jsxs("div",{className:"relative flex-1 sm:w-56",children:[e.jsx("input",{type:"text",value:f,onChange:t=>qe(t.target.value),placeholder:"جستجوی کاتالوگ...",className:"w-full bg-slate-900 border border-slate-700 rounded-xl py-2 pr-3 pl-9 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"}),e.jsx(Bt,{className:"w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5"})]})]})]}),jt?e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[1,2].map(t=>e.jsx("div",{className:"h-40 rounded-2xl bg-slate-900/70 border border-slate-800"},t))}):v&&s.length===0?e.jsxs("div",{className:"p-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex items-center justify-between gap-4",children:[e.jsx("span",{children:v}),e.jsx("button",{type:"button",onClick:Le,className:"px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 font-bold cursor-pointer",children:"تلاش مجدد"})]}):Te.length===0?e.jsxs("div",{className:"text-center py-12 px-6 bg-slate-950/40 border border-slate-800 rounded-2xl",children:[e.jsx(xe,{className:"w-10 h-10 text-amber-400/70 mx-auto mb-3"}),e.jsx("h3",{className:"text-sm font-extrabold text-slate-100 mb-1",children:"کاتالوگی با این فیلتر یافت نشد"}),e.jsx("p",{className:"text-xs text-slate-400 max-w-md mx-auto mb-4",children:"فیلتر وضعیت یا دسته‌بندی را تغییر دهید یا یک کاتالوگ جدید بسازید."})]}):e.jsx("div",{className:"grid grid-cols-1 xl:grid-cols-2 gap-4",children:Te.map(t=>e.jsx(He,{catalog:t,categories:o,isEditingThis:at===t.id,isToggling:Ge===t.id,isConfirmingDel:Qe===t.id,onToggleStatus:lt,onCategoryChange:it,onEdit:ot,onPreview:K,onOpenEmbed:oe,onRequestDelete:he,onConfirmDelete:ct},t.id))}),Pe&&e.jsx(r.Suspense,{fallback:e.jsxs("div",{className:"fixed inset-0 z-[120] bg-black/80 flex items-center justify-center text-white text-xs gap-2",children:[e.jsx(U,{className:"w-5 h-5 animate-spin text-amber-400"}),e.jsx("span",{children:"در حال باز کردن پیش‌نمایش کاتالوگ..."})]}),children:e.jsx(na,{catalog:Pe,onClose:()=>K(null),onRequestInquiry:()=>K(null),onOpenDielineStudio:()=>K(null)})}),(h==null?void 0:h.flipbookId)&&e.jsx("div",{className:"fixed inset-0 z-[130] bg-black/80 p-4 flex items-center justify-center",onClick:()=>oe(null),children:e.jsxs("div",{className:"w-full max-w-xl bg-white text-stone-900 rounded-2xl p-5 space-y-4 shadow-2xl",onClick:t=>t.stopPropagation(),children:[e.jsxs("div",{className:"flex items-center justify-between border-b border-stone-200 pb-3",children:[e.jsxs("h3",{className:"text-sm font-extrabold",children:["کد جاسازی وردپرس — ",h.title]}),e.jsx("button",{type:"button",onClick:()=>oe(null),className:"p-1 text-stone-500 hover:text-stone-900 cursor-pointer",children:e.jsx(F,{className:"w-4 h-4"})})]}),e.jsxs("p",{className:"text-xs text-stone-600 leading-relaxed",children:["کد زیر را کپی کرده و در برگه وردپرس داخل بلوک ",e.jsx("strong",{children:"«HTML سفارشی»"})," یا ویجت HTML المنتور قرار دهید:"]}),e.jsx("pre",{dir:"ltr",className:"p-3 rounded-xl bg-stone-900 text-stone-100 text-[11px] font-mono overflow-x-auto",children:Ue(`${typeof window<"u"?window.location.origin:""}/embed/${encodeURIComponent(h.flipbookId)}`,{height:"680px",title:h.title})}),e.jsx("div",{className:"flex items-center justify-end gap-2",children:e.jsxs("button",{type:"button",onClick:()=>wt(h.flipbookId,h.title),className:"px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer",children:[Ie===h.flipbookId?e.jsx(Ft,{className:"w-3.5 h-3.5"}):e.jsx(Gt,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:Ie===h.flipbookId?"کپی شد":"کپی کد iFrame"})]})})]})})]})},ca=()=>e.jsx(ia,{}),ka=Object.freeze(Object.defineProperty({__proto__:null,AdminCatalogManager:ca},Symbol.toStringTag,{value:"Module"}));export{ka as A,ya as C,ja as a,Ca as b,Ue as g};
