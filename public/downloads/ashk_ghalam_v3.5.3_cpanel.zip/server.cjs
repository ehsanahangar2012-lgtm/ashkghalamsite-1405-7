var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express3 = __toESM(require("express"), 1);
var import_vite = require("vite");
var import_multer = __toESM(require("multer"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_adm_zip = __toESM(require("adm-zip"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_child_process = require("child_process");
var import_genai = require("@google/genai");

// src/api/index.ts
var import_express2 = require("express");

// src/registry/TemplateRegistry.ts
var TemplateRegistry = class {
  constructor() {
    this.templates = /* @__PURE__ */ new Map();
    this.engines = /* @__PURE__ */ new Map();
  }
  registerTemplate(template, engine2) {
    this.templates.set(template.id, template);
    this.engines.set(template.engine, engine2);
  }
  getTemplate(id) {
    return this.templates.get(id);
  }
  getEngine(engineId) {
    return this.engines.get(engineId);
  }
  getAllTemplates() {
    return Array.from(this.templates.values());
  }
  async loadEngineDynamically(engineId) {
    const engine2 = this.engines.get(engineId);
    if (!engine2) {
      throw new Error(`Engine ${engineId} not found in registry.`);
    }
    return engine2;
  }
};
var globalRegistry = new TemplateRegistry();

// src/rules/RuleEngine.ts
var RuleEngine = class {
  constructor() {
    this.rules = [];
  }
  addRule(rule) {
    this.rules.push(rule);
  }
  evaluate(initialParams, constants = {}) {
    const context = {
      params: { ...initialParams },
      constants
    };
    for (const rule of this.rules) {
      if (!rule.condition || rule.condition(context)) {
        rule.action(context);
      }
    }
    return context.params;
  }
};

// src/exporters/SVGExporter.ts
var SVGExporter = class {
  export(primitives, options = {}) {
    const { strokeWidth = 1, strokeColor = "black", fillColor = "none" } = options;
    let svgPaths = "";
    for (const primitive of primitives) {
      let d = "";
      for (const cmd of primitive.paths) {
        if (cmd.type === 0 /* MoveTo */) {
          d += `M ${cmd.points[0].x},${cmd.points[0].y} `;
        } else if (cmd.type === 1 /* LineTo */) {
          d += `L ${cmd.points[0].x},${cmd.points[0].y} `;
        }
      }
      svgPaths += `<path id="${primitive.id}" class="${primitive.type}" d="${d.trim()}" stroke="${strokeColor}" stroke-width="${strokeWidth}" fill="${fillColor}" />
`;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg">
${svgPaths}</svg>`;
  }
};

// src/workflow/workflowRouter.ts
var import_express = require("express");

// src/workflow/VerificationService.ts
var WorkflowVerificationService = class _WorkflowVerificationService {
  static getInstance() {
    if (!_WorkflowVerificationService.instance) {
      _WorkflowVerificationService.instance = new _WorkflowVerificationService();
    }
    return _WorkflowVerificationService.instance;
  }
  /**
   * Helper to format Shamsi date
   */
  getShamsiTimestamp(date = /* @__PURE__ */ new Date()) {
    try {
      return new Intl.DateTimeFormat("fa-IR", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }).format(date);
    } catch {
      return date.toISOString();
    }
  }
  /**
   * Clean and normalize Persian text for title matching
   */
  normalizePersian(text) {
    if (!text) return "";
    return text.replace(/[\u200C\u200B]/g, " ").replace(/ي/g, "\u06CC").replace(/ك/g, "\u06A9").replace(/[\u064B-\u065F]/g, "").replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, " ").trim().toLowerCase();
  }
  /**
   * Calculate string similarity based on shared meaningful tokens
   */
  calculateTitleSimilarity(sourceTitle, targetTitle) {
    const tokensA = this.normalizePersian(sourceTitle).split(/\s+/).filter((w) => w.length > 2);
    const tokensB = this.normalizePersian(targetTitle).split(/\s+/).filter((w) => w.length > 2);
    if (tokensA.length === 0 || tokensB.length === 0) return 0;
    const setB = new Set(tokensB);
    let matchedCount = 0;
    for (const token of tokensA) {
      if (setB.has(token)) {
        matchedCount++;
      }
    }
    return matchedCount / Math.max(tokensA.length, tokensB.length) * 100;
  }
  /**
   * Extract real ad link from raw response payload or redirect URL
   */
  extractAdLinkFromResponse(payload) {
    if (!payload) return null;
    if (typeof payload === "string") {
      const urlMatch = payload.match(/https?:\/\/[^\s"']+(?:\/v\/|\/posts\/|\/ad\/|\/manage\/)[^\s"']+/i);
      if (urlMatch) {
        const url = urlMatch[0];
        const idMatch = url.match(/(?:\/v\/|\/posts\/|\/ad\/)([a-zA-Z0-9_-]+)/);
        return { url, adId: idMatch ? idMatch[1] : void 0 };
      }
    }
    if (typeof payload === "object") {
      const candidateUrl = payload.url || payload.adUrl || payload.link || payload.postUrl || payload.web_url;
      const candidateId = payload.id || payload.adId || payload.postId || payload.token;
      if (candidateUrl && typeof candidateUrl === "string") {
        return {
          url: candidateUrl,
          adId: candidateId ? String(candidateId) : void 0
        };
      }
    }
    return null;
  }
  /**
   * Strict Verification: Matches URL, Title, and ID.
   * If evidence is insufficient, returns UNKNOWN. Never assumes PUBLISHED on HTTP 200 alone.
   */
  async verifyAd(req) {
    const verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
    const verifiedAtShamsi = this.getShamsiTimestamp();
    const reasons = [];
    if (!req.adUrl || !req.adUrl.startsWith("http")) {
      reasons.push("\u0644\u06CC\u0646\u06A9 \u0645\u0639\u062A\u0628\u0631 \u0648 \u0633\u0627\u062E\u062A\u0627\u0631\u06CC\u0627\u0641\u062A\u0647 \u0627\u0632 \u0646\u062A\u06CC\u062C\u0647 \u0633\u0627\u0645\u0627\u0646\u0647 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0646\u0634\u062F.");
      return {
        status: "UNKNOWN",
        adUrl: req.adUrl || "",
        adId: req.adId,
        titleMatch: false,
        adIdMatch: false,
        verificationScore: 0,
        evidenceReasons: reasons,
        verifiedAt,
        verifiedAtShamsi
      };
    }
    if (req.pageStatus && req.pageStatus >= 400) {
      reasons.push(`\u062E\u0637\u0627\u06CC \u062F\u0633\u062A\u0631\u0633\u06CC HTTP ${req.pageStatus} \u0628\u0647 \u0635\u0641\u062D\u0647 \u0622\u06AF\u0647\u06CC \u06AF\u0632\u0627\u0631\u0634 \u0634\u062F.`);
      return {
        status: "REJECTED",
        adUrl: req.adUrl,
        adId: req.adId,
        titleMatch: false,
        adIdMatch: false,
        verificationScore: 0,
        evidenceReasons: reasons,
        verifiedAt,
        verifiedAtShamsi
      };
    }
    let titleMatch = false;
    let adIdMatch = false;
    let score = 0;
    if (req.adId) {
      if (req.adUrl.includes(req.adId) || req.htmlContent && req.htmlContent.includes(req.adId)) {
        adIdMatch = true;
        score += 40;
        reasons.push(`\u0634\u0646\u0627\u0633\u0647 \u0622\u06AF\u0647\u06CC (${req.adId}) \u0628\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 \u0635\u0641\u062D\u0647 \u0639\u0645\u0648\u0645\u06CC \u062A\u0637\u0628\u06CC\u0642 \u062F\u0627\u0631\u062F.`);
      } else {
        reasons.push(`\u0634\u0646\u0627\u0633\u0647 \u0622\u06AF\u0647\u06CC (${req.adId}) \u062F\u0631 \u0635\u0641\u062D\u0647 \u06CC\u0627 \u0622\u062F\u0631\u0633 URL \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.`);
      }
    }
    if (req.htmlContent && req.expectedTitle) {
      const titleTagMatch = req.htmlContent.match(/<title[^>]*>([^<]+)<\/title>/i);
      const h1TagMatch = req.htmlContent.match(/<h1[^>]*>([^<]+)<\/h1>/i);
      const extractedTitle = (h1TagMatch ? h1TagMatch[1] : titleTagMatch ? titleTagMatch[1] : "").trim();
      const similarity = this.calculateTitleSimilarity(req.expectedTitle, extractedTitle || req.htmlContent);
      if (similarity >= 60) {
        titleMatch = true;
        score += 60;
        reasons.push(`\u062A\u0637\u0628\u06CC\u0642 \u0645\u0639\u0646\u0627\u06CC\u06CC \u0639\u0646\u0648\u0627\u0646 (${Math.round(similarity)}%) \u0628\u0627 \u0639\u0646\u0648\u0627\u0646 \u0648\u0627\u0642\u0639\u06CC \u06A9\u0645\u067E\u06CC\u0646 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F.`);
      } else {
        reasons.push(`\u062A\u0637\u0628\u06CC\u0642 \u0639\u0646\u0648\u0627\u0646 \u0646\u0627\u06A9\u0627\u0641\u06CC \u0627\u0633\u062A (${Math.round(similarity)}% \u0634\u0628\u0627\u0647\u062A \u0628\u0627 \xAB${req.expectedTitle}\xBB).`);
      }
    } else {
      reasons.push("\u0645\u062D\u062A\u0648\u0627\u06CC DOM \u0635\u0641\u062D\u0647 \u0639\u0645\u0648\u0645\u06CC \u062C\u0647\u062A \u0628\u0631\u0631\u0633\u06CC \u062F\u0642\u06CC\u0642 \u0639\u0646\u0648\u0627\u0646 \u0627\u0631\u0627\u0626\u0647 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
    }
    if (score >= 80 && (titleMatch && adIdMatch)) {
      reasons.push("\u062A\u0623\u06CC\u06CC\u062F\u06CC\u0647 \u06A9\u0627\u0645\u0644 \u0628\u0627 \u0627\u062D\u0631\u0627\u0632 \u0647\u0645\u0632\u0645\u0627\u0646 \u0634\u0646\u0627\u0633\u0647\u060C \u0639\u0646\u0648\u0627\u0646 \u0648 \u0644\u06CC\u0646\u06A9 \u0639\u0645\u0648\u0645\u06CC \u0635\u0627\u062F\u0631 \u06AF\u0631\u062F\u06CC\u062F.");
      return {
        status: "PUBLISHED",
        adUrl: req.adUrl,
        adId: req.adId,
        titleMatch,
        adIdMatch,
        verificationScore: score,
        evidenceReasons: reasons,
        verifiedAt,
        verifiedAtShamsi
      };
    }
    reasons.push("\u0634\u0648\u0627\u0647\u062F \u0628\u0631\u0627\u06CC \u062B\u0628\u062A \u0642\u0637\u0639\u06CC \u0648\u0636\u0639\u06CC\u062A PUBLISHED \u06A9\u0627\u0641\u06CC \u0646\u06CC\u0633\u062A\u061B \u0648\u0636\u0639\u06CC\u062A \u0631\u0648\u06CC UNKNOWN \u062A\u062B\u0628\u06CC\u062A \u0634\u062F.");
    return {
      status: "UNKNOWN",
      adUrl: req.adUrl,
      adId: req.adId,
      titleMatch,
      adIdMatch,
      verificationScore: score,
      evidenceReasons: reasons,
      verifiedAt,
      verifiedAtShamsi
    };
  }
};

// src/workflow/WorkerCoordinator.ts
var WorkerCoordinator = class _WorkerCoordinator {
  constructor() {
    this.tasks = /* @__PURE__ */ new Map();
    this.workerHeartbeats = /* @__PURE__ */ new Map();
    this.workerHeartbeats.set("github_worker", { lastSeen: Date.now() });
    this.workerHeartbeats.set("local_worker", { lastSeen: Date.now() });
  }
  static getInstance() {
    if (!_WorkerCoordinator.instance) {
      _WorkerCoordinator.instance = new _WorkerCoordinator();
    }
    return _WorkerCoordinator.instance;
  }
  /**
   * Register a worker heartbeat
   */
  recordHeartbeat(worker, metadata) {
    this.workerHeartbeats.set(worker, { lastSeen: Date.now(), metadata });
  }
  /**
   * Check if a worker is considered available (within 60 seconds)
   */
  isWorkerHealthy(worker) {
    const hb = this.workerHeartbeats.get(worker);
    if (!hb) return false;
    return Date.now() - hb.lastSeen < 6e4;
  }
  /**
   * Create and queue a new task
   */
  queueTask(type, targetWorker, identifiers, payload) {
    const taskId = `tsk-${Date.now()}-${Math.floor(Math.random() * 1e4)}`;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const nowShamsi = WorkflowVerificationService.getInstance().getShamsiTimestamp();
    const task = {
      taskId,
      identifiers,
      type,
      targetWorker,
      status: "QUEUED",
      queuedAt: now,
      payload,
      evidence: [
        {
          timestamp: now,
          timestampShamsi: nowShamsi,
          phase: "TASK_QUEUED",
          description: `\u062A\u0633\u06A9 \u0628\u0627 \u0634\u0646\u0627\u0633\u0647 ${taskId} \u062F\u0631 \u0635\u0641 \u0648\u0631\u06A9\u0631 ${targetWorker} \u0642\u0631\u0627\u0631 \u06AF\u0631\u0641\u062A.`
        }
      ]
    };
    this.tasks.set(taskId, task);
    return task;
  }
  /**
   * Claim a task by a specific worker (QUEUED -> CLAIMED)
   */
  claimTask(taskId, worker) {
    const task = this.tasks.get(taskId);
    if (!task) return null;
    if (task.status !== "QUEUED" && task.status !== "PENDING_RUNNER_PICKUP") {
      return task;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const nowShamsi = WorkflowVerificationService.getInstance().getShamsiTimestamp();
    task.assignedWorker = worker;
    task.status = "CLAIMED";
    task.claimedAt = now;
    task.evidence.push({
      timestamp: now,
      timestampShamsi: nowShamsi,
      phase: "TASK_CLAIMED",
      description: `\u062A\u0633\u06A9 ${taskId} \u062A\u0648\u0633\u0637 \u0648\u0631\u06A9\u0631 ${worker} \u0631\u0632\u0631\u0648 \u0648 \u062A\u062D\u0648\u06CC\u0644 \u06AF\u0631\u0641\u062A\u0647 \u0634\u062F.`
    });
    return task;
  }
  /**
   * Set task to RUNNING (CLAIMED -> RUNNING)
   */
  startTaskExecution(taskId, worker) {
    const task = this.tasks.get(taskId);
    if (!task) return null;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const nowShamsi = WorkflowVerificationService.getInstance().getShamsiTimestamp();
    task.assignedWorker = worker;
    task.status = "RUNNING";
    task.startedAt = now;
    task.evidence.push({
      timestamp: now,
      timestampShamsi: nowShamsi,
      phase: "EXECUTION_STARTED",
      description: `\u0648\u0631\u06A9\u0631 ${worker} \u0627\u062C\u0631\u0627\u06CC \u062F\u0633\u062A\u0648\u0631\u0627\u062A \u062A\u0633\u06A9 \u0631\u0627 \u0628\u0647 \u0635\u0648\u0631\u062A \u0639\u0645\u0644\u06CC\u0627\u062A\u06CC \u0622\u063A\u0627\u0632 \u0646\u0645\u0648\u062F.`
    });
    return task;
  }
  /**
   * Mark task as COMPLETED or FAILED
   */
  finalizeTask(taskId, status, result, error) {
    const task = this.tasks.get(taskId);
    if (!task) return null;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const nowShamsi = WorkflowVerificationService.getInstance().getShamsiTimestamp();
    task.status = status;
    task.completedAt = now;
    task.result = result;
    task.error = error;
    task.evidence.push({
      timestamp: now,
      timestampShamsi: nowShamsi,
      phase: status === "COMPLETED" ? "TASK_COMPLETED" : status === "BLOCKED" ? "TASK_BLOCKED" : "TASK_FAILED",
      description: status === "COMPLETED" ? `\u062A\u0633\u06A9 ${taskId} \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u0648\u0633\u0637 \u0648\u0631\u06A9\u0631 ${task.assignedWorker || task.targetWorker} \u062A\u06A9\u0645\u06CC\u0644 \u0634\u062F.` : `\u062A\u0633\u06A9 \u0628\u0627 \u0648\u0636\u0639\u06CC\u062A ${status} \u062E\u0627\u062A\u0645\u0647 \u06CC\u0627\u0641\u062A. ${error || ""}`
    });
    return task;
  }
  /**
   * Resilient Switchover / Fallback:
   * When a worker is unresponsive or disconnected, switch to fallback worker
   * WITHOUT restarting the workflow from scratch!
   */
  switchoverTask(taskId, fallbackWorker, reason) {
    const task = this.tasks.get(taskId);
    if (!task) return null;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const nowShamsi = WorkflowVerificationService.getInstance().getShamsiTimestamp();
    const previousWorker = task.assignedWorker || task.targetWorker;
    task.targetWorker = fallbackWorker;
    task.assignedWorker = fallbackWorker;
    task.status = "CLAIMED";
    task.evidence.push({
      timestamp: now,
      timestampShamsi: nowShamsi,
      phase: "WORKER_SWITCHOVER",
      description: `\u0627\u0646\u062A\u0642\u0627\u0644 \u067E\u0627\u06CC\u062F\u0627\u0631 \u0627\u062C\u0631\u0627\u06CC \u062A\u0633\u06A9 \u0627\u0632 ${previousWorker} \u0628\u0647 ${fallbackWorker} \u0628\u0647 \u062F\u0644\u06CC\u0644: ${reason}. \u062C\u0631\u06CC\u0627\u0646 \u06A9\u0627\u0631 \u0627\u0632 \u0622\u062E\u0631\u06CC\u0646 \u0645\u0631\u062D\u0644\u0647 \u0645\u0648\u0641\u0642 \u0627\u062F\u0627\u0645\u0647 \u0645\u06CC\u200C\u06CC\u0627\u0628\u062F.`
    });
    return task;
  }
  /**
   * Get task by ID
   */
  getTask(taskId) {
    return this.tasks.get(taskId);
  }
  /**
   * List all tasks
   */
  getAllTasks() {
    return Array.from(this.tasks.values());
  }
};

// src/workflow/FormMappingEngine.ts
var FormMappingEngine = class {
  /**
   * Helper to inspect string attributes for keyword match
   */
  static matchesKeyword(descriptor, keywords) {
    const haystack = [
      descriptor.name || "",
      descriptor.id || "",
      descriptor.labelText || "",
      descriptor.placeholder || "",
      descriptor.ariaLabel || "",
      descriptor.type || ""
    ].join(" ").toLowerCase();
    return keywords.some((k) => haystack.includes(k.toLowerCase()));
  }
  /**
   * Discover and classify form elements
   */
  static discoverFormElements(htmlOrDom) {
    const discoveredAt = (/* @__PURE__ */ new Date()).toISOString();
    const elements = [];
    let isLoginForm = false;
    let isAdForm = false;
    if (typeof document !== "undefined" && htmlOrDom instanceof Document) {
      const inputs = Array.from(htmlOrDom.querySelectorAll("input, textarea, select, button"));
      inputs.forEach((el) => {
        const tagName = el.tagName.toLowerCase();
        const type = el.getAttribute("type") || (tagName === "textarea" ? "textarea" : tagName === "select" ? "select" : "text");
        const name = el.getAttribute("name") || "";
        const id = el.getAttribute("id") || "";
        const placeholder = el.getAttribute("placeholder") || "";
        const ariaLabel = el.getAttribute("aria-label") || "";
        const isRequired = el.hasAttribute("required") || el.getAttribute("aria-required") === "true";
        let labelText = "";
        if (id) {
          const labelEl = htmlOrDom.querySelector(`label[for="${id}"]`);
          if (labelEl) labelText = labelEl.textContent?.trim() || "";
        }
        if (!labelText && el.closest("label")) {
          labelText = el.closest("label")?.textContent?.trim() || "";
        }
        const selector = id ? `#${id}` : name ? `[name="${name}"]` : tagName;
        elements.push({
          selector,
          tagName,
          type,
          name,
          id,
          placeholder,
          ariaLabel,
          labelText,
          isRequired,
          currentValue: el.value || ""
        });
      });
    } else if (typeof htmlOrDom === "string") {
      const inputRegex = /<(input|textarea|select)[^>]*>/gi;
      let match;
      let counter = 0;
      while ((match = inputRegex.exec(htmlOrDom)) !== null) {
        counter++;
        const tagSnippet = match[0];
        const tagName = match[1].toLowerCase();
        const getAttr = (attr) => {
          const m = new RegExp(`${attr}\\s*=\\s*["']([^"']*)["']`, "i").exec(tagSnippet);
          return m ? m[1] : "";
        };
        const id = getAttr("id");
        const name = getAttr("name");
        const type = tagName === "textarea" ? "textarea" : tagName === "select" ? "select" : getAttr("type") || "text";
        const placeholder = getAttr("placeholder");
        const ariaLabel = getAttr("aria-label");
        const isRequired = /required/i.test(tagSnippet);
        let labelText = "";
        if (id) {
          const labelMatch = new RegExp(`<label[^>]*for=["']${id}["'][^>]*>([^<]+)<\\/label>`, "i").exec(htmlOrDom);
          if (labelMatch) labelText = labelMatch[1].trim();
        }
        elements.push({
          selector: id ? `#${id}` : name ? `[name="${name}"]` : `${tagName}:nth-of-type(${counter})`,
          tagName,
          type,
          name,
          id,
          placeholder,
          ariaLabel,
          labelText,
          isRequired
        });
      }
    }
    const hasAuthKeywords = elements.some(
      (e) => this.matchesKeyword(e, ["login", "signin", "password", "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631", "\u0648\u0631\u0648\u062F", "\u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F", "otp", "auth", "phone_number"])
    );
    const hasAdKeywords = elements.some(
      (e) => this.matchesKeyword(e, ["title", "\u0639\u0646\u0648\u0627\u0646", "description", "\u062A\u0648\u0636\u06CC\u062D\u0627\u062A", "\u0642\u06CC\u0645\u062A", "price", "category", "\u062F\u0633\u062A\u0647", "\u0639\u06A9\u0633", "image"])
    );
    if (hasAuthKeywords && !hasAdKeywords) {
      isLoginForm = true;
    } else if (hasAdKeywords) {
      isAdForm = true;
    }
    const metrics = {
      totalElements: elements.length,
      inputCount: elements.filter((e) => e.tagName === "input").length,
      textareaCount: elements.filter((e) => e.tagName === "textarea").length,
      selectCount: elements.filter((e) => e.tagName === "select").length,
      buttonCount: elements.filter((e) => e.tagName === "button" || e.type === "submit").length
    };
    return {
      formSelector: isLoginForm ? "form.auth-form" : "form.ad-post-form",
      isLoginForm,
      isAdForm,
      elements,
      metrics,
      discoveredAt
    };
  }
  /**
   * Map discovered DOM fields to campaign data
   * Evaluates required fields and reports empty required fields or validation errors.
   */
  static mapFormFields(elements, campaign) {
    const mappings = [];
    const emptyRequiredFields = [];
    const validationErrors = [];
    let mappedCount = 0;
    let filledCount = 0;
    const rules = [
      {
        campaignKey: "title",
        keywords: ["title", "\u0639\u0646\u0648\u0627\u0646", "\u0645\u0648\u0636\u0648\u0639", "ad-title"],
        valueExtractor: (c) => c.title,
        required: true,
        validator: (v) => ({ valid: Boolean(v && String(v).trim().length >= 4), error: "\u0639\u0646\u0648\u0627\u0646 \u0622\u06AF\u0647\u06CC \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F4 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F" })
      },
      {
        campaignKey: "description",
        keywords: ["description", "\u062A\u0648\u0636\u06CC\u062D\u0627\u062A", "\u0645\u062A\u0646 \u0622\u06AF\u0647\u06CC", "desc", "body"],
        valueExtractor: (c) => c.description,
        required: true,
        validator: (v) => ({ valid: Boolean(v && String(v).trim().length >= 10), error: "\u0645\u062A\u0646 \u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u0622\u06AF\u0647\u06CC \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F1\u06F0 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F" })
      },
      {
        campaignKey: "price",
        keywords: ["price", "\u0642\u06CC\u0645\u062A", "\u0627\u0631\u0632\u0634", "\u0645\u0628\u0644\u063A"],
        valueExtractor: (c) => c.price,
        required: false,
        validator: (v) => ({ valid: typeof v === "number" && v >= 0, error: "\u0645\u0628\u0644\u063A \u0628\u0627\u06CC\u062F \u0639\u062F\u062F\u06CC \u0646\u0627\u0645\u0646\u0641\u06CC \u0628\u0627\u0634\u062F" })
      },
      {
        campaignKey: "category",
        keywords: ["category", "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC", "\u062F\u0633\u062A\u0647", "\u06AF\u0631\u0648\u0647"],
        valueExtractor: (c) => c.category,
        required: true,
        validator: (v) => ({ valid: Boolean(v), error: "\u0627\u0646\u062A\u062E\u0627\u0628 \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A" })
      },
      {
        campaignKey: "city",
        keywords: ["city", "\u0634\u0647\u0631", "\u0627\u0633\u062A\u0627\u0646", "\u0645\u0648\u0642\u0639\u06CC\u062A"],
        valueExtractor: (c) => c.city,
        required: true,
        validator: (v) => ({ valid: Boolean(v), error: "\u0627\u0646\u062A\u062E\u0627\u0628 \u0634\u0647\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A" })
      },
      {
        campaignKey: "contactPhone",
        keywords: ["phone", "mobile", "\u0645\u0648\u0628\u0627\u06CC\u0644", "\u062A\u0644\u0641\u0646", "\u062A\u0645\u0627\u0633"],
        valueExtractor: (c) => c.contactPhone,
        required: true,
        validator: (v) => ({ valid: Boolean(v && /^(\+98|0)?9\d{9}$/.test(String(v).replace(/\s/g, ""))), error: "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0647\u0645\u0631\u0627\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" })
      }
    ];
    for (const rule of rules) {
      const matchedElem = elements.find((el) => this.matchesKeyword(el, rule.keywords));
      if (matchedElem) {
        mappedCount++;
        const val = rule.valueExtractor(campaign);
        let isValid = true;
        let errorReason;
        if (rule.validator) {
          const res = rule.validator(val);
          isValid = res.valid;
          errorReason = res.error;
        }
        if (isValid && (val !== void 0 && val !== null && val !== "")) {
          filledCount++;
        } else if (matchedElem.isRequired || rule.required) {
          emptyRequiredFields.push(rule.campaignKey);
          if (errorReason) validationErrors.push(errorReason);
        }
        mappings.push({
          campaignKey: rule.campaignKey,
          targetSelector: matchedElem.selector,
          fieldLabel: matchedElem.labelText || matchedElem.placeholder || matchedElem.name || rule.campaignKey,
          assignedValue: val,
          isValid,
          errorReason
        });
      } else if (rule.required) {
        emptyRequiredFields.push(`${rule.campaignKey} (\u0639\u062F\u0645 \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0641\u06CC\u0644\u062F \u062F\u0631 \u0641\u0631\u0645)`);
        validationErrors.push(`\u0641\u06CC\u0644\u062F \u0636\u0631\u0648\u0631\u06CC \xAB${rule.campaignKey}\xBB \u062F\u0631 \u0627\u0644\u0645\u0627\u0646\u200C\u0647\u0627\u06CC \u0641\u0631\u0645 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.`);
      }
    }
    return {
      foundFieldsCount: elements.length,
      mappedFieldsCount: mappedCount,
      filledFieldsCount: filledCount,
      emptyRequiredFields,
      validationErrors,
      mappings
    };
  }
};

// src/workflow/WorkflowEngine.ts
var WorkflowEngine = class {
  constructor() {
    this.coordinator = WorkerCoordinator.getInstance();
    this.verificationService = WorkflowVerificationService.getInstance();
  }
  recordPhase(state, phase, logMessage) {
    const now = /* @__PURE__ */ new Date();
    const iso = now.toISOString();
    const shamsi = this.verificationService.getShamsiTimestamp(now);
    state.currentPhase = phase;
    state.phaseTimestamps[phase] = { iso, shamsi };
    state.logs.push(`[${shamsi}] [${phase}] ${logMessage}`);
  }
  /**
   * Initialize a new End-to-End Workflow Execution
   */
  initializeWorkflow(campaign, targetPlatform = "Divar / B2B Industrial Ads", preferredWorker = "github_worker") {
    const identifiers = {
      workflowId: `wf-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
      executionId: `exec-${Date.now()}`,
      jobId: `job-ad-publish-${campaign.campaignId}`,
      actionId: `act-submit-${Date.now()}`
    };
    const initialAuthState = {
      isAuthenticated: false,
      requiresLogin: true,
      requiresRegistration: false,
      requiresOtp: false,
      pageUrl: `https://${targetPlatform.toLowerCase().replace(/[^a-z0-9]/g, "")}.ir/new`,
      evidence: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        timestampShamsi: this.verificationService.getShamsiTimestamp(),
        phase: "INIT",
        description: "\u06AF\u0631\u062F\u0634 \u06A9\u0627\u0631 \u0627\u0646\u062A\u0634\u0627\u0631 \u0622\u06AF\u0647\u06CC \u0645\u0642\u062F\u0627\u0631\u062F\u0647\u06CC \u0627\u0648\u0644\u06CC\u0647 \u0634\u062F."
      }
    };
    const initialOtpState = {
      isChallenged: false,
      status: "NONE",
      evidence: []
    };
    const state = {
      identifiers,
      campaign,
      targetPlatform,
      currentPhase: "INITIALIZED",
      activeWorker: preferredWorker,
      authState: initialAuthState,
      otpState: initialOtpState,
      phaseTimestamps: {},
      logs: []
    };
    this.recordPhase(state, "INITIALIZED", `\u06AF\u0631\u062F\u0634 \u06A9\u0627\u0631 \u0628\u0631\u0627\u06CC \u06A9\u0645\u067E\u06CC\u0646 \xAB${campaign.title}\xBB \u0631\u0648\u06CC \u067E\u0644\u062A\u0641\u0631\u0645 ${targetPlatform} \u0622\u063A\u0627\u0632 \u06AF\u0631\u062F\u06CC\u062F.`);
    return state;
  }
  /**
   * Phase 1 & 2: Evaluate Real Browser Authentication State
   */
  evaluateAuthentication(state, pageHtml, cookiesOrSession) {
    this.recordPhase(state, "LOGIN_CHECK", "\u0628\u0631\u0631\u0633\u06CC \u0648\u0636\u0639\u06CC\u062A \u0648\u0631\u0648\u062F \u0628\u0647 \u0633\u0627\u0645\u0627\u0646\u0647 \u0627\u0632 \u0645\u0631\u0648\u0631\u06AF\u0631 \u0648 \u0633\u0634\u0646...");
    const discovery = FormMappingEngine.discoverFormElements(pageHtml);
    state.formDiscovery = discovery;
    const hasAuthToken = Boolean(cookiesOrSession?.token || cookiesOrSession?.auth || cookiesOrSession?.sessionid);
    const userProfileFound = /class=["'][^"']*(?:user-profile|user-menu|dashboard-account|my-account)[^"']*["']/i.test(pageHtml);
    const hasActiveLoginForm = discovery.isLoginForm;
    if (hasAuthToken || userProfileFound && !hasActiveLoginForm) {
      state.authState.isAuthenticated = true;
      state.authState.requiresLogin = false;
      this.recordPhase(state, "AUTH_VERIFIED", "\u0648\u0636\u0639\u06CC\u062A \u06A9\u0627\u0631\u0628\u0631 \u0644\u0627\u06AF\u06CC\u0646\u200C\u0634\u062F\u0647 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F. \u0633\u0634\u0646 \u0648 \u0645\u0646\u0648\u06CC \u06A9\u0627\u0631\u0628\u0631\u06CC \u0641\u0639\u0627\u0644 \u0627\u0633\u062A.");
    } else {
      state.authState.isAuthenticated = false;
      state.authState.requiresLogin = true;
      const isRegistration = /ثبت‌نام|حساب کاربری جدید|register/i.test(pageHtml);
      if (isRegistration) {
        state.authState.requiresRegistration = true;
        this.recordPhase(state, "REGISTRATION_REQUIRED", "\u06A9\u0627\u0631\u0628\u0631 \u062F\u0631 \u067E\u0644\u062A\u0641\u0631\u0645 \u0639\u0636\u0648 \u0646\u06CC\u0633\u062A\u061B \u0646\u06CC\u0627\u0632 \u0628\u0647 \u062A\u06A9\u0645\u06CC\u0644 \u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0627\u0648\u0644\u06CC\u0647.");
      } else {
        this.recordPhase(state, "LOGIN_REQUIRED", "\u0641\u0631\u0645 \u0648\u0631\u0648\u062F \u062A\u0634\u062E\u06CC\u0635 \u062F\u0627\u062F\u0647 \u0634\u062F. \u062A\u0627 \u067E\u06CC\u0634 \u0627\u0632 \u0627\u062D\u0631\u0627\u0632 \u0647\u0648\u06CC\u062A\u060C \u0648\u0631\u0648\u062F \u0628\u0647 \u0641\u0631\u0645 \u0622\u06AF\u0647\u06CC \u0645\u062A\u0648\u0642\u0641 \u0627\u0633\u062A.");
      }
    }
    return state;
  }
  /**
   * Complete Login Step & Move to Ad Form
   */
  completeLogin(state, confirmedUserId, sessionToken) {
    state.authState.isAuthenticated = true;
    state.authState.currentUserId = confirmedUserId;
    state.authState.sessionToken = sessionToken;
    state.authState.requiresLogin = false;
    this.recordPhase(state, "AUTH_VERIFIED", `\u0648\u0631\u0648\u062F \u0628\u0627 \u0634\u0646\u0627\u0633\u0647 ${confirmedUserId} \u0628\u0647 \u0635\u0648\u0631\u062A \u0642\u0637\u0639\u06CC \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F.`);
    return state;
  }
  /**
   * Phase 3: Discover Ad Form and Map Campaign Fields
   */
  discoverAndMapAdForm(state, adPageHtml) {
    if (!state.authState.isAuthenticated) {
      this.recordPhase(state, "BLOCKED", "\u062E\u0637\u0627\u06CC \u062A\u0648\u0642\u0641: \u0627\u0645\u06A9\u0627\u0646 \u0648\u0631\u0648\u062F \u0628\u0647 \u0641\u0631\u0645 \u0622\u06AF\u0647\u06CC \u0642\u0628\u0644 \u0627\u0632 \u0627\u062D\u0631\u0627\u0632 \u0647\u0648\u06CC\u062A \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F.");
      return state;
    }
    this.recordPhase(state, "AD_FORM_DISCOVERY", "\u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0648 \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0641\u06CC\u0644\u062F\u0647\u0627\u06CC \u0641\u0631\u0645 \u062F\u0631\u062C \u0622\u06AF\u0647\u06CC \u0627\u0632 DOM \u0648\u0627\u0642\u0639\u06CC...");
    const discovery = FormMappingEngine.discoverFormElements(adPageHtml);
    state.formDiscovery = discovery;
    this.recordPhase(state, "FIELD_MAPPING", `\u0646\u06AF\u0627\u0634\u062A ${discovery.elements.length} \u0627\u0644\u0645\u0627\u0646 \u06CC\u0627\u0641\u062A\u0647\u200C\u0634\u062F\u0647 \u0628\u0647 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC \u06A9\u0645\u067E\u06CC\u0646...`);
    const mapping = FormMappingEngine.mapFormFields(discovery.elements, state.campaign);
    state.fieldMapping = mapping;
    this.recordPhase(
      state,
      "FORM_VALIDATION",
      `\u06AF\u0632\u0627\u0631\u0634 \u0641\u06CC\u0644\u062F\u0647\u0627: \u06CC\u0627\u0641\u062A\u0647\u200C\u0634\u062F\u0647: ${mapping.foundFieldsCount} | \u0646\u06AF\u0627\u0634\u062A\u200C\u0634\u062F\u0647: ${mapping.mappedFieldsCount} | \u067E\u0631\u0634\u062F\u0647: ${mapping.filledFieldsCount} | \u062E\u0637\u0627\u0647\u0627\u06CC \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC: ${mapping.validationErrors.length}`
    );
    if (mapping.emptyRequiredFields.length > 0 || mapping.validationErrors.length > 0) {
      const errList = [...mapping.emptyRequiredFields, ...mapping.validationErrors].join(", ");
      this.recordPhase(state, "FAILED", `\u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u0641\u0631\u0645 \u0645\u062A\u0648\u0642\u0641 \u0634\u062F. \u0641\u06CC\u0644\u062F\u0647\u0627\u06CC \u0636\u0631\u0648\u0631\u06CC \u062E\u0627\u0644\u06CC \u06CC\u0627 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: ${errList}`);
    } else {
      this.recordPhase(state, "FORM_FILLED", "\u062A\u0645\u0627\u0645\u06CC \u0641\u06CC\u0644\u062F\u0647\u0627\u06CC \u0636\u0631\u0648\u0631\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0646\u06AF\u0627\u0634\u062A \u0648 \u067E\u0631 \u0634\u062F\u0646\u062F. \u0622\u0645\u0627\u062F\u0647 \u0627\u0631\u0633\u0627\u0644.");
    }
    return state;
  }
  /**
   * Phase 5: Trigger OTP Challenge
   */
  triggerOtpChallenge(state, otpInputSelector = "#otp-input", expirySeconds = 120) {
    const now = /* @__PURE__ */ new Date();
    const iso = now.toISOString();
    const shamsi = this.verificationService.getShamsiTimestamp(now);
    state.otpState = {
      isChallenged: true,
      status: "OTP_REQUESTED",
      otpInputSelector,
      expirySeconds,
      requestedAt: iso,
      evidence: [
        {
          timestamp: iso,
          timestampShamsi: shamsi,
          phase: "OTP_REQUESTED",
          description: `\u0686\u0627\u0644\u0634 OTP \u0641\u0639\u0627\u0644 \u06AF\u0631\u062F\u06CC\u062F. \u067E\u06CC\u0627\u0645\u06A9 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F \u0648 \u0648\u0631\u0648\u062F\u06CC ${otpInputSelector} \u0645\u0646\u062A\u0638\u0631 \u06A9\u062F \u0627\u0633\u062A.`
        }
      ]
    };
    this.recordPhase(state, "AWAITING_OTP", `\u0633\u0627\u0645\u0627\u0646\u0647 \u0646\u06CC\u0627\u0632\u0645\u0646\u062F \u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F \u06CC\u06A9\u0628\u0627\u0631\u0645\u0635\u0631\u0641 \u0627\u0633\u062A. \u0645\u0647\u0644\u062A \u0627\u0646\u0642\u0636\u0627: ${expirySeconds} \u062B\u0627\u0646\u06CC\u0647.`);
    return state;
  }
  /**
   * Submit OTP Code and Verify Acceptance
   */
  submitAndVerifyOtp(state, code, isAcceptedByServer) {
    const now = /* @__PURE__ */ new Date();
    const iso = now.toISOString();
    const shamsi = this.verificationService.getShamsiTimestamp(now);
    state.otpState.code = code;
    state.otpState.submittedAt = iso;
    state.otpState.status = "OTP_SUBMITTED";
    state.otpState.evidence.push({
      timestamp: iso,
      timestampShamsi: shamsi,
      phase: "OTP_SUBMITTED",
      description: `\u06A9\u062F \u06CC\u06A9\u0628\u0627\u0631\u0645\u0635\u0631\u0641 \u0648\u0627\u0631\u062F \u06AF\u0631\u062F\u06CC\u062F \u0648 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0627\u06CC\u06CC\u062F \u0628\u0647 \u0633\u0631\u0648\u0631 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F.`
    });
    if (isAcceptedByServer) {
      state.otpState.status = "OTP_VERIFIED";
      state.otpState.verifiedAt = iso;
      state.otpState.isChallenged = false;
      state.otpState.evidence.push({
        timestamp: iso,
        timestampShamsi: shamsi,
        phase: "OTP_VERIFIED",
        description: "\u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F \u062A\u0648\u0633\u0637 \u0633\u0631\u0648\u0631 \u067E\u0630\u06CC\u0631\u0641\u062A\u0647 \u0634\u062F \u0648 \u0645\u0627\u0646\u0639 \u0627\u062D\u0631\u0627\u0632 \u0647\u0648\u06CC\u062A \u0628\u0631\u0637\u0631\u0641 \u06AF\u0631\u062F\u06CC\u062F."
      });
      this.recordPhase(state, "SUBMISSION_PENDING", "\u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F \u067E\u0630\u06CC\u0631\u0641\u062A\u0647 \u0634\u062F. \u0622\u0645\u0627\u062F\u0647 \u06A9\u0644\u06CC\u06A9 \u0628\u0631 \u062F\u06A9\u0645\u0647 \u0627\u0646\u062A\u0634\u0627\u0631 \u0622\u06AF\u0647\u06CC.");
    } else {
      state.otpState.status = "REJECTED";
      this.recordPhase(state, "FAILED", "\u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F \u062A\u0648\u0633\u0637 \u067E\u0644\u062A\u0641\u0631\u0645 \u0631\u062F \u0634\u062F \u06CC\u0627 \u0645\u0646\u0642\u0636\u06CC \u06AF\u0631\u062F\u06CC\u062F\u0647 \u0627\u0633\u062A.");
    }
    return state;
  }
  /**
   * Submit Ad Form and Collect Platform Result
   */
  submitAdForm(state, clickSucceeded, rawResponse) {
    if (state.currentPhase === "AWAITING_OTP" || state.otpState.isChallenged) {
      this.recordPhase(state, "BLOCKED", "\u062E\u0637\u0627: \u0627\u0645\u06A9\u0627\u0646 \u0627\u0631\u0633\u0627\u0644 \u0641\u0631\u0645 \u0642\u0628\u0644 \u0627\u0632 \u062A\u06A9\u0645\u06CC\u0644 \u0645\u0648\u0641\u0642 \u0686\u0627\u0644\u0634 OTP \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F.");
      return state;
    }
    if (!state.fieldMapping || state.fieldMapping.emptyRequiredFields.length > 0) {
      this.recordPhase(state, "FAILED", "\u062E\u0637\u0627: \u0641\u06CC\u0644\u062F\u0647\u0627\u06CC \u0636\u0631\u0648\u0631\u06CC \u062A\u06A9\u0645\u06CC\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u062F\u06A9\u0645\u0647 \u0627\u0631\u0633\u0627\u0644 \u06A9\u0644\u06CC\u06A9 \u0646\u062E\u0648\u0627\u0647\u062F \u0634\u062F.");
      return state;
    }
    this.recordPhase(state, "SUBMISSION_CLICKED", "\u062F\u06A9\u0645\u0647 \u0627\u0631\u0633\u0627\u0644 \u0622\u06AF\u0647\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0641\u0634\u0631\u062F\u0647 \u0634\u062F. \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E \u067E\u0644\u062A\u0641\u0631\u0645...");
    const extracted = this.verificationService.extractAdLinkFromResponse(rawResponse);
    state.submissionResult = {
      submitClicked: clickSucceeded,
      responsePayload: rawResponse,
      rawAdUrl: extracted?.url,
      rawAdId: extracted?.adId
    };
    if (extracted?.url) {
      this.recordPhase(state, "VERIFICATION_PENDING", `\u0622\u062F\u0631\u0633 \u062E\u0627\u0645 \u0622\u06AF\u0647\u06CC \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06AF\u0631\u062F\u06CC\u062F: ${extracted.url}. \u0634\u0631\u0648\u0639 \u062A\u0637\u0628\u06CC\u0642 \u0646\u0647\u0627\u06CC\u06CC...`);
    } else {
      this.recordPhase(state, "UNKNOWN", "\u067E\u0627\u0633\u062E \u0627\u0631\u0633\u0627\u0644 \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F \u0627\u0645\u0627 \u0644\u06CC\u0646\u06A9 \u0645\u0639\u062A\u0628\u0631\u06CC \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0646\u06AF\u0631\u062F\u06CC\u062F.");
    }
    return state;
  }
  /**
   * Phase 6: Final Verification against Real Public Ad Page
   */
  async performFinalVerification(state, publicPageHtml, httpStatus = 200) {
    const rawUrl = state.submissionResult?.rawAdUrl;
    const rawId = state.submissionResult?.rawAdId;
    const verification = await this.verificationService.verifyAd({
      adUrl: rawUrl,
      adId: rawId,
      expectedTitle: state.campaign.title,
      campaignId: state.campaign.campaignId,
      platformName: state.targetPlatform,
      htmlContent: publicPageHtml,
      pageStatus: httpStatus
    });
    state.verificationResult = verification;
    if (verification.status === "PUBLISHED") {
      this.recordPhase(
        state,
        "PUBLISHED",
        `\u0627\u0646\u062A\u0634\u0627\u0631 \u0642\u0637\u0639\u06CC \u0628\u0627 \u0627\u0645\u062A\u06CC\u0627\u0632 ${verification.verificationScore}% \u0627\u062D\u0631\u0627\u0632 \u0634\u062F! \u0644\u06CC\u0646\u06A9 \u0639\u0645\u0648\u0645\u06CC: ${verification.adUrl}`
      );
    } else {
      this.recordPhase(
        state,
        verification.status,
        `\u0648\u0636\u0639\u06CC\u062A \u0646\u0647\u0627\u06CC\u06CC ${verification.status} \u062B\u0628\u062A \u0634\u062F. \u062F\u0644\u0627\u06CC\u0644: ${verification.evidenceReasons.join(" | ")}`
      );
    }
    return state;
  }
};

// src/workflow/workflowRouter.ts
var router = (0, import_express.Router)();
var coordinator = WorkerCoordinator.getInstance();
var verificationService = WorkflowVerificationService.getInstance();
var engine = new WorkflowEngine();
var activeWorkflows = /* @__PURE__ */ new Map();
router.post("/start", (req, res) => {
  try {
    const { campaign, platform, preferredWorker } = req.body;
    if (!campaign || !campaign.title) {
      return res.status(400).json({ error: "campaign object with title is required" });
    }
    const state = engine.initializeWorkflow(
      campaign,
      platform || "Divar / B2B Industrial Ads",
      preferredWorker || "github_worker"
    );
    const task = coordinator.queueTask(
      "ashk24-worker-task",
      state.activeWorker,
      state.identifiers,
      { campaign: state.campaign, platform: state.targetPlatform }
    );
    state.currentTaskId = task.taskId;
    activeWorkflows.set(state.identifiers.workflowId, state);
    res.json({
      success: true,
      workflowId: state.identifiers.workflowId,
      executionId: state.identifiers.executionId,
      taskId: task.taskId,
      status: state.currentPhase,
      identifiers: state.identifiers
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.post("/worker-callback", (req, res) => {
  try {
    const { status, taskId, identifiers, startedAt, completedAt, jobStatus, error } = req.body;
    if (!taskId) {
      return res.status(400).json({ error: "taskId is required" });
    }
    if (status === "TASK_ACCEPTED") {
      coordinator.claimTask(taskId, "github_worker");
    } else if (status === "EXECUTION_STARTED") {
      coordinator.startTaskExecution(taskId, "github_worker");
    } else if (status === "TASK_COMPLETED") {
      coordinator.finalizeTask(taskId, "COMPLETED", { jobStatus, completedAt });
    } else if (status === "TASK_FAILED") {
      coordinator.finalizeTask(taskId, "FAILED", { jobStatus }, error || "Execution failed in runner");
    }
    res.json({ success: true, taskId, receivedStatus: status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.post("/verify", async (req, res) => {
  try {
    const { adUrl, adId, expectedTitle, campaignId, platformName, htmlContent, pageStatus } = req.body;
    const result = await verificationService.verifyAd({
      adUrl,
      adId,
      expectedTitle,
      campaignId: campaignId || "cmp-default",
      platformName: platformName || "Industrial Portal",
      htmlContent,
      pageStatus: pageStatus || 200
    });
    res.json({ success: true, verification: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.get("/tasks", (req, res) => {
  res.json({
    tasks: coordinator.getAllTasks()
  });
});
router.post("/tasks/claim", (req, res) => {
  try {
    const { taskId, workerType } = req.body;
    const task = coordinator.claimTask(taskId, workerType || "extension_worker");
    if (!task) {
      return res.status(404).json({ error: "Task not found or unavailable" });
    }
    res.json({ success: true, task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.get("/status/:workflowId", (req, res) => {
  const wf = activeWorkflows.get(req.params.workflowId);
  if (!wf) {
    return res.status(404).json({ error: "Workflow not found" });
  }
  res.json({ workflow: wf });
});
var workflowRouter_default = router;

// src/api/index.ts
var router2 = (0, import_express2.Router)();
router2.use("/workflow", workflowRouter_default);
router2.post("/generate", async (req, res) => {
  try {
    const { templateId, params, format } = req.body;
    const template = globalRegistry.getTemplate(templateId);
    if (!template) {
      return res.status(404).json({ error: "Template not found" });
    }
    const ruleEngine = new RuleEngine();
    const evaluatedParams = ruleEngine.evaluate(params);
    const engine2 = await globalRegistry.loadEngineDynamically(template.engine);
    const primitives = engine2(evaluatedParams);
    if (format === "svg") {
      const exporter = new SVGExporter();
      const svg = exporter.export(primitives);
      return res.type("svg").send(svg);
    }
    return res.json({ primitives });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
var api_default = router2;

// server.ts
var _dirname = process.cwd();
async function startServer() {
  const app = (0, import_express3.default)();
  const PORT = 3e3;
  app.use((0, import_cors.default)());
  app.use(import_express3.default.json({ limit: "50mb" }));
  app.use(import_express3.default.urlencoded({ limit: "50mb", extended: true }));
  app.use("/api", api_default);
  app.use("/", api_default);
  const uploadsDir = import_path.default.join(_dirname, "public", "uploads");
  if (!import_fs.default.existsSync(uploadsDir)) {
    import_fs.default.mkdirSync(uploadsDir, { recursive: true });
  }
  app.use("/uploads", import_express3.default.static(uploadsDir, {
    maxAge: "30d",
    setHeaders: (res) => {
      res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
    }
  }));
  const mediaDir = import_path.default.join(_dirname, "public", "media");
  if (!import_fs.default.existsSync(mediaDir)) {
    import_fs.default.mkdirSync(mediaDir, { recursive: true });
  }
  app.use("/media", import_express3.default.static(mediaDir, {
    maxAge: "30d",
    setHeaders: (res) => {
      res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
    }
  }));
  const downloadsDir = import_path.default.join(_dirname, "public", "downloads");
  if (!import_fs.default.existsSync(downloadsDir)) {
    import_fs.default.mkdirSync(downloadsDir, { recursive: true });
  }
  app.use("/downloads", import_express3.default.static(downloadsDir));
  const { S3Client, PutObjectCommand, GetObjectCommand } = await import("@aws-sdk/client-s3");
  const { getSignedUrl } = await import("@aws-sdk/s3-request-presigner");
  const s3Endpoint = process.env.S3_ENDPOINT || "";
  const isS3Enabled = !!s3Endpoint;
  let s3Client = null;
  if (isS3Enabled) {
    s3Client = new S3Client({
      region: process.env.S3_REGION || "us-east-1",
      endpoint: s3Endpoint,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY || "minioadmin",
        secretAccessKey: process.env.S3_SECRET_KEY || "minioadmin"
      },
      forcePathStyle: true
      // Needed for MinIO
    });
  }
  const localStorageOption = import_multer.default.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      let ext = import_path.default.extname(file.originalname).toLowerCase();
      if (!ext || ext === ".img" || ext === ".blob") {
        if (file.mimetype === "image/jpeg") ext = ".jpg";
        else if (file.mimetype === "image/png") ext = ".png";
        else if (file.mimetype === "image/webp") ext = ".webp";
        else if (file.mimetype === "image/gif") ext = ".gif";
        else ext = ".jpg";
      }
      cb(null, file.fieldname + "-" + uniqueSuffix + ext);
    }
  });
  const localUpload = (0, import_multer.default)({ storage: localStorageOption });
  let upload;
  let s3Upload = null;
  if (isS3Enabled) {
    try {
      const multerS3 = (await import("multer-s3")).default;
      s3Upload = (0, import_multer.default)({
        storage: multerS3({
          s3: s3Client,
          bucket: process.env.S3_BUCKET || "ashk-ghalam-enterprise",
          key: function(req, file, cb) {
            const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
            let ext = import_path.default.extname(file.originalname).toLowerCase();
            if (!ext || ext === ".img" || ext === ".blob") {
              if (file.mimetype === "image/jpeg") ext = ".jpg";
              else if (file.mimetype === "image/png") ext = ".png";
              else if (file.mimetype === "image/webp") ext = ".webp";
              else if (file.mimetype === "image/gif") ext = ".gif";
              else ext = ".jpg";
            }
            cb(null, file.fieldname + "-" + uniqueSuffix + ext);
          }
        })
      });
      upload = s3Upload;
    } catch (e) {
      console.error("Failed to initialize S3 upload storage, using local fallback only:", e);
      upload = localUpload;
    }
  } else {
    upload = localUpload;
  }
  const backupsDir = import_path.default.join(_dirname, "backups");
  if (!import_fs.default.existsSync(backupsDir)) {
    import_fs.default.mkdirSync(backupsDir, { recursive: true });
  }
  function getMediaFilesPack() {
    const mediaFiles = [];
    try {
      if (import_fs.default.existsSync(uploadsDir)) {
        const files = import_fs.default.readdirSync(uploadsDir);
        for (const file of files) {
          const filePath = import_path.default.join(uploadsDir, file);
          const stat = import_fs.default.statSync(filePath);
          if (stat.isFile()) {
            if (stat.size > 5 * 1024 * 1024) {
              console.warn(`Skipping large file in base64 serialization: ${file} (${stat.size} bytes)`);
              continue;
            }
            const fileBuffer = import_fs.default.readFileSync(filePath);
            mediaFiles.push({
              filename: file,
              base64: fileBuffer.toString("base64")
            });
          }
        }
      }
    } catch (err) {
      console.error("Failed to pack uploads:", err);
    }
    return mediaFiles;
  }
  function restoreMediaFilesPack(mediaFiles) {
    if (!Array.isArray(mediaFiles)) return;
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      for (const fileItem of mediaFiles) {
        if (fileItem.filename && fileItem.base64) {
          const destPath = import_path.default.join(uploadsDir, fileItem.filename);
          const resolvedPath = import_path.default.resolve(destPath);
          if (resolvedPath.startsWith(uploadsDir)) {
            const fileBuffer = Buffer.from(fileItem.base64, "base64");
            import_fs.default.writeFileSync(resolvedPath, fileBuffer);
          }
        }
      }
    } catch (err) {
      console.error("Failed to restore packaged uploads:", err);
    }
  }
  app.post("/api/backup/save", (req, res) => {
    try {
      const payload = req.body;
      if (!payload || typeof payload !== "object") {
        return res.status(400).json({ error: "Invalid backup payload" });
      }
      const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
      const filename = `backup_${stamp}.json`;
      const filePath = import_path.default.join(backupsDir, filename);
      const mediaFiles = getMediaFilesPack();
      const completeBackup = { ...payload, mediaFiles };
      import_fs.default.writeFileSync(filePath, JSON.stringify(completeBackup, null, 2), "utf8");
      res.json({ success: true, filename });
    } catch (err) {
      res.status(500).json({ error: "Failed to save backup on server: " + err.message });
    }
  });
  app.post("/api/backup/export", (req, res) => {
    try {
      const payload = req.body;
      if (!payload || typeof payload !== "object") {
        return res.status(400).json({ error: "Invalid payload" });
      }
      const mediaFiles = getMediaFilesPack();
      const completeBackup = { ...payload, mediaFiles };
      res.json(completeBackup);
    } catch (err) {
      res.status(500).json({ error: "Failed to compile export package: " + err.message });
    }
  });
  app.post("/api/backup/import", (req, res) => {
    try {
      const payload = req.body;
      if (!payload || typeof payload !== "object") {
        return res.status(400).json({ error: "Invalid backup cargo" });
      }
      if (payload.mediaFiles) {
        restoreMediaFilesPack(payload.mediaFiles);
      }
      res.json({ success: true, count: payload.mediaFiles ? payload.mediaFiles.length : 0 });
    } catch (err) {
      res.status(500).json({ error: "Failed to restore content items on host: " + err.message });
    }
  });
  function getCatalogMediaFilesPack(catalogs) {
    const catalogMedia = [];
    if (!Array.isArray(catalogs) || catalogs.length === 0) return catalogMedia;
    const referencedFiles = /* @__PURE__ */ new Set();
    catalogs.forEach((cat) => {
      const checkAndAdd = (url) => {
        if (!url || typeof url !== "string") return;
        const cleaned = url.replace(/^\/?uploads\//, "").replace(/^\//, "");
        if (cleaned && !cleaned.startsWith("data:") && !cleaned.startsWith("http")) {
          referencedFiles.add(cleaned);
        }
      };
      checkAndAdd(cat.coverImage);
      checkAndAdd(cat.thumbnailUrl);
      checkAndAdd(cat.pdfUrl);
      if (Array.isArray(cat.pages)) {
        cat.pages.forEach((p) => {
          checkAndAdd(p.imageUrl);
          checkAndAdd(p.thumbnailUrl);
        });
      }
    });
    try {
      if (import_fs.default.existsSync(uploadsDir)) {
        const diskFiles = import_fs.default.readdirSync(uploadsDir);
        for (const filename of diskFiles) {
          const isCatalogFile = referencedFiles.has(filename) || filename.startsWith("cover_") || filename.startsWith("thumb_") || filename.startsWith("p_") || filename.startsWith("pt_") || filename.startsWith("catalog_");
          if (isCatalogFile) {
            const filePath = import_path.default.join(uploadsDir, filename);
            const stat = import_fs.default.statSync(filePath);
            if (stat.isFile() && stat.size <= 8 * 1024 * 1024) {
              const fileBuffer = import_fs.default.readFileSync(filePath);
              catalogMedia.push({
                filename,
                base64: fileBuffer.toString("base64")
              });
            }
          }
        }
      }
    } catch (err) {
      console.error("Error gathering catalog media pack:", err);
    }
    return catalogMedia;
  }
  app.all(["/api/backup/catalogs-and-settings/export", "/api/backup/catalogs-settings/export"], (req, res) => {
    try {
      let serverCatalogs = [];
      const catalogsFilePath2 = import_path.default.join(uploadsDir, "custom_catalogs.json");
      if (import_fs.default.existsSync(catalogsFilePath2)) {
        try {
          serverCatalogs = JSON.parse(import_fs.default.readFileSync(catalogsFilePath2, "utf8"));
        } catch (e) {
          console.error("Error reading custom_catalogs.json", e);
        }
      }
      let serverSettings = {};
      const settingsFilePath2 = import_path.default.join(uploadsDir, "global_settings.json");
      if (import_fs.default.existsSync(settingsFilePath2)) {
        try {
          serverSettings = JSON.parse(import_fs.default.readFileSync(settingsFilePath2, "utf8"));
        } catch (e) {
          console.error("Error reading global_settings.json", e);
        }
      }
      const clientPayload = req.body || {};
      const finalCatalogs = clientPayload.catalogs && Array.isArray(clientPayload.catalogs) && clientPayload.catalogs.length > 0 ? clientPayload.catalogs : serverCatalogs;
      const finalSettings = {
        ...serverSettings,
        ...clientPayload.globalSettings || {},
        pricingFormula: clientPayload.pricingFormula || serverSettings.pricingFormula,
        siteContent: clientPayload.siteContent || serverSettings.siteContent,
        seoConfigs: clientPayload.seoConfigs || serverSettings.seoConfigs,
        b2bSettings: clientPayload.b2bSettings || serverSettings.b2bSettings
      };
      const catalogMedia = getCatalogMediaFilesPack(finalCatalogs);
      const now = /* @__PURE__ */ new Date();
      const shamsiDateStr = new Intl.DateTimeFormat("fa-IR", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      }).format(now);
      const timestamp = now.getTime();
      const payloadData = {
        type: "ASHK_GHALAM_ACTIVE_CATALOGS_AND_SETTINGS_BACKUP",
        version: "2.10.0",
        createdAt: now.toISOString(),
        createdAtShamsi: shamsiDateStr,
        generator: "Ashk Ghalam Industrial CAD Studio Migration Engine",
        stats: {
          catalogsCount: finalCatalogs.length,
          catalogPagesCount: finalCatalogs.reduce((acc, c) => acc + (c.pages?.length || 0), 0),
          catalogMediaCount: catalogMedia.length,
          hasGlobalSettings: Object.keys(finalSettings).length > 0
        },
        data: {
          catalogs: finalCatalogs,
          settings: finalSettings,
          catalogMedia
        }
      };
      const dataHash = import_crypto.default.createHash("sha256").update(JSON.stringify(payloadData.data)).digest("hex");
      const completePackage = {
        ...payloadData,
        sha256Hash: dataHash
      };
      const backupSavePath = import_path.default.join(backupsDir, `catalogs_settings_backup_${timestamp}.json`);
      import_fs.default.writeFileSync(backupSavePath, JSON.stringify(completePackage, null, 2), "utf8");
      res.setHeader("Content-Disposition", `attachment; filename="ashk_catalogs_settings_backup_${timestamp}.json"`);
      res.json(completePackage);
    } catch (err) {
      console.error("Error in catalogs-settings export:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0628\u0633\u062A\u0647 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0641\u0639\u0627\u0644: " + err.message });
    }
  });
  app.post(["/api/backup/catalogs-and-settings/restore-migrate", "/api/backup/catalogs-settings/restore-migrate"], (req, res) => {
    try {
      const packageCargo = req.body;
      if (!packageCargo || !packageCargo.data) {
        return res.status(400).json({ error: "\u0642\u0627\u0644\u0628 \u0641\u0627\u06CC\u0644 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A \u06CC\u0627 \u0641\u0627\u0642\u062F \u0628\u062E\u0634 \u062F\u0627\u062F\u0647 (data) \u0645\u06CC\u200C\u0628\u0627\u0634\u062F." });
      }
      const { data, sha256Hash } = packageCargo;
      const { catalogs, settings, catalogMedia } = data;
      const mergeMode = req.query.mode === "replace" ? "replace" : "merge";
      if (sha256Hash) {
        const calculatedHash = import_crypto.default.createHash("sha256").update(JSON.stringify(data)).digest("hex");
        if (calculatedHash !== sha256Hash) {
          console.warn("Notice: Hash mismatch in migration package, proceeding with data tolerance check.");
        }
      }
      const timestamp = Date.now();
      const preMigrationSnapshotPath = import_path.default.join(backupsDir, `pre_migration_snapshot_${timestamp}.json`);
      const currentServerState = {};
      const catalogsFilePath2 = import_path.default.join(uploadsDir, "custom_catalogs.json");
      const settingsFilePath2 = import_path.default.join(uploadsDir, "global_settings.json");
      if (import_fs.default.existsSync(catalogsFilePath2)) {
        try {
          currentServerState.catalogs = JSON.parse(import_fs.default.readFileSync(catalogsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      if (import_fs.default.existsSync(settingsFilePath2)) {
        try {
          currentServerState.settings = JSON.parse(import_fs.default.readFileSync(settingsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      import_fs.default.writeFileSync(preMigrationSnapshotPath, JSON.stringify(currentServerState, null, 2), "utf8");
      let restoredMediaCount = 0;
      if (Array.isArray(catalogMedia) && catalogMedia.length > 0) {
        if (!import_fs.default.existsSync(uploadsDir)) {
          import_fs.default.mkdirSync(uploadsDir, { recursive: true });
        }
        for (const fileItem of catalogMedia) {
          if (fileItem.filename && fileItem.base64) {
            const destPath = import_path.default.join(uploadsDir, fileItem.filename);
            const resolvedPath = import_path.default.resolve(destPath);
            if (resolvedPath.startsWith(uploadsDir)) {
              const fileBuffer = Buffer.from(fileItem.base64, "base64");
              import_fs.default.writeFileSync(resolvedPath, fileBuffer);
              restoredMediaCount++;
            }
          }
        }
      }
      let finalCatalogs = [];
      if (Array.isArray(catalogs)) {
        if (mergeMode === "replace") {
          finalCatalogs = catalogs;
        } else {
          const existingCatalogs = currentServerState.catalogs || [];
          const importedIds = new Set(catalogs.map((c) => String(c.id)));
          finalCatalogs = [
            ...catalogs,
            ...existingCatalogs.filter((c) => !importedIds.has(String(c.id)))
          ];
        }
        if (!import_fs.default.existsSync(uploadsDir)) {
          import_fs.default.mkdirSync(uploadsDir, { recursive: true });
        }
        import_fs.default.writeFileSync(catalogsFilePath2, JSON.stringify(finalCatalogs, null, 2), "utf8");
      }
      let finalSettings = currentServerState.settings || {};
      if (settings && typeof settings === "object") {
        if (mergeMode === "replace") {
          finalSettings = settings;
        } else {
          finalSettings = {
            ...finalSettings,
            ...settings
          };
        }
        if (!import_fs.default.existsSync(uploadsDir)) {
          import_fs.default.mkdirSync(uploadsDir, { recursive: true });
        }
        import_fs.default.writeFileSync(settingsFilePath2, JSON.stringify(finalSettings, null, 2), "utf8");
      }
      console.log(`[Migration Success] Restored ${finalCatalogs.length} catalogs, ${restoredMediaCount} media files, and global settings to updated site.`);
      res.json({
        success: true,
        message: "\u0627\u0646\u062A\u0642\u0627\u0644 \u0648 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0641\u0639\u0627\u0644 \u0628\u0647 \u0633\u0627\u06CC\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u06A9\u0627\u0645\u0644 \u0627\u0646\u062C\u0627\u0645 \u06AF\u0631\u062F\u06CC\u062F.",
        mergeMode,
        restoredStats: {
          catalogsCount: finalCatalogs.length,
          restoredMediaCount,
          settingsKeys: Object.keys(finalSettings)
        },
        restoredData: {
          catalogs: finalCatalogs,
          settings: finalSettings
        },
        preMigrationBackup: `pre_migration_snapshot_${timestamp}.json`
      });
    } catch (err) {
      console.error("Error in catalogs-settings restore-migrate:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0648 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0628\u0647 \u0633\u0627\u06CC\u062A: " + err.message });
    }
  });
  app.all(["/api/backup/full-system/export"], (req, res) => {
    try {
      if (!import_fs.default.existsSync(uploadsDir)) import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      if (!import_fs.default.existsSync(backupsDir)) import_fs.default.mkdirSync(backupsDir, { recursive: true });
      let catalogs = [];
      const catalogsFilePath2 = import_path.default.join(uploadsDir, "custom_catalogs.json");
      if (import_fs.default.existsSync(catalogsFilePath2)) {
        try {
          catalogs = JSON.parse(import_fs.default.readFileSync(catalogsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      let globalSettings = {};
      const settingsFilePath2 = import_path.default.join(uploadsDir, "global_settings.json");
      if (import_fs.default.existsSync(settingsFilePath2)) {
        try {
          globalSettings = JSON.parse(import_fs.default.readFileSync(settingsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      const softwareProducts = getSoftwareProductsData();
      const softwareLicenses = getSoftwareLicensesData();
      const clientPayload = req.body || {};
      if (clientPayload.catalogs && Array.isArray(clientPayload.catalogs) && clientPayload.catalogs.length > 0) {
        catalogs = clientPayload.catalogs;
      }
      if (clientPayload.globalSettings && typeof clientPayload.globalSettings === "object") {
        globalSettings = { ...globalSettings, ...clientPayload.globalSettings };
      }
      const mediaFiles = getMediaFilesPack();
      const now = /* @__PURE__ */ new Date();
      const shamsiDateStr = new Intl.DateTimeFormat("fa-IR", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      }).format(now);
      const timestamp = now.getTime();
      const backupPackage = {
        packageType: "ASHK_GHALAM_FULL_SYSTEM_RECOVERABLE_ARCHIVE",
        version: "3.1.0",
        createdAt: now.toISOString(),
        createdAtShamsi: shamsiDateStr,
        generator: "Ashk Ghalam Industrial CAD Studio v3.1 Backup Engine",
        stats: {
          catalogsCount: catalogs.length,
          softwareProductsCount: softwareProducts.length,
          softwareLicensesCount: softwareLicenses.length,
          mediaFilesCount: mediaFiles.length,
          hasGlobalSettings: Object.keys(globalSettings).length > 0,
          hasSiteContent: !!(clientPayload.siteContent || globalSettings.siteContent)
        },
        data: {
          globalSettings,
          siteContent: clientPayload.siteContent || globalSettings.siteContent || {},
          pricingFormula: clientPayload.pricingFormula || globalSettings.pricingFormula || {},
          seoConfigs: clientPayload.seoConfigs || globalSettings.seoConfigs || [],
          emergencyConfig: clientPayload.emergencyConfig || globalSettings.emergencyConfig || {},
          catalogs,
          softwareProducts,
          softwareLicenses,
          b2bSettings: clientPayload.b2bSettings || {},
          mediaFiles
        }
      };
      const sha256 = import_crypto.default.createHash("sha256").update(JSON.stringify(backupPackage.data)).digest("hex");
      backupPackage.sha256Hash = sha256;
      const localBackupFilename = `full_system_backup_${timestamp}.json`;
      const localBackupFilePath = import_path.default.join(backupsDir, localBackupFilename);
      import_fs.default.writeFileSync(localBackupFilePath, JSON.stringify(backupPackage, null, 2), "utf8");
      res.setHeader("Content-Disposition", `attachment; filename="ashk_full_system_backup_${timestamp}.json"`);
      res.json(backupPackage);
    } catch (err) {
      console.error("Full system export failed:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062A\u0647\u06CC\u0647 \u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u062C\u0627\u0645\u0639: " + err.message });
    }
  });
  app.post(["/api/backup/full-system/restore"], (req, res) => {
    try {
      const packageCargo = req.body;
      if (!packageCargo || !packageCargo.data) {
        return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0641\u0627\u0642\u062F \u0633\u0627\u062E\u062A\u0627\u0631 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u062F\u0627\u062F\u0647 (data) \u0645\u06CC\u200C\u0628\u0627\u0634\u062F." });
      }
      const { data } = packageCargo;
      const {
        globalSettings,
        siteContent,
        pricingFormula,
        seoConfigs,
        emergencyConfig,
        catalogs,
        softwareProducts,
        softwareLicenses,
        mediaFiles,
        b2bSettings
      } = data;
      const mergeMode = req.query.mode === "replace" ? "replace" : "merge";
      const timestamp = Date.now();
      if (!import_fs.default.existsSync(backupsDir)) import_fs.default.mkdirSync(backupsDir, { recursive: true });
      if (!import_fs.default.existsSync(uploadsDir)) import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      const preRestoreSnapshotPath = import_path.default.join(backupsDir, `pre_full_restore_snapshot_${timestamp}.json`);
      const currentSnapshot = {};
      const catalogsFilePath2 = import_path.default.join(uploadsDir, "custom_catalogs.json");
      const settingsFilePath2 = import_path.default.join(uploadsDir, "global_settings.json");
      if (import_fs.default.existsSync(catalogsFilePath2)) {
        try {
          currentSnapshot.catalogs = JSON.parse(import_fs.default.readFileSync(catalogsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      if (import_fs.default.existsSync(settingsFilePath2)) {
        try {
          currentSnapshot.settings = JSON.parse(import_fs.default.readFileSync(settingsFilePath2, "utf8"));
        } catch (_) {
        }
      }
      currentSnapshot.softwareProducts = getSoftwareProductsData();
      currentSnapshot.softwareLicenses = getSoftwareLicensesData();
      import_fs.default.writeFileSync(preRestoreSnapshotPath, JSON.stringify(currentSnapshot, null, 2), "utf8");
      let restoredMediaCount = 0;
      if (Array.isArray(mediaFiles) && mediaFiles.length > 0) {
        restoreMediaFilesPack(mediaFiles);
        restoredMediaCount = mediaFiles.length;
      }
      let finalSettings = currentSnapshot.settings || {};
      if (globalSettings && typeof globalSettings === "object") {
        if (mergeMode === "replace") {
          finalSettings = { ...globalSettings, siteContent, pricingFormula, seoConfigs, emergencyConfig };
        } else {
          finalSettings = {
            ...finalSettings,
            ...globalSettings,
            siteContent: siteContent || finalSettings.siteContent,
            pricingFormula: pricingFormula || finalSettings.pricingFormula,
            seoConfigs: seoConfigs || finalSettings.seoConfigs,
            emergencyConfig: emergencyConfig || finalSettings.emergencyConfig
          };
        }
        import_fs.default.writeFileSync(settingsFilePath2, JSON.stringify(finalSettings, null, 2), "utf8");
      }
      let finalCatalogs = [];
      if (Array.isArray(catalogs)) {
        if (mergeMode === "replace") {
          finalCatalogs = catalogs;
        } else {
          const existingCatalogs = currentSnapshot.catalogs || [];
          const importedIds = new Set(catalogs.map((c) => String(c.id)));
          finalCatalogs = [
            ...catalogs,
            ...existingCatalogs.filter((c) => !importedIds.has(String(c.id)))
          ];
        }
        import_fs.default.writeFileSync(catalogsFilePath2, JSON.stringify(finalCatalogs, null, 2), "utf8");
      }
      if (Array.isArray(softwareProducts)) {
        let finalSoft = softwareProducts;
        if (mergeMode === "merge") {
          const curSoft = getSoftwareProductsData();
          const importedSoftIds = new Set(softwareProducts.map((p) => String(p.id)));
          finalSoft = [...softwareProducts, ...curSoft.filter((p) => !importedSoftIds.has(String(p.id)))];
        }
        import_fs.default.writeFileSync(softwareProductsFilePath, JSON.stringify(finalSoft, null, 2), "utf8");
      }
      if (Array.isArray(softwareLicenses)) {
        let finalLic = softwareLicenses;
        if (mergeMode === "merge") {
          const curLic = getSoftwareLicensesData();
          const importedLicIds = new Set(softwareLicenses.map((l) => String(l.id)));
          finalLic = [...softwareLicenses, ...curLic.filter((l) => !importedLicIds.has(String(l.id)))];
        }
        import_fs.default.writeFileSync(softwareLicensesFilePath, JSON.stringify(finalLic, null, 2), "utf8");
      }
      console.log(`[Full System Restore] Restored ${finalCatalogs.length} catalogs, ${restoredMediaCount} media files, settings and software products successfully.`);
      res.json({
        success: true,
        message: "\u062A\u0645\u0627\u0645\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u0631\u0646\u062F\u060C \u0633\u0627\u06CC\u062A\u060C \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627\u060C \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u0647\u0627\u060C \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u0631\u0633\u0627\u0646\u0647 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0634\u062F\u0646\u062F.",
        restoredData: {
          globalSettings: finalSettings,
          siteContent: siteContent || finalSettings.siteContent,
          pricingFormula: pricingFormula || finalSettings.pricingFormula,
          seoConfigs: seoConfigs || finalSettings.seoConfigs,
          emergencyConfig: emergencyConfig || finalSettings.emergencyConfig,
          catalogs: finalCatalogs,
          b2bSettings: b2bSettings || {}
        },
        stats: {
          restoredMediaCount,
          catalogsCount: finalCatalogs.length,
          softwareProductsCount: Array.isArray(softwareProducts) ? softwareProducts.length : 0
        },
        preRestoreSnapshot: `pre_full_restore_snapshot_${timestamp}.json`
      });
    } catch (err) {
      console.error("Full system restore failed:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u062C\u0627\u0645\u0639: " + err.message });
    }
  });
  const getFilesRecursive = (dirPath, rootDir) => {
    let results = [];
    if (!import_fs.default.existsSync(dirPath)) return results;
    const list = import_fs.default.readdirSync(dirPath);
    list.forEach((file) => {
      const fullPath = import_path.default.join(dirPath, file);
      const stat = import_fs.default.statSync(fullPath);
      if (stat && stat.isDirectory()) {
        results = results.concat(getFilesRecursive(fullPath, rootDir));
      } else {
        results.push(import_path.default.relative(rootDir, fullPath));
      }
    });
    return results;
  };
  app.get("/api/build/files", (req, res) => {
    try {
      const distPath = import_path.default.join(_dirname, "dist");
      if (!import_fs.default.existsSync(distPath)) {
        try {
          console.log("[AutoBuild] dist directory not found. Triggering npm run build...");
          (0, import_child_process.execSync)("npm run build", { stdio: "inherit" });
        } catch (buildErr) {
          console.error("[AutoBuild] Failed to build project:", buildErr);
        }
      }
      if (!import_fs.default.existsSync(distPath)) {
        return res.status(404).json({ error: "\u0634\u0627\u062E\u0647 \u062E\u0631\u0648\u062C\u06CC \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644 \u0634\u062F\u0647 (dist) \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u0627\u0628\u062A\u062F\u0627 \u067E\u0631\u0648\u0698\u0647 \u0631\u0627 \u0628\u06CC\u0644\u062F \u06A9\u0646\u06CC\u062F." });
      }
      const relativePaths = getFilesRecursive(distPath, distPath);
      const filesInfo = relativePaths.map((relPath) => {
        const fullPath = import_path.default.join(distPath, relPath);
        const stat = import_fs.default.statSync(fullPath);
        let category = "frontend";
        if (relPath.startsWith("server.cjs") || relPath === "server.cjs" || relPath === "server.cjs.map") {
          category = "server";
        } else if (relPath.endsWith(".php") || relPath.endsWith(".html") || relPath.startsWith("assets/")) {
          category = "frontend";
        } else {
          category = "other";
        }
        return {
          relativePath: relPath,
          size: stat.size,
          category,
          updatedAt: stat.mtime.toISOString()
        };
      });
      res.json({
        success: true,
        distPath,
        files: filesInfo
      });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0644\u06CC\u0633\u062A \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u062E\u0631\u0648\u062C\u06CC: " + err.message });
    }
  });
  app.get("/api/build/download-zip", (req, res) => {
    try {
      const zipType = req.query.type || "frontend";
      const distPath = import_path.default.join(_dirname, "dist");
      if (!import_fs.default.existsSync(distPath)) {
        try {
          console.log("[AutoBuild] dist directory not found for download-zip. Triggering npm run build...");
          (0, import_child_process.execSync)("npm run build", { stdio: "inherit" });
        } catch (buildErr) {
          console.error("[AutoBuild] Failed to build project:", buildErr);
        }
      }
      if (!import_fs.default.existsSync(distPath)) {
        return res.status(404).send("<h2>\u0634\u0627\u062E\u0647 \u062E\u0631\u0648\u062C\u06CC \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644 \u0634\u062F\u0647 (dist) \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u0627\u0628\u062A\u062F\u0627 \u067E\u0631\u0648\u0698\u0647 \u0631\u0627 \u0628\u06CC\u0644\u062F \u06A9\u0646\u06CC\u062F.</h2>");
      }
      const relativePaths = getFilesRecursive(distPath, distPath);
      const filteredPaths = relativePaths.filter((relPath) => {
        const isServerFile = relPath.startsWith("server.cjs") || relPath === "server.cjs" || relPath === "server.cjs.map";
        if (zipType === "frontend") {
          return !isServerFile;
        } else if (zipType === "server") {
          return isServerFile;
        }
        return true;
      });
      if (filteredPaths.length === 0) {
        return res.status(400).send("<h2>\u0641\u0627\u06CC\u0644\u06CC \u062C\u0647\u062A \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0628\u0631 \u0627\u0633\u0627\u0633 \u0641\u06CC\u0644\u062A\u0631 \u0627\u0646\u062A\u062E\u0627\u0628 \u0634\u062F\u0647 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.</h2>");
      }
      const zip = new import_adm_zip.default();
      filteredPaths.forEach((relPath) => {
        const fullPath = import_path.default.join(distPath, relPath);
        const zipFolder = import_path.default.dirname(relPath);
        const targetPathInZip = zipFolder === "." ? "" : zipFolder;
        zip.addLocalFile(fullPath, targetPathInZip);
      });
      const zipBuffer = zip.toBuffer();
      const fileName = `ashk_ghalam_${zipType}_build_${Date.now()}.zip`;
      res.writeHead(200, {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${fileName}"`,
        "Content-Length": zipBuffer.length
      });
      res.end(zipBuffer);
    } catch (err) {
      res.status(500).send("<h2>\u062E\u0637\u0627 \u062F\u0631 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u067E\u0631\u0648\u0698\u0647: " + err.message + "</h2>");
    }
  });
  app.get("/api/backup/list", (req, res) => {
    try {
      if (!import_fs.default.existsSync(backupsDir)) {
        return res.json([]);
      }
      const files = import_fs.default.readdirSync(backupsDir);
      const backupFiles = files.filter((f) => f.startsWith("backup_") && f.endsWith(".json")).map((file) => {
        const filePath = import_path.default.join(backupsDir, file);
        const stat = import_fs.default.statSync(filePath);
        return {
          filename: file,
          size: stat.size,
          createdAt: stat.mtime.toISOString()
        };
      }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      res.json(backupFiles);
    } catch (err) {
      res.status(500).json({ error: "Failed to list backups: " + err.message });
    }
  });
  app.get("/api/backup/download/:filename", (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = import_path.default.join(backupsDir, filename);
      if (!filePath.startsWith(backupsDir) || !import_fs.default.existsSync(filePath)) {
        return res.status(404).json({ error: "Backup file not found" });
      }
      const stats = import_fs.default.statSync(filePath);
      res.setHeader("Content-Length", stats.size);
      res.setHeader("Content-Type", "application/json");
      import_fs.default.readFile(filePath, "utf8", (err, content) => {
        if (!err) {
          try {
            const payload = JSON.parse(content);
            if (payload && payload.mediaFiles) {
              restoreMediaFilesPack(payload.mediaFiles);
            }
          } catch (_) {
          }
        }
      });
      const readStream = import_fs.default.createReadStream(filePath);
      readStream.pipe(res);
    } catch (err) {
      res.status(500).json({ error: "Failed to read backup: " + err.message });
    }
  });
  app.delete("/api/backup/:filename", (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = import_path.default.join(backupsDir, filename);
      if (!filePath.startsWith(backupsDir) || !import_fs.default.existsSync(filePath)) {
        return res.status(404).json({ error: "Backup file not found" });
      }
      import_fs.default.unlinkSync(filePath);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete backup: " + err.message });
    }
  });
  const softwareProductsFilePath = import_path.default.join(uploadsDir, "software_products.json");
  const softwareLicensesFilePath = import_path.default.join(uploadsDir, "software_licenses.json");
  const defaultSoftwareProducts = [
    {
      id: "ashk-acc-pro",
      name: "\u0633\u0627\u0645\u0627\u0646\u0647 \u062C\u0627\u0645\u0639 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0648 \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u062F\u0648\u0637\u0631\u0641\u0647 \u0627\u0634\u06A9",
      englishName: "Ashk Dual-Entry Accounting & ERP Lite",
      version: "v4.5.0",
      category: "\u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0648 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC",
      shortDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u06CC\u06A9\u067E\u0627\u0631\u0686\u0647 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0645\u0627\u0644\u06CC\u060C \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u0648 \u06A9\u0627\u0631\u062F\u06A9\u0633 \u06A9\u0627\u0644\u0627\u060C \u0635\u062F\u0648\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0631\u0633\u0645\u06CC \u062F\u0627\u0631\u0627\u06CC\u06CC \u0648 \u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u0633\u0627\u0645\u0627\u0646\u0647 \u0645\u0648\u062F\u06CC\u0627\u0646 \u0628\u062F\u0648\u0646 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A.",
      fullDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u062C\u0627\u0645\u0639 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0627\u0634\u06A9 \u0628\u0631\u0627\u06CC \u0634\u0631\u06A9\u062A\u200C\u0647\u0627\u06CC \u062A\u062C\u0627\u0631\u06CC\u060C \u0628\u0627\u0632\u0631\u06AF\u0627\u0646\u06CC\u200C\u0647\u0627 \u0648 \u0645\u062C\u062A\u0645\u0639\u200C\u0647\u0627\u06CC \u062A\u0648\u0644\u06CC\u062F\u06CC \u062A\u0648\u0633\u0639\u0647 \u06CC\u0627\u0641\u062A\u0647 \u0627\u0633\u062A. \u0627\u06CC\u0646 \u0633\u0627\u0645\u0627\u0646\u0647 \u0628\u0627 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0645\u062D\u0644\u06CC \u0641\u0648\u0642\u200C\u0633\u0631\u06CC\u0639 SQLite/Postgres\u060C \u06AF\u0632\u0627\u0631\u0634\u0627\u062A \u0641\u0635\u0644\u06CC \u0627\u0631\u0632\u0634 \u0627\u0641\u0632\u0648\u062F\u0647\u060C \u062A\u0631\u0627\u0632 \u0622\u0632\u0645\u0627\u06CC\u0634\u06CC \u06F8 \u0633\u062A\u0648\u0646\u06CC\u060C \u062B\u0628\u062A \u0627\u0633\u0646\u0627\u062F \u062F\u0648\u0628\u0644 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC\u060C \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u062A\u0639\u062F\u0627\u062F\u06CC \u0648 \u0631\u06CC\u0627\u0644\u06CC \u0628\u0627 \u0631\u0648\u0634\u200C\u0647\u0627\u06CC \u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646 \u0645\u0648\u0632\u0648\u0646 \u0648 FIFO \u0631\u0627 \u06A9\u0627\u0645\u0644\u0627\u064B \u0622\u0641\u0644\u0627\u06CC\u0646 \u0648 \u0645\u0637\u0645\u0626\u0646 \u067E\u0631\u062F\u0627\u0632\u0634 \u0645\u06CC\u200C\u06A9\u0646\u062F.",
      badge: "\u067E\u0631\u0641\u0631\u0648\u0634\u200C\u062A\u0631\u06CC\u0646 \u0633\u06CC\u0633\u062A\u0645 \u0645\u0627\u0644\u06CC",
      color: "from-blue-600 via-indigo-600 to-sky-700",
      iconName: "Calculator",
      featured: true,
      downloadCondition: "requires_registration",
      // "free", "requires_registration", "requires_license"
      downloadUrl: "/downloads/ashk_accounting_setup_v4.5.exe",
      downloadSize: "142 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A",
      releaseDatePersian: "\u06F1\u06F4\u06F0\u06F4/\u06F0\u06F5/\u06F2\u06F0",
      capabilities: [
        "\u062B\u0628\u062A \u0633\u0646\u062F \u0627\u062A\u0648\u0645\u0627\u062A\u06CC\u06A9 \u0648 \u062F\u0633\u062A\u06CC \u062F\u0648\u0628\u0644 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0628\u0627 \u0633\u0631\u0641\u0635\u0644\u200C\u0647\u0627\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u06A9\u0644\u060C \u0645\u0639\u06CC\u0646 \u0648 \u062A\u0641\u0635\u06CC\u0644\u06CC",
        "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u06A9\u0627\u0631\u067E\u0648\u0634\u0647 \u0633\u0627\u0645\u0627\u0646\u0647 \u0645\u0648\u062F\u06CC\u0627\u0646 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC \u062C\u0647\u062A \u0627\u0631\u0633\u0627\u0644 \u0645\u0633\u062A\u0642\u06CC\u0645 \u0635\u0648\u0631\u062A\u062D\u0633\u0627\u0628 \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9\u06CC",
        "\u0633\u06CC\u0633\u062A\u0645 \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0648 \u0627\u0646\u0628\u0627\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC \u0628\u0627 \u0628\u0627\u0631\u06A9\u062F\u062E\u0648\u0627\u0646 \u0648 \u062B\u0628\u062A \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627\u06CC \u0636\u0627\u06CC\u0639\u0627\u062A",
        "\u0645\u063A\u0627\u06CC\u0631\u062A\u200C\u06AF\u06CC\u0631\u06CC \u0628\u0627\u0646\u06A9\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631 \u0627\u0632 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u0627\u06A9\u0633\u0644 \u06AF\u0631\u062F\u0634 \u062D\u0633\u0627\u0628 \u062A\u0645\u0627\u0645 \u0628\u0627\u0646\u06A9\u200C\u0647\u0627\u06CC \u06A9\u0634\u0648\u0631",
        "\u062F\u0641\u0627\u062A\u0631 \u0642\u0627\u0646\u0648\u0646\u06CC \u0631\u0648\u0632\u0646\u0627\u0645\u0647 \u0648 \u06A9\u0644 \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u062A\u0631\u0627\u0632\u0646\u0627\u0645\u0647 \u0648 \u0635\u0648\u0631\u062A \u0633\u0648\u062F \u0648 \u0632\u06CC\u0627\u0646 \u062C\u0627\u0645\u0639",
        "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u200C\u06AF\u06CC\u0631\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631 \u0631\u0645\u0632\u0646\u06AF\u0627\u0631\u06CC\u200C\u0634\u062F\u0647 \u062F\u0631 \u062D\u0627\u0641\u0638\u0647 \u0645\u062D\u0644\u06CC \u0648 \u0641\u0644\u0634 \u0645\u0645\u0648\u0631\u06CC \u0628\u062F\u0648\u0646 \u0648\u0627\u0628\u0633\u062A\u06AF\u06CC \u0628\u0647 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A"
      ],
      specs: {
        os: "\u0648\u06CC\u0646\u062F\u0648\u0632 \u06F1\u06F0 / \u06F1\u06F1 / \u0633\u0631\u0648\u0631 \u06F2\u06F0\u06F2\u06F2 (\u0646\u0633\u062E\u0647 \u06F6\u06F4 \u0628\u06CC\u062A\u06CC)",
        ram: "\u062D\u062F\u0627\u0642\u0644 \u06F4 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A (\u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u06F8 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A)",
        gpu: "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u0631\u0632\u0648\u0644\u0648\u0634\u0646\u200C\u0647\u0627\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0648 \u0645\u0627\u0646\u06CC\u062A\u0648\u0631\u0647\u0627\u06CC \u0639\u0631\u06CC\u0636",
        database: "\u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u0645\u062D\u0644\u06CC \u0627\u06CC\u0645\u0646 \u0628\u0627 \u0642\u0627\u0628\u0644\u06CC\u062A \u0634\u0628\u06A9\u0647 \u0686\u0646\u062F\u06A9\u0627\u0631\u0628\u0631\u0647",
        offlineEngine: true
      },
      plans: [
        {
          name: "\u067E\u06A9\u06CC\u062C \u067E\u0627\u06CC\u0647 \u0628\u0627 \u062B\u0628\u062A\u200C\u0646\u0627\u0645 (Free / Basic)",
          price: "\u0631\u0627\u06CC\u06AF\u0627\u0646 \u0628\u0627 \u062B\u0628\u062A \u0646\u0627\u0645",
          period: "\u062F\u0627\u0626\u0645\u06CC \u062A\u06A9 \u06A9\u0627\u0631\u0628\u0631\u0647",
          features: ["\u0635\u062F\u0648\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0648 \u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631", "\u06A9\u0627\u0631\u062F\u06A9\u0633 \u0627\u0646\u0628\u0627\u0631 \u062A\u0627 \u06F5\u06F0\u06F0 \u06A9\u0627\u0644\u0627", "\u06AF\u0632\u0627\u0631\u0634\u0627\u062A \u067E\u0627\u06CC\u0647 \u062A\u0631\u0627\u0632 \u0648 \u0633\u0648\u062F \u0648 \u0632\u06CC\u0627\u0646", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u200C\u06AF\u06CC\u0631\u06CC \u0645\u062D\u0644\u06CC"],
          conditionType: "requires_registration"
        },
        {
          name: "\u067E\u06A9\u06CC\u062C \u062A\u062C\u0627\u0631\u06CC \u0648 \u0645\u0648\u062F\u06CC\u0627\u0646 (Commercial)",
          price: "\u06F8,\u06F5\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u06F1 \u0633\u0627\u0644\u0647 \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u0622\u067E\u062F\u06CC\u062A",
          features: ["\u0645\u0627\u0698\u0648\u0644 \u0645\u0633\u062A\u0642\u06CC\u0645 \u0633\u0627\u0645\u0627\u0646\u0647 \u0645\u0648\u062F\u06CC\u0627\u0646", "\u06A9\u0627\u0631\u062F\u06A9\u0633 \u0646\u0627\u0645\u062D\u062F\u0648\u062F \u0686\u0646\u062F\u0627\u0646\u0628\u0627\u0631\u0647", "\u0645\u063A\u0627\u06CC\u0631\u062A\u200C\u06AF\u06CC\u0631\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0627\u06A9\u0633\u0644 \u0628\u0627\u0646\u06A9", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u062A\u0644\u0641\u0646\u06CC \u0648 \u0631\u06CC\u0645\u0648\u062A"],
          recommended: true,
          conditionType: "requires_license"
        },
        {
          name: "\u067E\u06A9\u06CC\u062C \u0633\u0627\u0632\u0645\u0627\u0646\u06CC \u0634\u0628\u06A9\u0647 (Enterprise Network)",
          price: "\u06F1\u06F6,\u06F8\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u062F\u0627\u0626\u0645\u06CC \u06F5 \u06A9\u0627\u0631\u0628\u0631 \u0647\u0645\u0632\u0645\u0627\u0646",
          features: ["\u062A\u0645\u0627\u0645 \u0627\u0645\u06A9\u0627\u0646\u0627\u062A \u062A\u062C\u0627\u0631\u06CC", "\u0633\u06CC\u0633\u062A\u0645 \u062D\u0642\u0648\u0642 \u0648 \u062F\u0633\u062A\u0645\u0632\u062F \u067E\u06CC\u0634\u0631\u0641\u062A\u0647", "\u06A9\u0646\u062A\u0631\u0644 \u0633\u0637\u062D \u062F\u0633\u062A\u0631\u0633\u06CC \u067E\u0631\u0633\u0646\u0644", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u062E\u062A\u0635\u0627\u0635\u06CC VIP"],
          conditionType: "requires_license"
        }
      ],
      catalogPages: [
        {
          title: "\u062F\u0627\u0634\u0628\u0648\u0631\u062F \u0646\u0642\u062F\u06CC\u0646\u06AF\u06CC \u0648 \u0635\u0648\u0631\u062A \u0648\u0636\u0639\u06CC\u062A \u0644\u062D\u0638\u0647\u200C\u0627\u06CC",
          description: "\u0645\u062F\u06CC\u0631 \u0645\u0627\u0644\u06CC \u0648 \u0645\u062F\u06CC\u0631\u0639\u0627\u0645\u0644 \u062F\u0631 \u06CC\u06A9 \u0646\u06AF\u0627\u0647 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u0646\u062F \u0622\u062E\u0631\u06CC\u0646 \u06AF\u0631\u062F\u0634 \u062D\u0633\u0627\u0628\u200C\u0647\u0627\u060C \u0645\u0637\u0627\u0644\u0628\u0627\u062A \u0633\u0631\u0631\u0633\u06CC\u062F \u0634\u062F\u0647\u060C \u0686\u06A9\u200C\u0647\u0627\u06CC \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC \u0648 \u067E\u0631\u062F\u0627\u062E\u062A\u06CC \u0648 \u0633\u0648\u062F \u0646\u0627\u062E\u0627\u0644\u0635 \u0645\u0627\u0647 \u062C\u0627\u0631\u06CC \u0631\u0627 \u0645\u0634\u0627\u0647\u062F\u0647 \u06A9\u0646\u0646\u062F.",
          imageUrl: "/media/accounting_dash.png",
          highlights: ["\u0646\u0645\u0648\u062F\u0627\u0631\u0647\u0627\u06CC \u062A\u062D\u0644\u06CC\u0644\u06CC \u0646\u0642\u062F\u06CC\u0646\u06AF\u06CC", "\u0647\u0634\u062F\u0627\u0631 \u0633\u0631\u0631\u0633\u06CC\u062F \u0686\u06A9\u200C\u0647\u0627", "\u0645\u062D\u0627\u0633\u0628\u0647 \u062F\u0642\u06CC\u0642 \u0646\u0642\u0637\u0647 \u0633\u0631 \u0628\u0647 \u0633\u0631"],
          stat: { label: "\u062F\u0642\u062A \u0645\u062D\u0627\u0633\u0628\u0627\u062A\u06CC", value: "\u06F1\u06F0\u06F0\u066A \u0628\u062F\u0648\u0646 \u062E\u0637\u0627" }
        },
        {
          title: "\u0627\u0631\u0633\u0627\u0644 \u0622\u0633\u0627\u0646 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0628\u0647 \u0633\u0627\u0645\u0627\u0646\u0647 \u0645\u0648\u062F\u06CC\u0627\u0646 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC",
          description: "\u0628\u062F\u0648\u0646 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0634\u0631\u06A9\u062A\u200C\u0647\u0627\u06CC \u0645\u0639\u062A\u0645\u062F \u06CC\u0627 \u067E\u0631\u062F\u0627\u062E\u062A \u0647\u0632\u06CC\u0646\u0647\u200C\u0647\u0627\u06CC \u0648\u0627\u0633\u0637\u0647\u200C\u0627\u06CC \u0633\u0646\u06AF\u06CC\u0646\u060C \u06A9\u0644\u06CC\u062F \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC \u062E\u0648\u062F \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0647 \u0648 \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627 \u0631\u0627 \u0645\u0633\u062A\u0642\u06CC\u0645\u0627\u064B \u0627\u0632 \u062F\u0627\u062E\u0644 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0627\u0645\u0636\u0627 \u0648 \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F.",
          imageUrl: "/media/accounting_modyan.png",
          highlights: ["\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u0627\u0644\u06AF\u0648\u0647\u0627\u06CC \u0641\u0627\u06A9\u062A\u0648\u0631 \u0637\u0644\u0627\u060C \u06A9\u0627\u0644\u0627\u060C \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631\u06CC \u0648 \u0635\u0627\u062F\u0631\u0627\u062A", "\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0622\u0646\u06CC \u0648\u0636\u0639\u06CC\u062A \u0635\u0648\u0631\u062A\u062D\u0633\u0627\u0628 \u0627\u0632 \u0633\u0631\u0648\u0631 \u0645\u0627\u0644\u06CC\u0627\u062A", "\u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u0627\u0632 \u062C\u0631\u06CC\u0645\u0647\u200C\u0647\u0627\u06CC \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC"],
          stat: { label: "\u0632\u0645\u0627\u0646 \u0627\u0631\u0633\u0627\u0644 \u0647\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631", value: "\u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F2 \u062B\u0627\u0646\u06CC\u0647" }
        }
      ]
    },
    {
      id: "ashk-remittance-core",
      name: "\u0633\u0627\u0645\u0627\u0646\u0647 \u062C\u0627\u0645\u0639 \u0635\u0631\u0627\u0641\u06CC\u060C \u062A\u0633\u0648\u06CC\u0647 \u0648 \u062D\u0648\u0627\u0644\u0647\u200C\u062C\u0627\u062A \u0627\u0631\u0632\u06CC \u0627\u0634\u06A9",
      englishName: "Ashk Remittance & Currency Clearing Core",
      version: "v3.8.2",
      category: "\u0633\u0627\u0645\u0627\u0646\u0647\u200C\u0647\u0627\u06CC \u062D\u0648\u0627\u0644\u0647 \u0648 \u0627\u0631\u0632\u06CC",
      shortDesc: "\u067E\u0644\u062A\u0641\u0631\u0645 \u062A\u062E\u0635\u0635\u06CC \u062B\u0628\u062A\u060C \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0648 \u062A\u0633\u0648\u06CC\u0647 \u0627\u0646\u0648\u0627\u0639 \u062D\u0648\u0627\u0644\u0647\u200C\u062C\u0627\u062A \u062F\u0631\u0647\u0645\u060C \u062F\u0644\u0627\u0631\u060C \u0644\u06CC\u0631 \u0648 \u06CC\u0648\u0631\u0648\u060C \u062A\u0633\u0648\u06CC\u0647 \u062F\u0641\u0627\u062A\u0631 \u0635\u0631\u0627\u0641\u06CC \u0648 \u0635\u062F\u0648\u0631 \u0633\u0646\u062F \u0627\u0645\u0646.",
      fullDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0645\u062F\u06CC\u0631\u06CC\u062A \u062D\u0648\u0627\u0644\u0647 \u0648 \u062F\u0641\u0627\u062A\u0631 \u0635\u0631\u0627\u0641\u06CC \u0627\u0634\u06A9 \u0648\u06CC\u0698\u0647 \u0634\u0631\u06A9\u062A\u200C\u0647\u0627\u06CC \u0628\u0627\u0632\u0631\u06AF\u0627\u0646\u06CC \u0648\u0627\u0631\u062F\u0627\u062A/\u0635\u0627\u062F\u0631\u0627\u062A \u0648 \u062F\u0641\u0627\u062A\u0631 \u062D\u0648\u0627\u0644\u0647 \u0637\u0631\u0627\u062D\u06CC \u06AF\u0631\u062F\u06CC\u062F\u0647 \u0627\u0633\u062A. \u0642\u0627\u0628\u0644\u06CC\u062A \u0645\u062D\u0627\u0633\u0628\u0647 \u0644\u062D\u0638\u0647\u200C\u0627\u06CC \u0646\u0631\u062E \u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646 \u0645\u0648\u0632\u0648\u0646\u060C \u062A\u0633\u0648\u06CC\u0647 \u062F\u0641\u0627\u062A\u0631 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0627\u0631\u0632\u06CC \u0648 \u0631\u06CC\u0627\u0644\u06CC\u060C \u062A\u0641\u06A9\u06CC\u06A9 \u06A9\u0627\u0631\u0645\u0632\u062F \u06A9\u0627\u0631\u06AF\u0632\u0627\u0631\u0627\u0646\u060C \u0635\u062F\u0648\u0631 \u0631\u0633\u06CC\u062F\u0647\u0627\u06CC \u06A9\u062F\u06AF\u0630\u0627\u0631\u06CC\u200C\u0634\u062F\u0647 \u0636\u062F\u062C\u0639\u0644 \u0628\u0627 \u0628\u0627\u0631\u06A9\u062F \u062F\u0648\u0628\u0639\u062F\u06CC\u060C \u0648 \u06AF\u0632\u0627\u0631\u0634 \u0633\u0648\u062F \u062A\u0633\u0639\u06CC\u0631 \u0627\u0631\u0632 \u0628\u0631 \u0627\u0633\u0627\u0633 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F\u0647\u0627\u06CC \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0631\u0627 \u062F\u0627\u0631\u0627 \u0645\u06CC\u200C\u0628\u0627\u0634\u062F.",
      badge: "\u0627\u0645\u0646\u200C\u062A\u0631\u06CC\u0646 \u0633\u06CC\u0633\u062A\u0645 \u0627\u0631\u0632\u06CC \u0648 \u062D\u0648\u0627\u0644\u0647",
      color: "from-emerald-600 via-teal-600 to-cyan-700",
      iconName: "Coins",
      featured: true,
      downloadCondition: "requires_license",
      downloadUrl: "/downloads/ashk_remittance_setup_v3.8.exe",
      downloadSize: "168 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A",
      releaseDatePersian: "\u06F1\u06F4\u06F0\u06F4/\u06F0\u06F6/\u06F1\u06F0",
      capabilities: [
        "\u0645\u062F\u06CC\u0631\u06CC\u062A \u0686\u0646\u062F\u0627\u0631\u0632\u06CC \u06A9\u0627\u0645\u0644 (\u062F\u0631\u0647\u0645 \u0627\u0645\u0627\u0631\u0627\u062A\u060C \u062F\u0644\u0627\u0631\u060C \u06CC\u0648\u0631\u0648\u060C \u06CC\u0648\u0627\u0646 \u0686\u06CC\u0646\u060C \u0644\u06CC\u0631 \u062A\u0631\u06A9\u06CC\u0647\u060C \u0631\u0648\u067E\u06CC\u0647 \u0648 \u062F\u06CC\u0646\u0627\u0631)",
        "\u062B\u0628\u062A \u0627\u0646\u0648\u0627\u0639 \u062D\u0648\u0627\u0644\u0647 \u0648\u0627\u0631\u062F\u0647\u060C \u0635\u0627\u062F\u0631\u0647\u060C \u0646\u0642\u062F\u06CC (\u0627\u0633\u06A9\u0646\u0627\u0633) \u0648 \u0633\u0648\u0626\u06CC\u0641\u062A \u0628\u0627 \u062F\u0631\u062C \u0645\u0634\u062E\u0635\u0627\u062A \u062F\u0642\u06CC\u0642 \u0630\u06CC\u0646\u0641\u0639",
        "\u062A\u0631\u0627\u0632 \u0627\u0631\u0632\u06CC \u062A\u0641\u06A9\u06CC\u06A9\u06CC \u06A9\u0627\u0631\u06AF\u0632\u0627\u0631\u0627\u0646 \u0648 \u0635\u0631\u0627\u0641\u06CC\u200C\u0647\u0627\u06CC \u0647\u0645\u06A9\u0627\u0631 \u0628\u0627 \u0642\u0627\u0628\u0644\u06CC\u062A \u062A\u0633\u0648\u06CC\u0647 \u0627\u0631\u0632\u06CC \u06CC\u0627 \u062A\u0647\u0627\u062A\u0631 \u0631\u06CC\u0627\u0644\u06CC",
        "\u062A\u0648\u0644\u06CC\u062F \u0631\u0633\u06CC\u062F \u062D\u0648\u0627\u0644\u0647 \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0636\u062F\u062C\u0639\u0644 \u0628\u0627 \u0648\u0627\u062A\u0631\u0645\u0627\u0631\u06A9 \u0631\u0645\u0632\u0646\u06AF\u0627\u0631\u06CC \u0634\u062F\u0647 \u0648 QR Code \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC",
        "\u0645\u062D\u0627\u0633\u0628\u0647 \u06A9\u0627\u0631\u0645\u0632\u062F \u062F\u0631\u0635\u062F\u06CC \u06CC\u0627 \u062B\u0627\u0628\u062A \u06A9\u0627\u0631\u06AF\u0632\u0627\u0631\u0627\u0646 \u062F\u0627\u062E\u0644\u06CC \u0648 \u062E\u0627\u0631\u062C\u06CC \u0628\u0647 \u0637\u0648\u0631 \u062E\u0648\u062F\u06A9\u0627\u0631",
        "\u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u0622\u0641\u0644\u0627\u06CC\u0646 \u0631\u0645\u0632\u0646\u06AF\u0627\u0631\u06CC\u200C\u0634\u062F\u0647 AES-256 \u062C\u0647\u062A \u0627\u0645\u0646\u06CC\u062A \u062D\u062F\u0627\u06A9\u062B\u0631\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062D\u0633\u0627\u0633 \u0627\u0631\u0632\u06CC"
      ],
      specs: {
        os: "\u0648\u06CC\u0646\u062F\u0648\u0632 \u06F1\u06F0 / \u06F1\u06F1 / \u0648\u06CC\u0646\u062F\u0648\u0632 \u0633\u0631\u0648\u0631\u060C \u0648 \u06A9\u0644\u0627\u06CC\u0646\u062A \u0648\u0628 \u0644\u0648\u06A9\u0627\u0644",
        ram: "\u062D\u062F\u0627\u0642\u0644 \u06F8 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A",
        gpu: "\u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0633\u0627\u0632\u0645\u0627\u0646\u06CC",
        database: "\u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0641\u0648\u0642 \u0627\u06CC\u0645\u0646 \u0645\u062D\u0644\u06CC \u0628\u0627 \u0633\u06CC\u0633\u062A\u0645 \u062A\u0627\u06CC\u06CC\u062F \u062F\u0648\u0645\u0631\u062D\u0644\u0647\u200C\u0627\u06CC",
        offlineEngine: true
      },
      plans: [
        {
          name: "\u0646\u0633\u062E\u0647 \u062F\u0641\u062A\u0631\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F (Standard Office)",
          price: "\u06F1\u06F2,\u06F0\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u06F1 \u0633\u0627\u0644\u0647 \u062A\u06A9 \u0633\u06CC\u0633\u062A\u0645",
          features: ["\u062B\u0628\u062A \u062D\u0648\u0627\u0644\u062C\u0627\u062A \u062A\u0627 \u06F3 \u0627\u0631\u0632 \u0627\u0635\u0644\u06CC", "\u062A\u0633\u0648\u06CC\u0647 \u0628\u0627 \u06F1\u06F0 \u0635\u0631\u0627\u0641 \u0647\u0645\u06A9\u0627\u0631", "\u0635\u062F\u0648\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0648 \u0631\u0633\u06CC\u062F \u0686\u0627\u067E\u06CC \u0627\u0645\u0646", "\u06AF\u0632\u0627\u0631\u0634 \u062A\u0633\u0639\u06CC\u0631 \u0627\u0631\u0632"],
          conditionType: "requires_license"
        },
        {
          name: "\u0646\u0633\u062E\u0647 \u0635\u0631\u0627\u0641\u06CC \u067E\u06CC\u0634\u0631\u0641\u062A\u0647 (Exchange Pro)",
          price: "\u06F2\u06F4,\u06F5\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u0646\u0627\u0645\u062D\u062F\u0648\u062F \u0632\u0645\u0627\u0646\u06CC (\u06F3 \u06A9\u0627\u0631\u0628\u0631 \u0634\u0628\u06A9\u0647)",
          features: ["\u062A\u0645\u0627\u0645 \u0627\u0631\u0632\u0647\u0627\u06CC \u062C\u0647\u0627\u0646\u06CC \u0628\u062F\u0648\u0646 \u0645\u062D\u062F\u0648\u062F\u06CC\u062A", "\u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u06A9\u0627\u0645\u0644 \u062F\u0641\u0627\u062A\u0631 \u0627\u0631\u0632\u06CC", "\u0645\u0627\u0698\u0648\u0644 \u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0647\u0645\u0631\u0627\u0647", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0634\u0628\u0627\u0646\u0647\u200C\u0631\u0648\u0632\u06CC"],
          recommended: true,
          conditionType: "requires_license"
        }
      ],
      catalogPages: [
        {
          title: "\u0645\u06CC\u0632 \u06A9\u0627\u0631 \u062A\u0633\u0648\u06CC\u0647 \u0627\u0631\u0632\u06CC \u0648 \u062D\u0648\u0627\u0644\u0647\u200C\u062C\u0627\u062A",
          description: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0644\u062D\u0638\u0647\u200C\u0627\u06CC \u0648\u0636\u0639\u06CC\u062A \u062D\u0648\u0627\u0644\u0647\u200C\u0647\u0627\u06CC \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631\u060C \u067E\u0631\u062F\u0627\u062E\u062A \u0634\u062F\u0647\u060C \u0645\u0631\u062C\u0648\u0639\u06CC \u0648 \u0645\u063A\u0627\u06CC\u0631\u062A\u200C\u0647\u0627\u06CC \u0627\u062D\u062A\u0645\u0627\u0644\u06CC \u0628\u0627 \u06A9\u0627\u0631\u06AF\u0632\u0627\u0631\u0627\u0646 \u062F\u0628\u06CC\u060C \u062A\u0631\u06A9\u06CC\u0647 \u0648 \u0686\u06CC\u0646 \u062F\u0631 \u06CC\u06A9 \u0645\u062D\u06CC\u0637 \u0627\u0645\u0646.",
          imageUrl: "/media/remittance_flow.png",
          highlights: ["\u062A\u0641\u06A9\u06CC\u06A9 \u0631\u0646\u06AF\u06CC \u0648\u0636\u0639\u06CC\u062A \u062D\u0648\u0627\u0644\u0647", "\u0647\u0634\u062F\u0627\u0631 \u062A\u063A\u06CC\u06CC\u0631\u0627\u062A \u0634\u062F\u06CC\u062F \u0646\u0631\u062E \u0627\u0631\u0632", "\u0645\u062D\u0627\u0633\u0628\u0647 \u062E\u0648\u062F\u06A9\u0627\u0631 \u0633\u0648\u062F \u0645\u0628\u0627\u062F\u0644\u0647"],
          stat: { label: "\u062A\u0633\u0648\u06CC\u0647 \u0631\u0648\u0632\u0627\u0646\u0647", value: "\u06F1\u06F0\u06F0\u066A \u062A\u0637\u0628\u06CC\u0642 \u062D\u0633\u0627\u0628" }
        },
        {
          title: "\u0635\u062F\u0648\u0631 \u0631\u0633\u06CC\u062F \u0645\u0639\u062A\u0628\u0631 \u0648 \u0631\u0645\u0632\u0646\u06AF\u0627\u0631\u06CC\u200C\u0634\u062F\u0647 \u062D\u0648\u0627\u0644\u0647",
          description: "\u0631\u0633\u06CC\u062F\u0647\u0627\u06CC \u0631\u0633\u0645\u06CC \u0628\u0627 \u0633\u0631\u0628\u0631\u06AF \u062F\u0641\u062A\u0631 \u0634\u0645\u0627\u060C \u062F\u0631\u062C \u0645\u0634\u062E\u0635\u0627\u062A \u06A9\u0627\u0645\u0644 \u0641\u0631\u0633\u062A\u0646\u062F\u0647 \u0648 \u06AF\u06CC\u0631\u0646\u062F\u0647\u060C \u0634\u0645\u0627\u0631\u0647 \u0631\u0641\u0631\u0646\u0633 \u0628\u06CC\u0646\u200C\u0627\u0644\u0645\u0644\u0644\u06CC \u0648 \u0627\u0645\u0636\u0627\u06CC \u062F\u06CC\u062C\u06CC\u062A\u0627\u0644 \u06A9\u0647 \u062E\u0637\u0627\u06CC \u062C\u0639\u0644 \u0648 \u0633\u0648\u0621\u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0631\u0627 \u0628\u0647 \u0635\u0641\u0631 \u0645\u06CC\u200C\u0631\u0633\u0627\u0646\u062F.",
          imageUrl: "/media/remittance_receipt.png",
          highlights: ["\u062E\u0631\u0648\u062C\u06CC \u0645\u0633\u062A\u0642\u06CC\u0645 PDF \u0627\u0645\u0646", "\u0627\u0645\u06A9\u0627\u0646 \u0627\u0631\u0633\u0627\u0644 \u062E\u0648\u062F\u06A9\u0627\u0631 \u062F\u0631 \u0648\u0627\u062A\u0633\u0627\u067E \u0648 \u0628\u0644\u0647", "\u06A9\u062F \u0631\u0647\u06AF\u06CC\u0631\u06CC \u067E\u06CC\u0627\u0645\u06A9\u06CC \u0645\u062D\u0644\u06CC"],
          stat: { label: "\u0627\u0639\u062A\u0628\u0627\u0631 \u0627\u0633\u0646\u0627\u062F", value: "\u0645\u0648\u0631\u062F \u062A\u0627\u06CC\u06CC\u062F \u0628\u0627\u0632\u0631\u06AF\u0627\u0646\u0627\u0646" }
        }
      ]
    },
    {
      id: "ashk-remittance-pocket",
      name: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u062D\u0648\u0627\u0644\u0647 \u0648 \u062A\u0633\u0648\u06CC\u0647 \u0633\u0631\u06CC\u0639 \u0627\u0634\u06A9",
      englishName: "Ashk Remittance Pocket Android",
      version: "v2.6.1",
      category: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646\u200C\u0647\u0627\u06CC \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u0627\u0646\u062F\u0631\u0648\u06CC\u062F",
      shortDesc: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0647\u0645\u0631\u0627\u0647 \u0628\u0631\u0627\u06CC \u0645\u062F\u06CC\u0631\u0627\u0646 \u0635\u0631\u0627\u0641\u06CC \u0648 \u0628\u0627\u0632\u0631\u06AF\u0627\u0646\u0627\u0646 \u062C\u0647\u062A \u0635\u062F\u0648\u0631 \u0622\u0646\u06CC \u0628\u0631\u06AF\u0647 \u062D\u0648\u0627\u0644\u0647\u060C \u062B\u0628\u062A \u0627\u0645\u0636\u0627\u06CC \u0645\u0634\u062A\u0631\u06CC \u0648 \u0627\u0634\u062A\u0631\u0627\u06A9 \u0631\u0633\u06CC\u062F \u062F\u0631 \u0645\u062D\u0644.",
      fullDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u062D\u0648\u0627\u0644\u0647 \u0627\u0634\u06A9\u060C \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0628\u0627\u062F\u0644\u0627\u062A \u0627\u0631\u0632\u06CC \u0631\u0627 \u0631\u0648\u06CC \u06AF\u0648\u0634\u06CC \u062A\u0644\u0641\u0646 \u0647\u0645\u0631\u0627\u0647 \u0648 \u062A\u0628\u0644\u062A \u0645\u0645\u06A9\u0646 \u0645\u06CC\u200C\u0633\u0627\u0632\u062F. \u0628\u0627 \u0627\u06CC\u0646 \u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u062D\u062A\u06CC \u062F\u0631 \u062D\u0627\u0644\u062A \u0642\u0637\u0639 \u0628\u0648\u062F\u0646 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u062D\u0648\u0627\u0644\u0647\u200C\u0647\u0627 \u0631\u0627 \u062B\u0628\u062A\u060C \u0627\u0633\u0646\u0627\u062F \u0631\u0627 \u0627\u0645\u0636\u0627\u060C \u0648 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0686\u0627\u067E\u06AF\u0631 \u062D\u0631\u0627\u0631\u062A\u06CC \u0628\u0644\u0648\u062A\u0648\u062B \u067E\u0631\u06CC\u0646\u062A \u0628\u06AF\u06CC\u0631\u06CC\u062F. \u0647\u0646\u06AF\u0627\u0645 \u0648\u0631\u0648\u062F \u0628\u0647 \u062F\u0641\u062A\u0631\u060C \u062A\u0645\u0627\u0645 \u062F\u0627\u062F\u0647\u200C\u0647\u0627 \u0628\u0647 \u0635\u0648\u0631\u062A \u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u0627 \u0633\u0631\u0648\u0631 \u0627\u0635\u0644\u06CC \u0633\u06CC\u0646\u06A9 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F.",
      badge: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0645\u062D\u0628\u0648\u0628 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F",
      color: "from-amber-600 via-orange-600 to-rose-700",
      iconName: "Smartphone",
      featured: true,
      downloadCondition: "requires_registration",
      downloadUrl: "/downloads/ashk_remittance_pocket.apk",
      downloadSize: "28 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A (\u0641\u0627\u06CC\u0644 \u0646\u0635\u0628\u06CC APK)",
      releaseDatePersian: "\u06F1\u06F4\u06F0\u06F4/\u06F0\u06F6/\u06F1\u06F5",
      capabilities: [
        "\u0633\u0627\u0632\u06AF\u0627\u0631 \u0628\u0627 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u06F8 \u0628\u0647 \u0628\u0627\u0644\u0627 \u0631\u0648\u06CC \u062A\u0645\u0627\u0645 \u0628\u0631\u0646\u062F\u0647\u0627\u06CC \u06AF\u0648\u0634\u06CC \u0648 \u062A\u0628\u0644\u062A \u0633\u0627\u0645\u0633\u0648\u0646\u06AF\u060C \u0634\u06CC\u0627\u0626\u0648\u0645\u06CC \u0648...",
        "\u06A9\u0627\u0631\u06A9\u0631\u062F \u06A9\u0627\u0645\u0644 \u0628\u062F\u0648\u0646 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A \u0628\u0627 \u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u0645\u062D\u0644\u06CC SQLite \u0631\u0648\u06CC \u06AF\u0648\u0634\u06CC",
        "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u067E\u0631\u06CC\u0646\u062A\u0631\u0647\u0627\u06CC \u062C\u06CC\u0628\u06CC \u0648 \u0631\u0648\u0644 \u062D\u0631\u0627\u0631\u062A\u06CC \u06A9\u0645\u0631\u06CC \u0628\u0627 \u0628\u0644\u0648\u062A\u0648\u062B \u062C\u0647\u062A \u0635\u062F\u0648\u0631 \u0642\u0628\u0636 \u0641\u0648\u0631\u06CC",
        "\u0627\u0645\u06A9\u0627\u0646 \u062F\u0631\u06CC\u0627\u0641\u062A \u0627\u0645\u0636\u0627\u06CC \u062F\u0633\u062A\u200C\u0646\u0648\u06CC\u0633 \u0637\u0631\u0641 \u0645\u0639\u0627\u0645\u0644\u0647 \u0631\u0648\u06CC \u0635\u0641\u062D\u0647 \u0644\u0645\u0633\u06CC \u06AF\u0648\u0634\u06CC",
        "\u0627\u0634\u062A\u0631\u0627\u06A9\u200C\u06AF\u0630\u0627\u0631\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631 \u0639\u06A9\u0633 \u06CC\u0627 PDF \u0631\u0633\u06CC\u062F \u062D\u0648\u0627\u0644\u0647 \u062F\u0631 \u0627\u06CC\u062A\u0627\u060C \u0631\u0648\u0628\u06CC\u06A9\u0627\u060C \u062A\u0644\u06AF\u0631\u0627\u0645 \u0648 \u067E\u06CC\u0627\u0645\u06A9",
        "\u0633\u06CC\u0646\u06A9 \u0647\u0648\u0634\u0645\u0646\u062F \u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u0627 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0648\u06CC\u0646\u062F\u0648\u0632 \u062F\u0631 \u0634\u0628\u06A9\u0647 Wi-Fi \u0645\u062D\u0644\u06CC \u062F\u0641\u062A\u0631"
      ],
      specs: {
        os: "\u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u06F8.\u06F0 \u0648 \u0628\u0627\u0644\u0627\u062A\u0631 (Android 8.0 - 15.0)",
        ram: "\u062D\u062F\u0627\u0642\u0644 \u06F2 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A",
        gpu: "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u062D\u0627\u0644\u062A \u062A\u06CC\u0631\u0647 \u0648 \u0631\u0648\u0634\u0646",
        database: "\u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0622\u0641\u0644\u0627\u06CC\u0646 \u0631\u0648\u06CC \u062D\u0627\u0641\u0638\u0647 \u062F\u0627\u062E\u0644\u06CC \u0628\u0627 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u062F\u0627\u062F\u0647\u200C\u0647\u0627",
        offlineEngine: true
      },
      plans: [
        {
          name: "\u0646\u0633\u062E\u0647 \u067E\u0627\u06CC\u0647 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0647\u0645\u0631\u0627\u0647",
          price: "\u0631\u0627\u06CC\u06AF\u0627\u0646 \u0628\u0631\u0627\u06CC \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0634\u062F\u0647",
          period: "\u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u062F\u0627\u0626\u0645",
          features: ["\u062B\u0628\u062A \u0631\u0648\u0632\u0627\u0646\u0647 \u062A\u0627 \u06F2\u06F0 \u062D\u0648\u0627\u0644\u0647", "\u0635\u062F\u0648\u0631 \u0631\u0633\u06CC\u062F \u062A\u0635\u0648\u06CC\u0631\u06CC", "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u0686\u0627\u067E\u06AF\u0631 \u0628\u0644\u0648\u062A\u0648\u062B", "\u0630\u062E\u06CC\u0631\u0647 \u062F\u0631 \u06AF\u0648\u0634\u06CC"],
          conditionType: "requires_registration"
        },
        {
          name: "\u0646\u0633\u062E\u0647 \u0646\u0627\u0645\u062D\u062F\u0648\u062F \u0628\u0627\u0632\u0631\u06AF\u0627\u0646\u06CC",
          price: "\u06F3,\u06F2\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u062F\u0627\u0626\u0645\u06CC \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u0622\u067E\u062F\u06CC\u062A\u200C\u0647\u0627\u06CC \u0633\u0627\u0644\u0627\u0646\u0647",
          features: ["\u062B\u0628\u062A \u0646\u0627\u0645\u062D\u062F\u0648\u062F \u062D\u0648\u0627\u0644\u0647", "\u0627\u0645\u0636\u0627\u06CC \u062F\u06CC\u062C\u06CC\u062A\u0627\u0644 \u0645\u0634\u062A\u0631\u06CC", "\u0633\u06CC\u0646\u06A9 \u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u0627 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0645\u0631\u06A9\u0632\u06CC", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u200C\u06AF\u06CC\u0631\u06CC \u0627\u0628\u0631\u06CC \u0645\u062D\u0644\u06CC"],
          recommended: true,
          conditionType: "requires_license"
        }
      ],
      catalogPages: [
        {
          title: "\u0631\u0627\u0628\u0637 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0633\u0631\u06CC\u0639 \u0648 \u0627\u0631\u06AF\u0648\u0646\u0648\u0645\u06CC\u06A9 \u0644\u0645\u0633\u06CC",
          description: "\u0637\u0631\u0627\u062D\u06CC \u0634\u062F\u0647 \u0628\u0631\u0627\u06CC \u0633\u0631\u0639\u062A \u0639\u0645\u0644 \u0628\u0627\u0644\u0627 \u062F\u0631 \u0628\u0627\u0632\u0627\u0631\u061B \u062B\u0628\u062A \u06CC\u06A9 \u062D\u0648\u0627\u0644\u0647 \u06A9\u0627\u0645\u0644 \u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F3\u06F0 \u062B\u0627\u0646\u06CC\u0647 \u0632\u0645\u0627\u0646 \u0645\u06CC\u200C\u0628\u0631\u062F.",
          imageUrl: "/media/android_pocket_ui.png",
          highlights: ["\u06A9\u06CC\u0628\u0648\u0631\u062F \u0639\u062F\u062F\u06CC \u0628\u0632\u0631\u06AF \u0648 \u0633\u0631\u06CC\u0639", "\u0641\u06CC\u0644\u062F\u0647\u0627\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u062A\u0628\u062F\u06CC\u0644 \u0646\u0631\u062E", "\u0641\u0647\u0631\u0633\u062A \u0645\u062E\u0627\u0637\u0628\u06CC\u0646 \u062A\u062C\u0627\u0631\u06CC \u067E\u0631\u062A\u06A9\u0631\u0627\u0631"],
          stat: { label: "\u0633\u0631\u0639\u062A \u062B\u0628\u062A", value: "\u06F3\u06F0 \u062B\u0627\u0646\u06CC\u0647" }
        },
        {
          title: "\u067E\u0631\u06CC\u0646\u062A \u0641\u0648\u0631\u06CC \u0631\u0648\u06CC \u0686\u0627\u067E\u06AF\u0631\u0647\u0627\u06CC \u0647\u0645\u0631\u0627\u0647",
          description: "\u0628\u062F\u0648\u0646 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0646\u0635\u0628 \u062F\u0631\u0627\u06CC\u0648\u0631\u0647\u0627\u06CC \u067E\u06CC\u0686\u06CC\u062F\u0647\u060C \u0628\u0627 \u06CC\u06A9 \u0644\u0645\u0633 \u0628\u0647 \u067E\u0631\u06CC\u0646\u062A\u0631 \u06A9\u0645\u0631\u06CC \u0645\u062A\u0635\u0644 \u0634\u062F\u0647 \u0648 \u0642\u0628\u0636 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0686\u0627\u067E\u06CC \u0628\u0647 \u0645\u0634\u062A\u0631\u06CC \u062A\u062D\u0648\u06CC\u0644 \u062F\u0647\u06CC\u062F.",
          imageUrl: "/media/android_bluetooth_print.png",
          highlights: ["\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u0686\u0627\u067E\u06AF\u0631\u0647\u0627\u06CC \u06F5\u06F8 \u0648 \u06F8\u06F0 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631\u06CC", "\u0686\u0627\u067E \u0644\u0648\u06AF\u0648\u06CC \u062F\u0641\u062A\u0631 \u0635\u0631\u0627\u0641\u06CC", "\u0628\u062F\u0648\u0646 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u06A9\u0627\u0628\u0644"],
          stat: { label: "\u0633\u0627\u0632\u06AF\u0627\u0631\u06CC \u0628\u0644\u0648\u062A\u0648\u062B", value: "\u06F1\u06F0\u06F0\u066A \u0645\u062F\u0644\u200C\u0647\u0627\u06CC \u0628\u0627\u0632\u0627\u0631" }
        }
      ]
    },
    {
      id: "ashk-warehouse-order-android",
      name: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0648 \u062B\u0628\u062A \u0633\u0641\u0627\u0631\u0634 \u0648\u06CC\u0632\u06CC\u062A\u0648\u0631 \u0627\u0634\u06A9",
      englishName: "Ashk Smart Inventory & Order Android",
      version: "v3.1.0",
      category: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646\u200C\u0647\u0627\u06CC \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u0627\u0646\u062F\u0631\u0648\u06CC\u062F",
      shortDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u062A\u0628\u0644\u062A \u0648 \u0645\u0648\u0628\u0627\u06CC\u0644 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u0628\u0631\u0627\u06CC \u0627\u0646\u0628\u0627\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC \u0628\u0627 \u0628\u0627\u0631\u06A9\u062F\u062E\u0648\u0627\u0646\u060C \u0627\u0633\u06A9\u0646 \u06A9\u0627\u0644\u0627\u060C \u0648\u06CC\u0632\u06CC\u062A\u0648\u0631\u06CC \u0648 \u0635\u062F\u0648\u0631 \u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631 \u062F\u0631 \u0645\u062D\u0644.",
      fullDesc: "\u0627\u067E\u0644\u06CC\u06A9\u06CC\u0634\u0646 \u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u0648 \u0641\u0631\u0648\u0634 \u0645\u06CC\u062F\u0627\u0646\u06CC \u0627\u0634\u06A9\u060C \u0627\u0628\u0632\u0627\u0631\u06CC \u0642\u062F\u0631\u062A\u0645\u0646\u062F \u0628\u0631\u0627\u06CC \u067E\u0631\u0633\u0646\u0644 \u0627\u0646\u0628\u0627\u0631 \u0648 \u062A\u06CC\u0645 \u0628\u0627\u0632\u0627\u0631\u06CC\u0627\u0628\u06CC \u0648 \u0641\u0631\u0648\u0634 \u0627\u0633\u062A. \u0628\u0627\u0632\u0627\u0631\u06CC\u0627\u0628 \u0628\u0627 \u062F\u0627\u0634\u062A\u0646 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u062F\u06CC\u062C\u06CC\u062A\u0627\u0644 \u0645\u062D\u0635\u0648\u0644\u0627\u062A \u0631\u0648\u06CC \u062A\u0628\u0644\u062A\u060C \u0633\u0641\u0627\u0631\u0634\u0627\u062A \u0645\u0634\u062A\u0631\u06CC \u0631\u0627 \u062D\u062A\u06CC \u062F\u0631 \u0646\u0642\u0627\u0637 \u06A9\u0648\u0631 \u0628\u062F\u0648\u0646 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A \u062B\u0628\u062A \u0646\u0645\u0648\u062F\u0647 \u0648 \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631 \u0628\u0627 \u0627\u0633\u06A9\u0646 \u0628\u0627\u0631\u06A9\u062F \u0628\u0633\u062A\u0647\u200C\u0647\u0627\u060C \u0648\u0631\u0648\u062F \u0648 \u062E\u0631\u0648\u062C \u0628\u0627\u0631 \u0631\u0627 \u0628\u062F\u0648\u0646 \u062E\u0637\u0627\u06CC \u0627\u0646\u0633\u0627\u0646\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u0645\u0633\u062A\u0646\u062F \u0645\u06CC\u200C\u06A9\u0646\u062F.",
      badge: "\u06A9\u0627\u0631\u0628\u0631\u062F\u06CC\u200C\u062A\u0631\u06CC\u0646 \u0627\u0628\u0632\u0627\u0631 \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC",
      color: "from-purple-600 via-fuchsia-600 to-pink-700",
      iconName: "Box",
      featured: false,
      downloadCondition: "requires_registration",
      downloadUrl: "/downloads/ashk_inventory_android.apk",
      downloadSize: "34 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A (\u0641\u0627\u06CC\u0644 \u0646\u0635\u0628\u06CC APK)",
      releaseDatePersian: "\u06F1\u06F4\u06F0\u06F4/\u06F0\u06F5/\u06F2\u06F8",
      capabilities: [
        "\u0627\u0633\u06A9\u0646 \u0641\u0648\u0642\u200C\u0633\u0631\u06CC\u0639 \u0628\u0627\u0631\u06A9\u062F \u06A9\u0627\u0644\u0627\u0647\u0627 \u0628\u0627 \u062F\u0648\u0631\u0628\u06CC\u0646 \u06AF\u0648\u0634\u06CC \u06CC\u0627 \u062F\u0633\u062A\u06AF\u0627\u0647\u200C\u0647\u0627\u06CC \u0647\u0646\u062F\u0644\u062F \u0635\u0646\u0639\u062A\u06CC (Urovo, Point Mobile, iData)",
        "\u0627\u0646\u0628\u0627\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC \u0622\u0633\u0627\u0646 \u0648 \u0645\u0642\u0627\u06CC\u0633\u0647 \u0645\u0648\u062C\u0648\u062F\u06CC \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0628\u0627 \u0645\u0648\u062C\u0648\u062F\u06CC \u0633\u06CC\u0633\u062A\u0645\u06CC \u0648 \u062B\u0628\u062A \u06A9\u0633\u0631\u06CC/\u0627\u0636\u0627\u0641\u06CC",
        "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u062F\u06CC\u062C\u06CC\u062A\u0627\u0644 \u062A\u0635\u0648\u06CC\u0631\u06CC \u0627\u0632 \u0645\u062D\u0635\u0648\u0644\u0627\u062A \u0628\u0631\u0627\u06CC \u067E\u0631\u0632\u0646\u062A \u062D\u0636\u0648\u0631\u06CC \u0648\u06CC\u0632\u06CC\u062A\u0648\u0631\u0647\u0627 \u0646\u0632\u062F \u0645\u0634\u062A\u0631\u06CC",
        "\u062B\u0628\u062A \u0633\u0641\u0627\u0631\u0634\u0627\u062A \u0641\u0631\u0648\u0634 \u0648 \u0635\u062F\u0648\u0631 \u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631 \u0628\u0627 \u0627\u0639\u0645\u0627\u0644 \u062A\u062E\u0641\u06CC\u0641\u0627\u062A \u067E\u0644\u06A9\u0627\u0646\u06CC \u0628\u0647 \u0635\u0648\u0631\u062A \u0622\u0641\u0644\u0627\u06CC\u0646",
        "\u0645\u062D\u0627\u0633\u0628\u0647 \u0633\u0642\u0641 \u0627\u0639\u062A\u0628\u0627\u0631 \u0645\u0634\u062A\u0631\u06CC \u0648 \u0647\u0634\u062F\u0627\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627\u06CC \u062A\u0633\u0648\u06CC\u0647 \u0646\u0634\u062F\u0647 \u0642\u0628\u0644\u06CC",
        "\u0627\u0646\u062A\u0642\u0627\u0644 \u0622\u0646\u06CC \u0627\u0633\u0646\u0627\u062F \u0628\u0647 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0627\u0634\u06A9 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0634\u0628\u06A9\u0647 \u062F\u0627\u062E\u0644\u06CC"
      ],
      specs: {
        os: "\u0627\u0646\u062F\u0631\u0648\u06CC\u062F \u06F7.\u06F1 \u0628\u0647 \u0628\u0627\u0644\u0627 (\u0633\u0627\u0632\u06AF\u0627\u0631 \u0628\u0627 \u06A9\u0644\u06CC\u0647 \u06AF\u0648\u0634\u06CC\u200C\u0647\u0627\u060C \u062A\u0628\u0644\u062A\u200C\u0647\u0627 \u0648 \u0647\u0646\u062F\u0644\u062F\u0647\u0627\u06CC \u0635\u0646\u0639\u062A\u06CC)",
        ram: "\u062D\u062F\u0627\u0642\u0644 \u06F2 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A",
        gpu: "\u0628\u0647\u06CC\u0646\u0647\u200C\u0634\u062F\u0647 \u0628\u0631\u0627\u06CC \u0645\u0635\u0631\u0641 \u062D\u062F\u0627\u0642\u0644 \u0628\u0627\u062A\u0631\u06CC \u062F\u0631 \u0634\u06CC\u0641\u062A\u200C\u0647\u0627\u06CC \u06A9\u0627\u0631\u06CC \u0637\u0648\u0644\u0627\u0646\u06CC",
        database: "\u0628\u0627\u0646\u06A9 \u0627\u0637\u0644\u0627\u0639\u0627\u062A\u06CC \u0645\u062D\u0644\u06CC \u0622\u0641\u0644\u0627\u06CC\u0646 \u0628\u0627 \u0642\u0627\u0628\u0644\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u06F2\u06F0,\u06F0\u06F0\u06F0 \u0642\u0644\u0645 \u06A9\u0627\u0644\u0627",
        offlineEngine: true
      },
      plans: [
        {
          name: "\u0646\u0633\u062E\u0647 \u0631\u0627\u06CC\u06AF\u0627\u0646 \u062B\u0628\u062A\u200C\u0646\u0627\u0645\u06CC",
          price: "\u0631\u0627\u06CC\u06AF\u0627\u0646 \u0628\u0627 \u0639\u0636\u0648\u06CC\u062A \u062F\u0631 \u0633\u0627\u0645\u0627\u0646\u0647",
          period: "\u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u062F\u0627\u0626\u0645",
          features: ["\u0627\u0633\u06A9\u0646 \u0628\u0627\u0631\u06A9\u062F \u062A\u0627 \u06F2\u06F0\u06F0 \u06A9\u0627\u0644\u0627", "\u0627\u0646\u0628\u0627\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC \u067E\u0627\u06CC\u0647", "\u062B\u0628\u062A \u0633\u0641\u0627\u0631\u0634 \u0631\u0648\u0632\u0627\u0646\u0647"],
          conditionType: "requires_registration"
        },
        {
          name: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u0646\u0627\u0645\u062D\u062F\u0648\u062F \u062A\u062C\u0627\u0631\u06CC",
          price: "\u06F4,\u06F5\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u062F\u0627\u0626\u0645\u06CC \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u0622\u067E\u062F\u06CC\u062A\u200C\u0647\u0627",
          features: ["\u06A9\u0627\u0644\u0627\u0647\u0627\u06CC \u0646\u0627\u0645\u062D\u062F\u0648\u062F", "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u0647\u0646\u062F\u0644\u062F\u0647\u0627\u06CC \u0644\u06CC\u0632\u0631\u06CC", "\u0645\u0627\u0698\u0648\u0644 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u062A\u0635\u0648\u06CC\u0631\u06CC \u0648\u06CC\u0632\u06CC\u062A\u0648\u0631", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u06A9\u0627\u0645\u0644"],
          recommended: true,
          conditionType: "requires_license"
        }
      ],
      catalogPages: [
        {
          title: "\u0627\u0633\u06A9\u0646 \u0628\u0627\u0631\u06A9\u062F \u062F\u0631 \u06A9\u0633\u0631\u06CC \u0627\u0632 \u062B\u0627\u0646\u06CC\u0647",
          description: "\u0645\u0648\u062A\u0648\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u062A\u0635\u0648\u06CC\u0631 \u062F\u0627\u062E\u0644\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u060C \u0628\u0627\u0631\u06A9\u062F\u0647\u0627\u06CC \u0645\u062E\u062F\u0648\u0634 \u06CC\u0627 \u06A9\u0645\u200C\u0631\u0646\u06AF \u0631\u0627 \u0646\u06CC\u0632 \u0628\u0627 \u0633\u0631\u0639\u062A \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0648 \u0645\u0634\u062E\u0635\u0627\u062A \u06A9\u0627\u0644\u0627 \u0631\u0627 \u0631\u0648\u06CC \u0635\u0641\u062D\u0647 \u0645\u06CC\u200C\u0622\u0648\u0631\u062F.",
          imageUrl: "/media/inventory_scan.png",
          highlights: ["\u062A\u0634\u062E\u06CC\u0635 \u0628\u0627\u0631\u06A9\u062F \u0645\u06CC\u0644\u0647\u200C\u0627\u06CC \u0648 QR", "\u0635\u062F\u0648\u0631 \u0628\u0648\u0642 \u062A\u0627\u06CC\u06CC\u062F \u0648 \u0644\u0631\u0632\u0634", "\u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u0627\u0632 \u0634\u0645\u0627\u0631\u0634 \u062A\u06A9\u0631\u0627\u0631\u06CC"],
          stat: { label: "\u06A9\u0627\u0647\u0634 \u062E\u0637\u0627\u06CC \u0627\u0646\u0628\u0627\u0631", value: "\u06F9\u06F9.\u06F5\u066A" }
        },
        {
          title: "\u062B\u0628\u062A \u0633\u0641\u0627\u0631\u0634\u0627\u062A \u0648 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0648\u06CC\u0632\u06CC\u062A\u0648\u0631\u06CC",
          description: "\u0648\u06CC\u0632\u06CC\u062A\u0648\u0631 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u062A\u0635\u0627\u0648\u06CC\u0631 \u06A9\u06CC\u0641\u06CC\u062A \u0628\u0627\u0644\u0627\u06CC \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC\u060C \u0645\u0634\u062E\u0635\u0627\u062A \u06A9\u0627\u0631\u062A\u0646 \u0648 \u0642\u06CC\u0645\u062A\u200C\u0647\u0627 \u0631\u0627 \u0628\u0647 \u062E\u0631\u06CC\u062F\u0627\u0631 \u0646\u0634\u0627\u0646 \u062F\u0647\u062F \u0648 \u0633\u0641\u0627\u0631\u0634 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u062F.",
          imageUrl: "/media/visitor_catalog.png",
          highlights: ["\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0648\u0631\u0642\u200C\u0632\u0646 \u062A\u0635\u0648\u06CC\u0631\u06CC", "\u0645\u062D\u0627\u0633\u0628\u0647 \u062F\u0631\u0635\u062F \u067E\u0648\u0631\u0633\u0627\u0646\u062A", "\u0635\u062F\u0648\u0631 \u0622\u0646\u06CC \u0641\u0627\u06A9\u062A\u0648\u0631 \u062F\u0631 \u0645\u062D\u0644"],
          stat: { label: "\u0627\u0641\u0632\u0627\u06CC\u0634 \u0641\u0631\u0648\u0634 \u0645\u06CC\u062F\u0627\u0646\u06CC", value: "\u06F2.\u06F5 \u0628\u0631\u0627\u0628\u0631" }
        }
      ]
    },
    {
      id: "ashk-payroll-hrm",
      name: "\u0633\u0627\u0645\u0627\u0646\u0647 \u0645\u062F\u06CC\u0631\u06CC\u062A \u062D\u0642\u0648\u0642 \u0648 \u062F\u0633\u062A\u0645\u0632\u062F \u0648 \u062A\u0631\u062F\u062F \u067E\u0631\u0633\u0646\u0644 \u0627\u0634\u06A9",
      englishName: "Ashk Payroll & Attendance HRM",
      version: "v2.9.0",
      category: "\u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0648 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC",
      shortDesc: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u062C\u0627\u0645\u0639 \u0645\u062D\u0627\u0633\u0628\u0647 \u062D\u0642\u0648\u0642 \u0648 \u0645\u0632\u0627\u06CC\u0627\u060C \u0634\u06CC\u0641\u062A\u200C\u0647\u0627\u06CC \u06A9\u0627\u0631\u06CC\u060C \u0645\u0631\u062E\u0635\u06CC \u0648 \u0645\u0627\u0645\u0648\u0631\u06CC\u062A \u0628\u0627 \u062E\u0631\u0648\u062C\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u062F\u06CC\u0633\u06A9\u062A \u0628\u06CC\u0645\u0647 \u0648 \u0628\u0627\u0646\u06A9.",
      fullDesc: "\u0633\u0627\u0645\u0627\u0646\u0647 \u062D\u0642\u0648\u0642 \u0648 \u062F\u0633\u062A\u0645\u0632\u062F \u0627\u0634\u06A9 \u0645\u0646\u0637\u0628\u0642 \u0628\u0631 \u0622\u062E\u0631\u06CC\u0646 \u0642\u0648\u0627\u0646\u06CC\u0646 \u0648\u0632\u0627\u0631\u062A \u06A9\u0627\u0631 \u0648 \u0633\u0627\u0632\u0645\u0627\u0646 \u062A\u0627\u0645\u06CC\u0646 \u0627\u062C\u062A\u0645\u0627\u0639\u06CC \u06A9\u0634\u0648\u0631 \u0627\u0633\u062A. \u0627\u06CC\u0646 \u0633\u06CC\u0633\u062A\u0645 \u0628\u0647 \u062F\u0633\u062A\u06AF\u0627\u0647\u200C\u0647\u0627\u06CC \u0633\u0627\u0639\u062A\u200C\u0632\u0646\u06CC \u0627\u062B\u0631\u0627\u0646\u06AF\u0634\u062A \u0648 \u062A\u0634\u062E\u06CC\u0635 \u0686\u0647\u0631\u0647 \u0645\u062A\u0635\u0644 \u0634\u062F\u0647 \u0648 \u0627\u0636\u0627\u0641\u0647 \u06A9\u0627\u0631\u060C \u06A9\u0633\u0631 \u06A9\u0627\u0631\u060C \u0634\u0628\u200C\u06A9\u0627\u0631\u06CC\u060C \u062D\u0642 \u0627\u0648\u0644\u0627\u062F \u0648 \u0628\u0646 \u062E\u0648\u0627\u0631\u0648\u0628\u0627\u0631 \u0631\u0627 \u0645\u062D\u0627\u0633\u0628\u0647 \u06A9\u0631\u062F\u0647 \u0648 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u062F\u06CC\u0633\u06A9\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u062D\u0642\u0648\u0642 \u0628\u0627\u0646\u06A9 \u0648 \u0644\u06CC\u0633\u062A \u0628\u06CC\u0645\u0647 \u0631\u0627 \u0628\u062F\u0648\u0646 \u062E\u0637\u0627 \u062A\u0648\u0644\u06CC\u062F \u0645\u06CC\u200C\u06A9\u0646\u062F.",
      badge: "\u062F\u0642\u062A \u0645\u062D\u0627\u0633\u0628\u0627\u062A\u06CC \u0628\u0627\u0644\u0627",
      color: "from-teal-600 via-emerald-600 to-green-700",
      iconName: "Users",
      featured: false,
      downloadCondition: "requires_registration",
      downloadUrl: "/downloads/ashk_payroll_setup_v2.9.exe",
      downloadSize: "95 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A",
      releaseDatePersian: "\u06F1\u06F4\u06F0\u06F4/\u06F0\u06F6/\u06F0\u06F1",
      capabilities: [
        "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0627\u0632 \u0622\u062E\u0631\u06CC\u0646 \u0636\u0631\u0627\u06CC\u0628 \u0648 \u062C\u062F\u0627\u0648\u0644 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC \u0633\u0627\u0644 \u062C\u062F\u06CC\u062F \u0648\u0632\u0627\u0631\u062A \u0627\u0642\u062A\u0635\u0627\u062F \u0648 \u062F\u0627\u0631\u0627\u06CC\u06CC",
        "\u062A\u0648\u0644\u06CC\u062F \u062E\u0648\u062F\u06A9\u0627\u0631 \u062F\u06CC\u0633\u06A9\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9\u06CC \u062D\u0642\u0648\u0642 \u0628\u0631\u0627\u06CC \u0628\u0627\u0646\u06A9\u200C\u0647\u0627\u06CC \u0645\u0644\u06CC\u060C \u0645\u0644\u062A\u060C \u0635\u0627\u062F\u0631\u0627\u062A\u060C \u062A\u062C\u0627\u0631\u062A\u060C \u067E\u0627\u0633\u0627\u0631\u06AF\u0627\u062F \u0648...",
        "\u062E\u0631\u0648\u062C\u06CC \u0641\u0627\u06CC\u0644 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u062F\u06CC\u0633\u06A9\u062A \u0628\u06CC\u0645\u0647 \u062A\u0627\u0645\u06CC\u0646 \u0627\u062C\u062A\u0645\u0627\u0639\u06CC \u0628\u0627 \u0641\u0631\u0645\u062A DSK",
        "\u0645\u062D\u0627\u0633\u0628\u0647 \u0639\u06CC\u062F\u06CC\u060C \u067E\u0627\u062F\u0627\u0634\u060C \u0633\u0646\u0648\u0627\u062A \u067E\u0627\u06CC\u0627\u0646 \u062E\u062F\u0645\u062A \u0648 \u0645\u0627\u0646\u062F\u0647 \u0645\u0631\u062E\u0635\u06CC \u0628\u0627 \u0641\u0631\u0645\u0648\u0644\u200C\u0647\u0627\u06CC \u062F\u0642\u06CC\u0642 \u0642\u0627\u0646\u0648\u0646\u06CC",
        "\u0637\u0631\u0627\u062D\u06CC \u0648 \u0686\u0627\u067E \u0641\u06CC\u0634 \u062D\u0642\u0648\u0642\u06CC \u0645\u062D\u0631\u0645\u0627\u0646\u0647 \u0628\u0627 \u0627\u0646\u0648\u0627\u0639 \u0642\u0627\u0644\u0628\u200C\u0647\u0627\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0648 \u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9\u06CC \u0628\u0647 \u067E\u0631\u0633\u0646\u0644",
        "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u0627\u0646\u0648\u0627\u0639 \u062F\u0633\u062A\u06AF\u0627\u0647\u200C\u0647\u0627\u06CC \u0633\u0627\u0639\u062A\u200C\u0632\u0646\u06CC \u06A9\u0627\u0631\u062A\u060C \u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A \u0648 \u062F\u0648\u0631\u0628\u06CC\u0646 \u062A\u0634\u062E\u06CC\u0635 \u0686\u0647\u0631\u0647 \u062F\u0631 \u0634\u0628\u06A9\u0647 \u062F\u0627\u062E\u0644\u06CC"
      ],
      specs: {
        os: "\u0648\u06CC\u0646\u062F\u0648\u0632 \u06F1\u06F0 / \u06F1\u06F1 / \u0633\u0631\u0648\u0631",
        ram: "\u062D\u062F\u0627\u0642\u0644 \u06F4 \u06AF\u06CC\u06AF\u0627\u0628\u0627\u06CC\u062A",
        gpu: "\u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F",
        database: "\u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u0645\u062D\u0644\u06CC \u0627\u06CC\u0645\u0646 \u0628\u0627 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u200C\u06AF\u06CC\u0631\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631",
        offlineEngine: true
      },
      plans: [
        {
          name: "\u0646\u0633\u062E\u0647 \u06A9\u0627\u0631\u06AF\u0627\u0647\u06CC (\u062A\u0627 \u06F1\u06F5 \u0646\u0641\u0631)",
          price: "\u0631\u0627\u06CC\u06AF\u0627\u0646 \u0628\u0627 \u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0627\u0648\u0644\u06CC\u0647",
          period: "\u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u062F\u0627\u0626\u0645",
          features: ["\u0645\u062D\u0627\u0633\u0628\u0647 \u062D\u0642\u0648\u0642 \u062A\u0627 \u06F1\u06F5 \u067E\u0631\u0633\u0646\u0644", "\u062A\u0648\u0644\u06CC\u062F \u062F\u06CC\u0633\u06A9\u062A \u0628\u06CC\u0645\u0647", "\u0686\u0627\u067E \u0641\u06CC\u0634 \u062D\u0642\u0648\u0642\u06CC", "\u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u200C\u06AF\u06CC\u0631\u06CC"],
          conditionType: "requires_registration"
        },
        {
          name: "\u0646\u0633\u062E\u0647 \u0633\u0627\u0632\u0645\u0627\u0646\u06CC \u0646\u0627\u0645\u062D\u062F\u0648\u062F",
          price: "\u06F5,\u06F8\u06F0\u06F0,\u06F0\u06F0\u06F0 \u062A\u0648\u0645\u0627\u0646",
          period: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u062F\u0627\u0626\u0645\u06CC \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0633\u0627\u0644\u0627\u0646\u0647",
          features: ["\u067E\u0631\u0633\u0646\u0644 \u0646\u0627\u0645\u062D\u062F\u0648\u062F", "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u062F\u0633\u062A\u06AF\u0627\u0647 \u06A9\u0627\u0631\u062A\u200C\u0632\u0646\u06CC", "\u062A\u0648\u0644\u06CC\u062F \u062F\u06CC\u0633\u06A9\u062A \u062A\u0645\u0627\u0645 \u0628\u0627\u0646\u06A9\u200C\u0647\u0627", "\u0645\u062D\u0627\u0633\u0628\u0647 \u062A\u0633\u0648\u06CC\u0647 \u062D\u0633\u0627\u0628 \u0633\u0646\u0648\u0627\u062A"],
          recommended: true,
          conditionType: "requires_license"
        }
      ],
      catalogPages: [
        {
          title: "\u0645\u062D\u0627\u0633\u0628\u0627\u062A \u0628\u062F\u0648\u0646 \u062E\u0637\u0627\u06CC \u0627\u062D\u06A9\u0627\u0645 \u067E\u0631\u0633\u0646\u0644\u06CC",
          description: "\u062A\u0646\u0638\u06CC\u0645 \u067E\u0627\u0631\u0627\u0645\u062A\u0631\u06CC\u06A9 \u067E\u0627\u06CC\u0647\u200C\u0647\u0627\u06CC \u062D\u0642\u0648\u0642\u06CC\u060C \u062D\u0642 \u062C\u0630\u0628\u060C \u062D\u0642 \u0634\u06CC\u0641\u062A \u0648 \u0645\u0633\u06A9\u0646 \u0645\u0637\u0627\u0628\u0642 \u0628\u062E\u0634\u0646\u0627\u0645\u0647\u200C\u0647\u0627\u06CC \u062C\u062F\u06CC\u062F \u0634\u0648\u0631\u0627\u06CC \u0639\u0627\u0644\u06CC \u06A9\u0627\u0631.",
          imageUrl: "/media/payroll_calc.png",
          highlights: ["\u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0628\u062E\u0634\u0646\u0627\u0645\u0647\u200C\u0647\u0627", "\u06AF\u0632\u0627\u0631\u0634 \u062A\u0641\u06A9\u06CC\u06A9\u06CC \u06A9\u0633\u0648\u0631\u0627\u062A", "\u0645\u062D\u0627\u0633\u0628\u0647 \u062F\u0642\u06CC\u0642 \u062D\u0642 \u0628\u06CC\u0645\u0647 \u0633\u0647\u0645 \u06A9\u0627\u0631\u06AF\u0631 \u0648 \u06A9\u0627\u0631\u0641\u0631\u0645\u0627"],
          stat: { label: "\u0633\u0631\u0639\u062A \u0635\u062F\u0648\u0631 \u0641\u06CC\u0634\u200C\u0647\u0627", value: "\u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F1 \u062F\u0642\u06CC\u0642\u0647" }
        }
      ]
    }
  ];
  function getSoftwareProductsData() {
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      if (import_fs.default.existsSync(softwareProductsFilePath)) {
        const raw = import_fs.default.readFileSync(softwareProductsFilePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
      import_fs.default.writeFileSync(softwareProductsFilePath, JSON.stringify(defaultSoftwareProducts, null, 2), "utf-8");
      return defaultSoftwareProducts;
    } catch (e) {
      console.error("Error reading software products:", e);
      return defaultSoftwareProducts;
    }
  }
  function getSoftwareLicensesData() {
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      if (import_fs.default.existsSync(softwareLicensesFilePath)) {
        const raw = import_fs.default.readFileSync(softwareLicensesFilePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch (e) {
      return [];
    }
  }
  app.get("/api/software/products", (req, res) => {
    try {
      const products = getSoftwareProductsData();
      const category = req.query.category;
      if (category && category !== "all" && category !== "\u0647\u0645\u0647") {
        const filtered = products.filter((p) => p.category === category);
        return res.json({ success: true, count: filtered.length, products: filtered });
      }
      res.json({ success: true, count: products.length, products });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0644\u06CC\u0633\u062A \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u0647\u0627: " + err.message });
    }
  });
  app.get("/api/software/products/:id", (req, res) => {
    try {
      const products = getSoftwareProductsData();
      const product = products.find((p) => p.id === req.params.id);
      if (!product) {
        return res.status(404).json({ error: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
      }
      res.json({ success: true, product });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0645\u0634\u062E\u0635\u0627\u062A \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631: " + err.message });
    }
  });
  app.post("/api/software/products", import_express3.default.json({ limit: "50mb" }), (req, res) => {
    try {
      const productData = req.body;
      if (!productData || !productData.name) {
        return res.status(400).json({ error: "\u0646\u0627\u0645 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
      }
      const products = getSoftwareProductsData();
      const prodId = productData.id || `soft-${Date.now()}`;
      productData.id = prodId;
      const existingIndex = products.findIndex((p) => p.id === prodId);
      if (existingIndex >= 0) {
        products[existingIndex] = { ...products[existingIndex], ...productData, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      } else {
        productData.createdAt = (/* @__PURE__ */ new Date()).toISOString();
        products.unshift(productData);
      }
      import_fs.default.writeFileSync(softwareProductsFilePath, JSON.stringify(products, null, 2), "utf-8");
      res.json({ success: true, product: productData });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u062F\u0631 \u0628\u06A9\u200C\u0627\u0646\u062F: " + err.message });
    }
  });
  app.delete("/api/software/products/:id", (req, res) => {
    try {
      const id = req.params.id;
      let products = getSoftwareProductsData();
      products = products.filter((p) => p.id !== id);
      import_fs.default.writeFileSync(softwareProductsFilePath, JSON.stringify(products, null, 2), "utf-8");
      res.json({ success: true, message: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u06AF\u0631\u062F\u06CC\u062F." });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062D\u0630\u0641 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631: " + err.message });
    }
  });
  app.post("/api/software/license/request", import_express3.default.json(), (req, res) => {
    try {
      const { productId, planName, customerName, customerPhone, customerEmail, companyName, hardwareId } = req.body;
      if (!productId || !customerName || !customerPhone) {
        return res.status(400).json({ error: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0645\u062A\u0642\u0627\u0636\u06CC (\u0646\u0627\u0645\u060C \u0634\u0645\u0627\u0631\u0647 \u062A\u0645\u0627\u0633 \u0648 \u0634\u0646\u0627\u0633\u0647 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631) \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
      }
      const products = getSoftwareProductsData();
      const product = products.find((p) => p.id === productId);
      if (!product) {
        return res.status(404).json({ error: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
      }
      const salt = "ASHK-GHALAM-SECURE-KEY-2026";
      const cleanPhone = String(customerPhone).replace(/[^0-9]/g, "");
      const rawPayload = `${productId}:${cleanPhone}:${Date.now()}:${salt}`;
      const hash = import_crypto.default.createHash("sha256").update(rawPayload).digest("hex").toUpperCase();
      const formattedLicenseKey = `ASHK-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
      const newLicenseRecord = {
        id: `lic_${Date.now()}`,
        licenseKey: formattedLicenseKey,
        productId,
        productName: product.name,
        planName: planName || "\u0646\u0633\u062E\u0647 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F",
        customerName,
        customerPhone: cleanPhone,
        customerEmail: customerEmail || "",
        companyName: companyName || "",
        hardwareId: hardwareId || "AUTO-DETECTED-HWID",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "ACTIVE",
        expiresAt: "PERMANENT"
      };
      const licenses = getSoftwareLicensesData();
      licenses.unshift(newLicenseRecord);
      import_fs.default.writeFileSync(softwareLicensesFilePath, JSON.stringify(licenses, null, 2), "utf-8");
      res.json({
        success: true,
        licenseKey: formattedLicenseKey,
        license: newLicenseRecord,
        downloadUrl: product.downloadUrl,
        message: "\u0644\u0627\u06CC\u0633\u0646\u0633 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0635\u0627\u062F\u0631 \u06AF\u0631\u062F\u06CC\u062F."
      });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0635\u062F\u0648\u0631 \u0644\u0627\u06CC\u0633\u0646\u0633: " + err.message });
    }
  });
  app.post("/api/software/download/verify", import_express3.default.json(), (req, res) => {
    try {
      const { productId, userEmail, userPhone, licenseKey } = req.body;
      const products = getSoftwareProductsData();
      const product = products.find((p) => p.id === productId);
      if (!product) {
        return res.status(404).json({ error: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
      }
      const condition = product.downloadCondition || "free";
      if (condition === "free") {
        return res.json({
          authorized: true,
          downloadUrl: product.downloadUrl,
          message: "\u062F\u0627\u0646\u0644\u0648\u062F \u0627\u06CC\u0646 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0622\u0632\u0627\u062F \u0648 \u0631\u0627\u06CC\u06AF\u0627\u0646 \u0627\u0633\u062A."
        });
      }
      if (condition === "requires_registration") {
        if (!userEmail && !userPhone) {
          return res.status(401).json({
            authorized: false,
            requiresAuth: true,
            message: "\u0628\u0631\u0627\u06CC \u062F\u0627\u0646\u0644\u0648\u062F \u0627\u06CC\u0646 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u060C \u0644\u0637\u0641\u0627\u064B \u0627\u0628\u062A\u062F\u0627 \u062F\u0631 \u0633\u0627\u0645\u0627\u0646\u0647 \u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0646\u0645\u0648\u062F\u0647 \u06CC\u0627 \u0648\u0627\u0631\u062F \u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u062E\u0648\u062F \u0634\u0648\u06CC\u062F."
          });
        }
        return res.json({
          authorized: true,
          downloadUrl: product.downloadUrl,
          message: "\u062F\u0633\u062A\u0631\u0633\u06CC \u062F\u0627\u0646\u0644\u0648\u062F \u0628\u0631 \u0627\u0633\u0627\u0633 \u0639\u0636\u0648\u06CC\u062A \u062F\u0631 \u0633\u0627\u0645\u0627\u0646\u0647 \u062A\u0627\u06CC\u06CC\u062F \u06AF\u0631\u062F\u06CC\u062F."
        });
      }
      if (condition === "requires_license") {
        if (!licenseKey) {
          return res.status(403).json({
            authorized: false,
            requiresLicense: true,
            message: "\u062F\u0627\u0646\u0644\u0648\u062F \u0648 \u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u0627\u06CC\u0646 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0646\u06CC\u0627\u0632\u0645\u0646\u062F \u062B\u0628\u062A \u06A9\u062F \u0644\u0627\u06CC\u0633\u0646\u0633 \u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A."
          });
        }
        const licenses = getSoftwareLicensesData();
        const validLic = licenses.find(
          (l) => l.productId === productId && l.licenseKey.trim().toUpperCase() === String(licenseKey).trim().toUpperCase() && l.status === "ACTIVE"
        );
        if (!validLic) {
          return res.status(403).json({
            authorized: false,
            requiresLicense: true,
            message: "\u06A9\u062F \u0644\u0627\u06CC\u0633\u0646\u0633 \u0648\u0627\u0631\u062F \u0634\u062F\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0628\u0648\u062F\u0647 \u06CC\u0627 \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0635\u0627\u062F\u0631 \u0646\u06AF\u0631\u062F\u06CC\u062F\u0647 \u0627\u0633\u062A."
          });
        }
        return res.json({
          authorized: true,
          downloadUrl: product.downloadUrl,
          message: "\u06A9\u062F \u0644\u0627\u06CC\u0633\u0646\u0633 \u062A\u0627\u06CC\u06CC\u062F \u0634\u062F. \u0644\u06CC\u0646\u06A9 \u062F\u0627\u0646\u0644\u0648\u062F \u0641\u0639\u0627\u0644 \u06AF\u0631\u062F\u06CC\u062F."
        });
      }
      res.json({ authorized: true, downloadUrl: product.downloadUrl });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u062F\u0627\u0646\u0644\u0648\u062F: " + err.message });
    }
  });
  app.get("/api/software/licenses/list", (req, res) => {
    try {
      const licenses = getSoftwareLicensesData();
      res.json({ success: true, count: licenses.length, licenses });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0644\u06CC\u0633\u062A \u0644\u0627\u06CC\u0633\u0646\u0633\u200C\u0647\u0627: " + err.message });
    }
  });
  const settingsFilePath = import_path.default.join(uploadsDir, "global_settings.json");
  const publicSettingsFilePath = import_path.default.join(_dirname, "public", "global_settings.json");
  app.get("/api/settings/global", (req, res) => {
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      if (import_fs.default.existsSync(settingsFilePath)) {
        const content = import_fs.default.readFileSync(settingsFilePath, "utf-8");
        return res.json(JSON.parse(content));
      }
      if (import_fs.default.existsSync(publicSettingsFilePath)) {
        const content = import_fs.default.readFileSync(publicSettingsFilePath, "utf-8");
        return res.json(JSON.parse(content));
      }
      return res.json({});
    } catch (err) {
      console.error("Failed reading global settings:", err);
      return res.status(500).json({ error: "Failed to read global settings" });
    }
  });
  app.post("/api/settings/global", import_express3.default.json({ limit: "50mb" }), (req, res) => {
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      const publicDir = import_path.default.join(_dirname, "public");
      if (!import_fs.default.existsSync(publicDir)) {
        import_fs.default.mkdirSync(publicDir, { recursive: true });
      }
      const newSettings = req.body;
      if (!newSettings) {
        return res.status(400).json({ error: "Invalid settings data" });
      }
      let settings = {};
      if (import_fs.default.existsSync(settingsFilePath)) {
        try {
          const content = import_fs.default.readFileSync(settingsFilePath, "utf-8");
          settings = JSON.parse(content);
        } catch (e) {
          console.error("Error parsing existing settings, overwriting...");
        }
      } else if (import_fs.default.existsSync(publicSettingsFilePath)) {
        try {
          const content = import_fs.default.readFileSync(publicSettingsFilePath, "utf-8");
          settings = JSON.parse(content);
        } catch (e) {
          console.error("Error parsing public settings, overwriting...");
        }
      }
      settings = { ...settings, ...newSettings };
      const settingsJson = JSON.stringify(settings, null, 2);
      import_fs.default.writeFileSync(settingsFilePath, settingsJson, "utf-8");
      try {
        import_fs.default.writeFileSync(publicSettingsFilePath, settingsJson, "utf-8");
      } catch (e) {
        console.warn("Could not write to public/global_settings.json fallback:", e);
      }
      res.json({ success: true, settings });
    } catch (err) {
      console.error("Failed saving global settings:", err);
      res.status(500).json({ error: "Failed to save global settings" });
    }
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });
  app.post("/api/gemini/analyze", async (req, res) => {
    try {
      const { model, dims, material, specialEffect, userPrompt } = req.body;
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        throw new Error("API_KEY_MISSING");
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const modelName = model?.name || "\u0633\u0627\u0632\u0647 \u062C\u0639\u0628\u0647 \u0633\u0641\u0627\u0631\u0634\u06CC";
      const modelCode = model?.code || "CAD-Custom";
      const activeDims = dims ? `${dims.L}x${dims.W}x${dims.H} mm` : "\u0646\u0627\u0645\u0634\u062E\u0635";
      const matName = material?.name || "\u0627\u06CC\u0646\u062F\u0631\u0628\u0631\u062F \u06F3\u06F0\u06F0 \u06AF\u0631\u0645";
      const systemInstruction = `\u0634\u0645\u0627 "\u0645\u0648\u062A\u0648\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0645\u0633\u062A\u0642\u0644 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F\u0647\u0627\u06CC \u0647\u0646\u062F\u0633\u06CC \u0627\u0634\u06A9 \u0642\u0644\u0645" \u0647\u0633\u062A\u06CC\u062F. \u06CC\u06A9 \u0645\u062A\u062E\u0635\u0635 \u062A\u0645\u0627\u0645 \u0639\u06CC\u0627\u0631 \u062F\u0631 \u0637\u0631\u0627\u062D\u06CC \u0635\u0646\u0639\u062A\u06CC \u06A9\u0627\u0631\u062A\u0646 \u0648 \u062C\u0639\u0628\u0647 (\u0633\u0627\u0632\u0647\u200C\u0647\u0627\u06CC \u0645\u0642\u0648\u0627\u06CC\u06CC\u060C FEFCO \u0648 ECMA). 
\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u062A\u062D\u0644\u06CC\u0644 \u0641\u0646\u06CC \u0627\u0628\u0639\u0627\u062F \u062F\u0627\u062F\u0647 \u0634\u062F\u0647 (\u0637\u0648\u0644\u060C \u0639\u0631\u0636\u060C \u0627\u0631\u062A\u0641\u0627\u0639\u060C \u062C\u0646\u0633 \u0645\u0642\u0648\u0627/\u06A9\u0627\u0631\u062A\u0646 \u0648 \u0627\u0641\u06A9\u062A \u0648\u06CC\u0698\u0647)\u060C \u067E\u0627\u0633\u062E\u06AF\u0648\u06CC\u06CC \u0628\u0647 \u0686\u0627\u0644\u0634\u200C\u0647\u0627\u06CC \u062A\u0627\u062E\u0648\u0631\u062F\u06AF\u06CC\u060C \u0686\u0633\u0628\u060C \u067E\u0644\u0647 \u0644\u0628\u0647 \u0648 \u0632\u0648\u0627\u06CC\u0627\u06CC \u0628\u0631\u0634 \u062F\u0631 \u0635\u0646\u0639\u062A \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC\u060C \u0645\u062D\u0627\u0633\u0628\u0647 \u06A9\u0633\u0631 \u062E\u0637 \u062A\u0627 (folding loss) \u0648 \u0628\u0627\u0637\u0644\u0647 \u0645\u062C\u0627\u0632 \u0644\u06CC\u062A\u0648\u06AF\u0631\u0627\u0641\u06CC \u0628\u0631 \u0627\u0633\u0627\u0633 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0645\u0627\u0634\u06CC\u0646\u0647\u0627\u06CC \u062F\u0627\u06CC\u06A9\u0627\u062A BOBST \u0648 \u06AF\u0648\u062A\u0645\u0646 \u0627\u0633\u062A.
\u062A\u0645\u0627\u0645 \u067E\u0627\u0633\u062E\u200C\u0647\u0627 \u0631\u0627 \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u0641\u0646\u06CC\u060C \u062F\u0642\u06CC\u0642\u060C \u0628\u0633\u06CC\u0627\u0631 \u0628\u0627 \u067E\u0631\u0633\u062A\u06CC\u0698 \u0648 \u06A9\u0627\u0645\u0644\u0627\u064B \u0645\u0633\u062A\u062F\u0644 \u0641\u0631\u0645\u062A \u0634\u062F\u0647 \u0628\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 Markdown \u0632\u06CC\u0628\u0627 \u0648 \u062E\u0627\u0646\u0627\u06CC \u062D\u0631\u0641\u0647\u200C\u0627\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0645\u0627\u06CC\u06CC\u062F. \u0627\u0632 \u0639\u0628\u0627\u0631\u0627\u062A \u0639\u0627\u0645\u06CC\u0627\u0646\u0647 \u0628\u067E\u0631\u0647\u06CC\u0632\u06CC\u062F \u0648 \u0627\u0632 \u0627\u0635\u0637\u0644\u0627\u062D\u0627\u062A \u062A\u062E\u0635\u0635\u06CC \u0645\u062B\u0644 \u0644\u0648\u067E \u062A\u0627\u060C \u06AF\u0631\u06CC\u0646 \u0645\u0642\u0648\u0627\u060C \u062E\u0637 \u0634\u0627\u0633\u06CC\u060C \u062A\u06CC\u063A \u0645\u0627\u062A\u0631\u06CC\u06A9\u0633\u060C \u0627\u06CC\u0646\u062F\u0631\u0628\u0631\u062F\u060C \u067E\u0634\u062A\u200C\u0637\u0648\u0633\u06CC \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F.`;
      const promptText = `\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0633\u0627\u0632\u0647 \u062C\u0627\u0631\u06CC:
- \u0645\u062F\u0644 \u0633\u0627\u0632\u0647: ${modelName} (${modelCode})
- \u0627\u0628\u0639\u0627\u062F \u0635\u0646\u0639\u062A\u06CC: ${activeDims}
- \u062C\u0646\u0633 \u0645\u0642\u0648\u0627/\u06A9\u0627\u0631\u062A\u0646: ${matName}
- \u062C\u0644\u0648\u0647 \u0648\u06CC\u0698\u0647: ${specialEffect || "\u0646\u062F\u0627\u0631\u062F"}

\u067E\u0631\u0633\u0634 \u06A9\u0627\u0631\u0628\u0631 \u06CC\u0627 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0631\u0631\u0633\u06CC \u0645\u062C\u0627\u0648\u0631 \u0644\u0628\u0647\u200C\u0647\u0627:
"${userPrompt}"`;
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: promptText,
        config: {
          systemInstruction,
          temperature: 0.2
        }
      });
      const textResponse = response.text;
      res.json({ success: true, text: textResponse });
    } catch (err) {
      if (err.message === "API_KEY_MISSING") {
        res.status(400).json({ error: "\u0633\u06CC\u06AF\u0646\u0627\u0644 \u06A9\u0644\u06CC\u062F \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u062F\u0631 \u0647\u0627\u0633\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
      } else {
        res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0645\u0648\u062A\u0648\u0631 \u0645\u0633\u062A\u0642\u0644 \u06A9\u0627\u062F: " + err.message });
      }
    }
  });
  app.post("/api/gemini/analyze-object", async (req, res) => {
    try {
      const { image, mimeType, referenceHeight, objectDescription } = req.body;
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!image) {
        return res.status(400).json({ error: "\u062A\u0635\u0648\u06CC\u0631 \u0634\u06CC\u0621 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      let cleanBase64 = image;
      if (cleanBase64.includes(";base64,")) {
        cleanBase64 = cleanBase64.split(";base64,").pop() || "";
      }
      if (!apiKey) {
        console.warn("GEMINI_API_KEY is missing. Using local rule-based computer vision simulator.");
        const lowerDesc = (objectDescription || "").toLowerCase();
        let name = "\u0634\u06CC\u0621 \u0645\u0631\u062C\u0639 \u0627\u0633\u06A9\u0646 \u0634\u062F\u0647";
        let estDims = "70x70x160 mm";
        let L = 80, W = 80, H = 170;
        let strategy = "\u0628\u0631 \u0645\u0628\u0646\u0627\u06CC \u0627\u0644\u06AF\u0648\u0631\u06CC\u062A\u0645\u200C\u0647\u0627\u06CC \u0634\u0628\u06CC\u0647\u200C\u0633\u0627\u0632 \u0627\u0634\u06A9 \u0642\u0644\u0645\u060C \u0627\u0628\u0639\u0627\u062F \u0628\u0647\u06CC\u0646\u0647 \u062C\u0639\u0628\u0647 \u0628\u0627 \u062A\u0644\u0631\u0627\u0646\u0633 \u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u062E\u0644\u0627\u0635\u06CC \u062F\u06CC\u0648\u0627\u0631\u0647\u200C\u0647\u0627 \u0628\u0631\u0627\u06CC \u0628\u0637\u0631\u06CC \u06CC\u0627 \u0634\u06CC\u0621 \u062A\u062E\u0645\u06CC\u0646 \u0632\u062F\u0647 \u0634\u062F \u062A\u0627 \u0627\u0632 \u0622\u0633\u06CC\u0628 \u062D\u06CC\u0646 \u062A\u0631\u0627\u0646\u0632\u06CC\u062A \u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u0634\u0648\u062F.";
        if (lowerDesc.includes("\u0639\u0637\u0631") || lowerDesc.includes("perfume") || lowerDesc.includes("\u0627\u062F\u06A9\u0644\u0646")) {
          name = "\u0628\u0637\u0631\u06CC \u0639\u0637\u0631 \u0627\u062F\u06A9\u0644\u0646 \u0627\u06CC\u0633\u062A\u0627\u062F\u0647";
          estDims = "65x65x110 mm";
          L = 75;
          W = 75;
          H = 125;
          strategy = "\u0628\u0631\u0627\u06CC \u0645\u062D\u0635\u0648\u0644 \u0639\u0637\u0631 \u0627\u062F\u06A9\u0644\u0646 \u0627\u06CC\u0633\u062A\u0627\u062F\u0647 \u0644\u0648\u06A9\u0633\u060C \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0627\u0632 \u062A\u0644\u0631\u0627\u0646\u0633 \u0645\u062A\u0642\u0627\u0631\u0646 \u06F1\u06F0+ \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u062F\u0631 \u0627\u0631\u062A\u0641\u0627\u0639 \u0648 \u06F1\u06F0+ \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u062F\u0631 \u062F\u0647\u0646\u0647 \u0637\u0648\u0644 \u0648 \u0639\u0631\u0636 \u0647\u0645\u0631\u0627\u0647 \u0628\u0627 \u0628\u0627\u0641\u0631 \u0641\u0648\u0645 \u062F\u0627\u062E\u0644\u06CC \u062C\u0647\u062A \u062A\u062B\u0628\u06CC\u062A \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0634\u06CC\u0634\u0647 \u062A\u0648\u0635\u06CC\u0647 \u06AF\u0631\u062F\u06CC\u062F.";
        } else if (lowerDesc.includes("\u0645\u0627\u06AF") || lowerDesc.includes("mug") || lowerDesc.includes("\u0644\u06CC\u0648\u0627\u0646")) {
          name = "\u0645\u0627\u06AF \u0633\u0631\u0627\u0645\u06CC\u06A9\u06CC \u062F\u0633\u062A\u0647 \u062F\u0627\u0631";
          estDims = "90x90x95 mm";
          L = 105;
          W = 100;
          H = 105;
          strategy = "\u062F\u0633\u062A\u0647 \u0645\u0627\u06AF \u062F\u0631 \u0646\u0638\u0631 \u06AF\u0631\u0641\u062A\u0647 \u0634\u062F\u061B \u0644\u0630\u0627 \u0637\u0648\u0644 \u062C\u0639\u0628\u0647 \u0628\u0627 \u062D\u0627\u0634\u06CC\u0647 \u0627\u0636\u0627\u0641\u06CC \u06F1\u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0637\u0631\u0627\u062D\u06CC \u0634\u062F\u0647 \u062A\u0627 \u0641\u0634\u0627\u0631 \u062C\u0627\u0646\u0628\u06CC \u0628\u0647 \u062F\u0633\u062A\u0647 \u0633\u0631\u0627\u0645\u06CC\u06A9\u06CC \u0648\u0627\u0631\u062F \u0646\u0634\u0648\u062F \u0648 \u0627\u0632 \u0634\u06A9\u0633\u062A\u06AF\u06CC \u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u0634\u0648\u062F.";
        } else if (lowerDesc.includes("\u062A\u0644\u0641\u0646") || lowerDesc.includes("phone") || lowerDesc.includes("\u0645\u0648\u0628\u0627\u06CC\u0644")) {
          name = "\u062C\u0639\u0628\u0647 \u062A\u0644\u0641\u0646 \u0647\u0645\u0631\u0627\u0647 \u0647\u0648\u0634\u0645\u0646\u062F";
          estDims = "75x155x8 mm";
          L = 90;
          W = 170;
          H = 22;
          strategy = "\u0628\u0631\u0627\u06CC \u06A9\u0627\u0644\u0627\u06CC \u062D\u0633\u0627\u0633 \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9\u06CC\u060C \u0633\u0627\u062E\u062A\u0627\u0631 \u062C\u0639\u0628\u0647 \u0647\u0627\u0631\u062F\u0628\u0627\u06A9\u0633 \u06CC\u0627 \u06A9\u06CC\u0628\u0648\u0631\u062F\u06CC \u0645\u062C\u0647\u0632 \u0628\u0647 \u062F\u06CC\u0648\u0627\u0631\u0647 \u062F\u0648\u0628\u0644 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u0645\u06CC\u200C\u0634\u0648\u062F. \u0627\u0628\u0639\u0627\u062F \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0641\u0636\u0627\u06CC \u06A9\u0627\u0628\u0644 \u0634\u0627\u0631\u0698\u0631 \u0648 \u0622\u062F\u0627\u067E\u062A\u0648\u0631 \u0631\u0627 \u062A\u0636\u0645\u06CC\u0646 \u0645\u06CC\u200C\u06A9\u0646\u062F.";
        } else if (referenceHeight) {
          const numericHeight = parseInt(referenceHeight) || 120;
          const ratio = 0.6;
          H = Math.round(numericHeight + 10);
          L = Math.round(numericHeight * ratio);
          W = Math.round(numericHeight * ratio);
          estDims = `${L - 8}x${W - 8}x${numericHeight} mm`;
          strategy = `\u0627\u0628\u0639\u0627\u062F \u0628\u0631 \u0645\u0628\u0646\u0627\u06CC \u0627\u0631\u062A\u0641\u0627\u0639 \u0645\u0631\u062C\u0639 \u0627\u0639\u0644\u0627\u0645\u06CC \u06A9\u0627\u0631\u0628\u0631 (${referenceHeight} \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631) \u0628\u0627 \u0645\u062D\u0627\u0633\u0628\u0647 \u062A\u0646\u0627\u0633\u0628\u0627\u062A \u0637\u0644\u0627\u06CC\u06CC \u0647\u0646\u062F\u0633\u06CC \u0637\u0631\u0627\u062D\u06CC \u06AF\u0631\u062F\u06CC\u062F.`;
        }
        return res.json({
          success: true,
          data: {
            objectName: name,
            estimatedObjectDimensions: estDims,
            suggestedLength: L,
            suggestedWidth: W,
            suggestedHeight: H,
            packagingStrategy: strategy
          }
        });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const systemInstruction = `\u0634\u0645\u0627 "\u0645\u0648\u062A\u0648\u0631 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0622\u0646\u0627\u0644\u06CC\u0632 \u062A\u0635\u0648\u06CC\u0631 \u0648 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0627\u0628\u0639\u0627\u062F \u0627\u0634\u06A9 \u0642\u0644\u0645" \u0647\u0633\u062A\u06CC\u062F.
\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u0628\u0627\u0632\u0634\u0646\u0627\u062E\u062A \u062F\u0642\u06CC\u0642 \u0634\u06CC\u0621 \u062F\u0631\u0648\u0646 \u062A\u0635\u0648\u06CC\u0631 (\u0645\u0627\u0646\u0646\u062F \u0628\u0637\u0631\u06CC \u0639\u0637\u0631\u060C \u06A9\u062A\u0627\u0628\u060C \u0645\u0627\u06AF\u060C \u0627\u062F\u06A9\u0644\u0646\u060C \u06A9\u0631\u0645\u060C \u0642\u0637\u0639\u0647 \u0635\u0646\u0639\u062A\u06CC)\u060C \u062D\u062F\u0633 \u0632\u062F\u0646 \u0627\u0628\u0639\u0627\u062F \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0622\u0646 \u0628\u0647 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 (\u0628\u0627 \u0628\u0647\u0631\u0647\u200C\u06AF\u06CC\u0631\u06CC \u0627\u0632 \u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u06A9\u0645\u06A9\u06CC \u06A9\u0627\u0631\u0628\u0631)\u060C \u0648 \u062A\u0648\u0644\u06CC\u062F \u0627\u0628\u0639\u0627\u062F \u0628\u0647\u06CC\u0646\u0647\u060C \u0627\u0645\u0646 \u0648 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u062C\u0647\u062A \u0633\u0627\u062E\u062A \u062C\u0639\u0628\u0647 \u0645\u0642\u0648\u0627\u06CC\u06CC \u06CC\u0627 \u06A9\u0627\u0631\u062A\u0646\u06CC \u0628\u0631\u0627\u06CC \u0622\u0646 \u0634\u06CC\u0621 \u0627\u0633\u062A. \u0627\u0628\u0639\u0627\u062F \u0628\u0627\u06CC\u062F \u0628\u0647 \u0641\u0631\u0645 \u0637\u0648\u0644 (Length)\u060C \u0639\u0631\u0636 (Width) \u0648 \u0627\u0631\u062A\u0641\u0627\u0639 (Height) \u0628\u0647 \u0639\u062F\u062F \u0635\u062D\u06CC\u062D \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0628\u0627\u0634\u0646\u062F. \u0627\u0628\u0639\u0627\u062F \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u062C\u0639\u0628\u0647 \u0628\u0627\u06CC\u062F \u0628\u0631\u0627\u06CC \u0645\u062D\u0627\u0641\u0638\u062A \u0648 \u062C\u0627\u06AF\u06CC\u0631\u06CC \u0631\u0627\u062D\u062A\u060C \u062A\u0631\u062C\u06CC\u062D\u0627\u064B \u06F5 \u0627\u0644\u06CC \u06F1\u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0628\u0632\u0631\u06AF\u062A\u0631 \u0627\u0632 \u0637\u0648\u0644\u060C \u0639\u0631\u0636 \u0648 \u0627\u0631\u062A\u0641\u0627\u0639 \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u062E\u0648\u062F\u0650 \u06A9\u0627\u0644\u0627 \u0628\u0627\u0634\u062F.
\u0634\u0645\u0627 \u0628\u0627\u06CC\u062F \u0645\u0642\u0627\u062F\u06CC\u0631 \u0631\u0627 \u0628\u0647 \u0635\u0648\u0631\u062A \u06CC\u06A9 \u0634\u06CC\u0621 JSON \u0628\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 \u0645\u0639\u062A\u0628\u0631 \u0628\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC\u062F. \u0647\u06CC\u0686 \u0645\u062A\u0646 \u0645\u0642\u062F\u0645\u0647 \u06CC\u0627 \u0645\u0648\u062E\u0631\u0647 \u0627\u0636\u0627\u0641\u06CC \u0646\u0646\u0648\u06CC\u0633\u06CC\u062F.`;
      const promptText = `\u0644\u0637\u0641\u0627\u064B \u062A\u0635\u0648\u06CC\u0631 \u0636\u0645\u06CC\u0645\u0647 \u0634\u062F\u0647 \u0627\u0632 \u0634\u06CC\u0621 \u0645\u0631\u062C\u0639 \u0631\u0627 \u0628\u0631\u0631\u0633\u06CC \u06A9\u0646\u06CC\u062F \u0648 \u0627\u0628\u0639\u0627\u062F \u0628\u0647\u06CC\u0646\u0647 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0631\u0627 \u0645\u0634\u062E\u0635 \u0646\u0645\u0627\u06CC\u06CC\u062F.
\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0628\u0639\u0627\u062F\u06CC \u06CC\u0627 \u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u062A\u06A9\u0645\u06CC\u0644\u06CC \u0627\u0631\u0627\u0626\u0647 \u0634\u062F\u0647 \u062A\u0648\u0633\u0637 \u06A9\u0627\u0631\u0628\u0631:
- \u0627\u0631\u062A\u0641\u0627\u0639 \u062A\u0642\u0631\u06CC\u0628\u06CC \u0627\u0639\u0644\u0627\u0645 \u0634\u062F\u0647: "${referenceHeight || "\u0646\u0627\u0645\u0634\u062E\u0635"}"
- \u062A\u0648\u0635\u06CC\u0641 \u0634\u06CC\u0621: "${objectDescription || "\u0646\u0627\u0645\u0634\u062E\u0635"}"`;
      const imagePart = {
        inlineData: {
          mimeType: mimeType || "image/png",
          data: cleanBase64
        }
      };
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: [imagePart, promptText],
        config: {
          systemInstruction,
          temperature: 0.1,
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              objectName: {
                type: import_genai.Type.STRING,
                description: "Name of the recognized object in Persian (e.g. \u0628\u0637\u0631\u06CC \u0639\u0637\u0631 \u0644\u0648\u06A9\u0633, \u0644\u06CC\u0648\u0627\u0646 \u0645\u0627\u06AF \u0633\u0631\u0627\u0645\u06CC\u06A9\u06CC)."
              },
              estimatedObjectDimensions: {
                type: import_genai.Type.STRING,
                description: "Estimated dimensions of the product itself in 'L x W x H mm' format."
              },
              suggestedLength: {
                type: import_genai.Type.INTEGER,
                description: "Recommended packaging outer length (L) in mm. Integer."
              },
              suggestedWidth: {
                type: import_genai.Type.INTEGER,
                description: "Recommended packaging outer width (W) in mm. Integer."
              },
              suggestedHeight: {
                type: import_genai.Type.INTEGER,
                description: "Recommended packaging outer height (H) in mm. Integer."
              },
              packagingStrategy: {
                type: import_genai.Type.STRING,
                description: "Brief, highly technical and professional explanation in Persian explaining the structural design choice, why these dimensions were selected, and protective gaps added."
              }
            },
            required: ["objectName", "suggestedLength", "suggestedWidth", "suggestedHeight", "packagingStrategy"]
          }
        }
      });
      const textResponse = response.text;
      if (!textResponse) {
        throw new Error("EMPTY_GEMINI_RESPONSE");
      }
      const parsedData = JSON.parse(textResponse.trim());
      res.json({
        success: true,
        data: parsedData
      });
    } catch (err) {
      console.error("Error in analyze-object API:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062A\u062D\u0644\u06CC\u0644 \u062A\u0635\u0648\u06CC\u0631 \u0634\u06CC\u0621 \u0645\u0631\u062C\u0639: " + err.message });
    }
  });
  app.post("/api/gemini/analyze-dieline", async (req, res) => {
    try {
      const { image, mimeType, notes, activeModelId } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!image) {
        return res.status(400).json({ error: "\u062A\u0635\u0648\u06CC\u0631 \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646 \u0645\u0631\u062C\u0639 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      let cleanBase64 = image;
      if (cleanBase64.includes(";base64,")) {
        cleanBase64 = cleanBase64.split(";base64,").pop() || "";
      }
      if (!apiKey) {
        console.warn("GEMINI_API_KEY is missing. Using local rule-based Dieline/ArtiosCAD simulator.");
        let anglesStatus = "\u062A\u062D\u0644\u06CC\u0644 \u0632\u0627\u0648\u06CC\u0647: \u0632\u0648\u0627\u06CC\u0627\u06CC \u0628\u0627\u0644\u0647\u200C\u0647\u0627 \u0628\u0647 \u0632\u0648\u0627\u06CC\u0627\u06CC \u0628\u0647\u06CC\u0646\u0647 \u0645\u0627\u06CC\u0644 \u06F1\u06F5 \u062F\u0631\u062C\u0647 \u0648 \u0644\u0628\u0647 \u0641\u0648\u0644\u062F \u0628\u0627 \u06F9\u06F0 \u062F\u0631\u062C\u0647 \u0627\u0631\u062A\u0642\u0627 \u06CC\u0627\u0641\u062A\u0646\u062F \u062A\u0627 \u0632\u0648\u0627\u06CC\u0627\u06CC \u062F\u0627\u06CC\u06A9\u0627\u062A \u0639\u0627\u0631\u06CC \u0627\u0632 \u062A\u062F\u0627\u062E\u0644 \u062E\u0637\u0648\u0637 \u062A\u0627 \u0628\u0627\u0634\u0646\u062F.";
        let locksStatus = "\u062A\u062D\u0644\u06CC\u0644 \u0642\u0641\u0644 \u062A\u0647: \u0633\u06CC\u0633\u062A\u0645 \u0642\u0641\u0644 \u06A9\u0627\u0644\u06CC\u0628\u0631\u0647 \u0634\u062F. \u0627\u062A\u0635\u0627\u0644\u0627\u062A \u0648 \u0641\u0627\u0642 \u0648 \u0632\u0628\u0627\u0646\u0647 \u0645\u0627\u062F\u06CC-\u0645\u0627\u062F\u06AF\u06CC \u0628\u0627 \u0627\u0646\u0637\u0628\u0627\u0642 \u0628\u0627\u0644\u0627 \u0628\u0631 \u0627\u0633\u0627\u0633 \u0636\u062E\u0627\u0645\u062A \u0645\u0642\u0648\u0627\u06CC \u0641\u0639\u0644\u06CC \u062F\u0631 \u0645\u062D\u0627\u0633\u0628\u0627\u062A \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646 \u062A\u062B\u0628\u06CC\u062A \u0634\u062F\u0646\u062F.";
        let creasesStatus = "\u062A\u062D\u0644\u06CC\u0644 \u062E\u0637 \u062A\u0627: \u062C\u0628\u0631\u0627\u0646 \u062E\u0637 \u062A\u0627 (Crease Compensation) \u0628\u0631\u0627\u0628\u0631 \u06F0.\u06F5\u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0627\u0639\u0645\u0627\u0644 \u0634\u062F \u0648 \u0644\u0628\u0647 \u0634\u06CC\u0627\u0631\u0647\u0627\u06CC \u0642\u0641\u0644 \u0628\u0627 \u06A9\u0633\u0631 \u062E\u0645 \u0645\u062A\u0646\u0627\u0633\u0628 \u062A\u0646\u0638\u06CC\u0645 \u06AF\u0631\u062F\u06CC\u062F \u062A\u0627 \u0632\u0627\u06CC\u06CC\u062F\u0647 \u0628\u0627\u062F\u06AF\u06CC\u0631\u06CC \u0631\u062E \u0646\u062F\u0647\u062F.";
        let suggestedAdjustments = [
          "\u062A\u0646\u0638\u06CC\u0645 \u0632\u0627\u0648\u06CC\u0647 \u067E\u0644\u0647 \u0645\u0627\u062F\u06CC \u0644\u0627\u06A9\u200C\u0628\u0627\u062A\u0645 \u0627\u0632 \u06F4\u06F0 \u062F\u0631\u062C\u0647 \u0628\u0647 \u06F4\u06F5 \u062F\u0631\u062C\u0647 \u062C\u0647\u062A \u0642\u0641\u0644 \u0645\u062D\u06A9\u0645\u200C\u062A\u0631 (\u062A\u0637\u0628\u06CC\u0642 \u0628\u0627 \u0646\u0645\u0648\u0646\u0647 \u0641\u06CC\u0632\u06CC\u06A9\u06CC).",
          "\u0627\u0639\u0645\u0627\u0644 \u067E\u0644\u0647 \u06A9\u0633\u0631 \u062A\u0627 (Fold Loss) \u0628\u0647 \u0645\u06CC\u0632\u0627\u0646 \u06F0.\u06F5\u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0631\u0648\u06CC \u06A9\u0644 \u0634\u06CC\u062A \u0628\u0631 \u0627\u0633\u0627\u0633 \u06AF\u0631\u06CC\u0646 \u0645\u0642\u0648\u0627.",
          "\u0635\u06CC\u0642\u0644\u06CC \u06A9\u0631\u062F\u0646 \u0632\u0648\u0627\u06CC\u0627\u06CC \u062A\u0644\u0627\u0642\u06CC \u062E\u0637\u0648\u0637 \u062A\u0627 \u0648 \u062E\u0637\u0648\u0637 \u0628\u0631\u0634 \u0628\u0647 \u0645\u06CC\u0632\u0627\u0646 \u06F1.\u06F2 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u062C\u0647\u062A \u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u0627\u0632 \u067E\u0627\u0631\u06AF\u06CC \u0645\u0642\u0648\u0627 \u062F\u0631 \u062F\u0627\u06CC\u06A9\u0627\u062A."
        ];
        if (activeModelId === "snap-lock-123") {
          anglesStatus = "\u06A9\u0627\u0644\u06CC\u0628\u0631\u0627\u0633\u06CC\u0648\u0646 \u0632\u0648\u0627\u06CC\u0627\u06CC \u062A\u0647 \u0642\u0641\u0644\u06CC: \u0628\u0631 \u0627\u0633\u0627\u0633 \u062A\u062D\u0644\u06CC\u0644 \u062A\u0635\u0648\u06CC\u0631 \u0646\u0645\u0648\u0646\u0647 \u0627\u0631\u0633\u0627\u0644\u06CC \u0634\u0645\u0627\u060C \u0632\u0627\u0648\u06CC\u0647 \u0634\u06CC\u0627\u0631\u0647\u0627\u06CC \u06A9\u0646\u0627\u0631\u06CC \u0628\u0647 \u06F4\u06F5 \u062F\u0631\u062C\u0647 \u0627\u0631\u062A\u0642\u0627 \u06CC\u0627\u0641\u062A \u062A\u0627 \u0632\u0628\u0627\u0646\u0647\u200C\u0647\u0627 \u0628\u0627 \u0642\u0641\u0644 \u0627\u0635\u0637\u06A9\u0627\u06A9\u06CC \u0628\u0647\u062A\u0631\u06CC \u0686\u0641\u062A \u0634\u0648\u0646\u062F.";
          locksStatus = "\u0627\u0635\u0644\u0627\u062D \u0647\u0646\u062F\u0633\u06CC \u0632\u0628\u0627\u0646\u0647 \u0645\u0627\u062F\u06AF\u06CC: \u0634\u06CC\u0627\u0631 \u0632\u0628\u0627\u0646\u0647 \u0645\u0627\u062F\u06AF\u06CC \u062A\u0647 \u0642\u0641\u0644 \u062A\u0627 \u06F3.\u06F2 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0639\u0631\u06CC\u0636\u200C\u062A\u0631 \u0645\u062D\u0627\u0633\u0628\u0647 \u0634\u062F \u062A\u0627 \u0636\u062E\u0627\u0645\u062A \u0645\u0642\u0648\u0627 \u0631\u0627 \u06A9\u0627\u0645\u0644\u0627 \u062C\u0628\u0631\u0627\u0646 \u06A9\u0646\u062F \u0648 \u0628\u062F\u0648\u0646 \u062E\u0645 \u062E\u0648\u0631\u062F\u0646 \u062F\u0631 \u067E\u0644\u0647 \u0632\u06CC\u0631\u06CC \u0686\u0641\u062A \u06AF\u0631\u062F\u062F.";
          creasesStatus = "\u062A\u0635\u062D\u06CC\u062D \u0641\u0648\u0644\u062F\u0644\u0627\u0633 \u062A\u0647 \u062C\u0639\u0628\u0647: \u0641\u0648\u0646\u062F\u0627\u0633\u06CC\u0648\u0646 \u062A\u0627 \u062E\u0648\u0631\u062F\u06AF\u06CC \u0632\u0628\u0627\u0646\u0647\u200C\u0647\u0627\u06CC \u0686\u0647\u0627\u0631\u06AF\u0627\u0646\u0647 \u062A\u0647 \u0642\u0641\u0644\u06CC \u0628\u0647 \u0645\u0642\u062F\u0627\u0631 \u06F0.\u06F6 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0639\u0642\u0628\u200C\u0646\u0634\u06CC\u0646\u06CC \u06A9\u0631\u062F \u062A\u0627 \u062A\u0647 \u06A9\u0627\u0631 \u06A9\u0627\u0645\u0644\u0627\u064B \u0645\u0633\u0637\u062D \u0628\u0627\u06CC\u0633\u062A\u062F.";
          suggestedAdjustments = [
            "\u062A\u063A\u06CC\u06CC\u0631 \u067E\u0644\u0647 \u0627\u0631\u062A\u0641\u0627\u0639\u06CC \u0628\u0627\u0644\u0647 \u0634\u06CC\u0627\u0631 \u062A\u0647 \u0642\u0641\u0644\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0628\u0647 \u06F3.\u06F5 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u062C\u0647\u062A \u0645\u0645\u0627\u0646\u0639\u062A \u0627\u0632 \u0628\u0627\u062F\u06A9\u0631\u062F\u0646 \u062A\u0647 \u062C\u0639\u0628\u0647.",
            "\u0627\u0636\u0627\u0641\u0647 \u06A9\u0631\u062F\u0646 \u067E\u0644\u0647 \u0622\u0632\u0627\u062F \u06F1.\u06F5 \u062F\u0631\u062C\u0647\u200C\u0627\u06CC \u0628\u0647 \u0632\u0628\u0627\u0646\u0647\u200C\u0647\u0627\u06CC \u06A9\u0646\u0627\u0631\u06CC \u0628\u0631\u0627\u06CC \u0628\u0627\u0632 \u0648 \u0628\u0633\u062A \u0631\u0648\u0627\u0646\u200C\u062A\u0631 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u062F\u0631 \u062E\u0637 \u0645\u0648\u0646\u062A\u0627\u0698.",
            "\u06A9\u0627\u0647\u0634 \u0644\u0642\u06CC \u0632\u0628\u0627\u0646\u0647 \u0642\u0641\u0644 \u0628\u0627\u0644\u0627 \u0627\u0632 \u06F1.\u06F0 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0628\u0647 \u06F0.\u06F6 \u0645\u06CC\u0644\u06CC\u200C\u0645\u062A\u0631 \u0628\u0631 \u0627\u0633\u0627\u0633 \u0646\u0645\u0648\u0646\u0647 \u0627\u0631\u0633\u0627\u0644\u06CC \u062C\u0647\u062A \u0686\u0641\u062A\u200C\u0634\u062F\u06AF\u06CC \u0627\u0633\u062A\u0648\u0627\u0631."
          ];
        }
        return res.json({
          success: true,
          data: {
            anglesStatus,
            locksStatus,
            creasesStatus,
            suggestedAdjustments,
            geometryEngineCorrection: true
          }
        });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const systemInstruction = `\u0634\u0645\u0627 "\u0645\u0648\u062A\u0648\u0631 \u0641\u0648\u0642 \u0647\u0648\u0634\u0645\u0646\u062F \u0627\u0635\u0644\u0627\u062D \u0647\u0646\u062F\u0633\u06CC \u0648 \u06A9\u0627\u0644\u06CC\u0628\u0631\u0627\u0633\u06CC\u0648\u0646 \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC (\u0645\u0634\u0627\u0628\u0647 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 ArtiosCAD)" \u0647\u0633\u062A\u06CC\u062F.
\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u0628\u0631\u0631\u0633\u06CC \u062F\u0642\u06CC\u0642 \u062A\u0635\u0648\u06CC\u0631 \u0646\u0642\u0634\u0647 \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646\u060C \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0628\u0627\u0632 \u0634\u062F\u0647 \u06CC\u0627 \u0627\u0644\u06AF\u0648 \u0627\u0631\u0633\u0627\u0644\u06CC \u06A9\u0627\u0631\u0628\u0631 \u0648 \u0645\u0642\u0627\u06CC\u0633\u0647 \u0622\u0646 \u0628\u0627 \u067E\u0627\u0631\u0627\u0645\u062A\u0631\u0647\u0627\u06CC \u0645\u062F\u0644 \u0641\u0639\u0627\u0644 \u06A9\u0627\u0631\u06AF\u0627\u0647\u06CC \u0627\u0633\u062A. \u0634\u0645\u0627 \u0628\u0627\u06CC\u062F \u0646\u0642\u0627\u0637 \u0636\u0639\u0641 \u0647\u0646\u062F\u0633\u06CC\u060C \u062A\u062F\u0627\u062E\u0644 \u0632\u0648\u0627\u06CC\u0627\u060C \u06AF\u0633\u06CC\u062E\u062A\u06AF\u06CC \u0627\u062D\u062A\u0645\u0627\u0644\u06CC \u0642\u0641\u0644 \u062A\u0647 \u062C\u0639\u0628\u0647 (\u0645\u0627\u0646\u0646\u062F \u0644\u0627\u06A9\u200C\u0628\u0627\u062A\u0645 \u06CC\u0627 \u062A\u0647 \u0642\u0641\u0644\u06CC \u06F1-\u06F2-\u06F3)\u060C \u0648 \u0645\u0634\u06A9\u0644\u0627\u062A \u0639\u062F\u0645 \u0627\u0646\u0637\u0628\u0627\u0642 \u0628\u0627 \u0636\u062E\u0627\u0645\u062A \u0648\u0631\u0642 \u0631\u0627 \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u06A9\u0631\u062F\u0647 \u0648 \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u06A9\u0627\u0645\u0644\u0627\u064B \u0641\u0646\u06CC \u0648 \u0645\u0647\u0646\u062F\u0633\u06CC\u060C \u0632\u0648\u0627\u06CC\u0627 \u0648 \u0627\u0628\u0639\u0627\u062F \u0627\u0635\u0644\u0627\u062D \u0634\u062F\u0647 \u0631\u0627 \u0627\u0631\u0627\u06CC\u0647 \u062F\u0647\u06CC\u062F. \u067E\u0627\u0633\u062E \u0628\u0627\u06CC\u062F \u062F\u0631 \u0642\u0627\u0644\u0628 \u06CC\u06A9 \u0634\u06CC\u0621 JSON \u0645\u0646\u0637\u0628\u0642 \u0628\u0631 \u0633\u0627\u062E\u062A\u0627\u0631 \u062A\u0639\u0631\u06CC\u0641 \u0634\u062F\u0647 \u0628\u0627\u0634\u062F.`;
      const promptText = `\u0644\u0637\u0641\u0627\u064B \u062A\u0635\u0648\u06CC\u0631 \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646 \u0646\u0645\u0648\u0646\u0647 \u06CC\u0627 \u0645\u0627\u06A9\u062A \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0631\u0627 \u0622\u0646\u0627\u0644\u06CC\u0632 \u06A9\u0646\u06CC\u062F.
\u0645\u062F\u0644 \u0641\u0639\u0627\u0644 \u062C\u0627\u0631\u06CC \u062F\u0631 \u06A9\u0627\u0631\u06AF\u0627\u0647: "${activeModelId}"
\u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u0648 \u0627\u0645\u0636\u0627\u06CC \u0647\u0646\u062F\u0633\u06CC \u0645\u062F\u0646\u0638\u0631 \u06A9\u0627\u0631\u0628\u0631: "${notes || "\u0646\u0627\u0645\u0634\u062E\u0635"}"
\u0646\u062A\u0627\u06CC\u062C \u0645\u062D\u0627\u0633\u0628\u0627\u062A\u06CC \u062A\u062D\u0644\u06CC\u0644 \u062F\u0642\u06CC\u0642 \u0632\u0648\u0627\u06CC\u0627\u060C \u0641\u0648\u0644\u062F \u0644\u0627\u0633 (\u06A9\u0633\u0631 \u062A\u0627)\u060C \u0633\u06CC\u0633\u062A\u0645 \u0642\u0641\u0644 \u0645\u0627\u062F\u06CC \u0648 \u0645\u0627\u062F\u06AF\u06CC (\u0644\u0627\u06A9\u200C\u0628\u0627\u062A\u0645) \u0648 \u062A\u0639\u062F\u06CC\u0644\u200C\u0647\u0627\u06CC \u0627\u0628\u0639\u0627\u062F\u06CC \u0631\u0627 \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u0641\u0646\u06CC \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC\u062F.`;
      const imagePart = {
        inlineData: {
          mimeType: mimeType || "image/png",
          data: cleanBase64
        }
      };
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: [imagePart, promptText],
        config: {
          systemInstruction,
          temperature: 0.15,
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              anglesStatus: {
                type: import_genai.Type.STRING,
                description: "Technical feedback in Persian about dieline angles analysis and alignment corrections (e.g. adjust flap angles to 45 deg)."
              },
              locksStatus: {
                type: import_genai.Type.STRING,
                description: "Technical feedback in Persian about lock bottom / snap-lock joints and tongues calibration."
              },
              creasesStatus: {
                type: import_genai.Type.STRING,
                description: "Technical feedback in Persian about folding creases, crease compensation, and fold loss corrections."
              },
              suggestedAdjustments: {
                type: import_genai.Type.ARRAY,
                items: { type: import_genai.Type.STRING },
                description: "Array of 3 highly specific, technical geometric adjustment items in Persian (e.g. increase slot depth by 0.5mm)."
              },
              geometryEngineCorrection: {
                type: import_genai.Type.BOOLEAN,
                description: "Set to true indicating that geometric parameters are ready to be calibrated."
              }
            },
            required: ["anglesStatus", "locksStatus", "creasesStatus", "suggestedAdjustments", "geometryEngineCorrection"]
          }
        }
      });
      const textResponse = response.text;
      if (!textResponse) {
        throw new Error("EMPTY_GEMINI_RESPONSE");
      }
      const parsedData = JSON.parse(textResponse.trim());
      res.json({
        success: true,
        data: parsedData
      });
    } catch (err) {
      console.error("Error in analyze-dieline API:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062A\u062D\u0644\u06CC\u0644 \u0647\u0646\u062F\u0633\u06CC \u062F\u0627\u06CC\u0644\u0627\u06CC\u0646 \u0645\u0631\u062C\u0639: " + err.message });
    }
  });
  const distDir = import_path.default.join(process.cwd(), "dist");
  if (!import_fs.default.existsSync(distDir)) {
    import_fs.default.mkdirSync(distDir, { recursive: true });
  }
  function copyDirRecursiveSync(src, dest) {
    if (!import_fs.default.existsSync(dest)) {
      import_fs.default.mkdirSync(dest, { recursive: true });
    }
    if (!import_fs.default.existsSync(src)) return;
    const entries = import_fs.default.readdirSync(src, { withFileTypes: true });
    for (const entry of entries) {
      const srcPath = import_path.default.join(src, entry.name);
      const destPath = import_path.default.join(dest, entry.name);
      if (entry.isDirectory()) {
        copyDirRecursiveSync(srcPath, destPath);
      } else {
        import_fs.default.copyFileSync(srcPath, destPath);
      }
    }
  }
  function classifyZipEntry(rawEntryName) {
    let cleanPath = rawEntryName.replace(/\\/g, "/").replace(/^\/+/, "");
    if (cleanPath === "manifest.json" || cleanPath === "update-meta.json" || cleanPath === "metadata.json" || cleanPath.endsWith("/manifest.json")) {
      return { type: "meta", targetRelativePath: "manifest.json", displayTarget: "\u0645\u062A\u0627\u062F\u0627\u062F\u0647 \u0645\u0627\u0646\u06CC\u0641\u0633\u062A (manifest.json)" };
    }
    if (cleanPath === "database-update.json" || cleanPath === "content-update.json") {
      return { type: "db", targetRelativePath: cleanPath, displayTarget: "\u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u0645\u062A\u0646\u06CC" };
    }
    if (cleanPath.startsWith("uploads/") || cleanPath.startsWith("public/uploads/")) {
      const rel = cleanPath.replace(/^(public\/)?uploads\//, "");
      return { type: "uploads", targetRelativePath: rel, displayTarget: `uploads/${rel}` };
    }
    let unwrapPath = cleanPath;
    if (unwrapPath.startsWith("dist/")) {
      unwrapPath = unwrapPath.slice(5);
    } else if (unwrapPath.startsWith("build/")) {
      unwrapPath = unwrapPath.slice(6);
    }
    return { type: "dist", targetRelativePath: unwrapPath, displayTarget: `dist/${unwrapPath}` };
  }
  app.post("/api/update/upload", localUpload.single("updatePack"), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 \u0622\u067E\u062F\u06CC\u062A \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const zipPath = import_path.default.join(uploadsDir, req.file.filename);
      const zip = new import_adm_zip.default(zipPath);
      const zipEntries = zip.getEntries();
      const filesList = [];
      let updateMeta = null;
      let distCount = 0;
      let mediaCount = 0;
      let dbCount = 0;
      for (const entry of zipEntries) {
        if (entry.isDirectory) continue;
        const info = classifyZipEntry(entry.entryName);
        filesList.push({
          name: entry.entryName,
          isDirectory: entry.isDirectory,
          size: entry.header.size,
          target: info.displayTarget
        });
        if (info.type === "dist") distCount++;
        else if (info.type === "uploads") mediaCount++;
        else if (info.type === "db") dbCount++;
        if (info.type === "meta") {
          try {
            updateMeta = JSON.parse(entry.getData().toString("utf8"));
          } catch (e) {
            console.error("Error parsing update metadata", e);
          }
        }
      }
      let packageType = "web_build";
      let packageTypeName = "\u0628\u0633\u062A\u0647 \u06A9\u062F\u0647\u0627\u06CC \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644\u200C\u0634\u062F\u0647 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 (Build / Dist)";
      if (distCount > 0 && mediaCount === 0) {
        packageType = "web_build";
        packageTypeName = "\u0628\u0633\u062A\u0647 \u06A9\u062F\u0647\u0627\u06CC \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644\u200C\u0634\u062F\u0647 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 (Vite / React Build)";
      } else if (mediaCount > 0 && distCount === 0) {
        packageType = "media_pack";
        packageTypeName = "\u0628\u0633\u062A\u0647 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u0631\u0633\u0627\u0646\u0647\u200C\u0627\u06CC \u0648 \u062A\u0635\u0627\u0648\u06CC\u0631 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF";
      } else {
        packageType = "full_hybrid";
        packageTypeName = "\u0628\u0633\u062A\u0647 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u062C\u0627\u0645\u0639 (\u06A9\u062F\u0647\u0627\u06CC \u06A9\u0644\u0627\u06CC\u0646\u062A + \u0631\u0633\u0627\u0646\u0647\u200C\u0647\u0627 + \u0628\u0627\u0646\u06A9 \u062F\u0627\u062F\u0647)";
      }
      if (!updateMeta) {
        updateMeta = {
          version: `3.2.${Math.floor(Math.random() * 90) + 10}`,
          title: packageType === "web_build" ? "\u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u06A9\u062F\u0647\u0627\u06CC \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644\u200C\u0634\u062F\u0647 \u062E\u0631\u0648\u062C\u06CC build" : "\u0628\u0633\u062A\u0647 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0627\u0634\u06A9\u200C\u0642\u0644\u0645",
          description: `\u0634\u0627\u0645\u0644 ${distCount} \u0641\u0627\u06CC\u0644 \u06A9\u0627\u0645\u067E\u0627\u06CC\u0644\u200C\u0634\u062F\u0647 \u06A9\u0644\u0627\u06CC\u0646\u062A\u060C ${mediaCount} \u0641\u0627\u06CC\u0644 \u0631\u0633\u0627\u0646\u0647 \u0648 ${dbCount} \u0645\u062A\u0627\u062F\u0627\u062F\u0647 \u0633\u0627\u062E\u062A\u0627\u0631\u06CC.`,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          author: "\u0645\u062F\u06CC\u0631\u06CC\u062A \u0633\u06CC\u0633\u062A\u0645 \u0627\u0634\u06A9\u200C\u0642\u0644\u0645"
        };
      }
      res.json({
        success: true,
        filename: req.file.filename,
        meta: updateMeta,
        packageType,
        packageTypeName,
        stats: {
          distCount,
          mediaCount,
          dbCount,
          totalFiles: filesList.length
        },
        files: filesList,
        dataProtectionGuarantee: "\u2705 \u062A\u0645\u0627\u0645\u06CC \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627\u060C \u0646\u0645\u0648\u0646\u0647\u200C\u06A9\u0627\u0631\u0647\u0627\u060C \u0633\u0641\u0627\u0631\u0634\u0627\u062A B2B\u060C \u0641\u0631\u0645\u0648\u0644\u200C\u0647\u0627\u06CC \u0642\u06CC\u0645\u062A \u0648 \u062A\u0635\u0627\u0648\u06CC\u0631 \u0645\u0648\u062C\u0648\u062F \u0634\u0645\u0627 \u0628\u062F\u0648\u0646 \u062A\u063A\u06CC\u06CC\u0631 \u06A9\u0627\u0645\u0644\u0627\u064B \u062F\u0633\u062A\u200C\u0646\u062E\u0648\u0631\u062F\u0647 \u0645\u062D\u0641\u0648\u0638 \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F."
      });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u062A\u062D\u0644\u06CC\u0644 \u0648 \u0628\u0627\u0631\u06AF\u0630\u0627\u0631\u06CC \u0627\u0648\u0644\u06CC\u0647 \u0628\u0633\u062A\u0647 \u0622\u067E\u062F\u06CC\u062A \u0632\u06CC\u067E: " + err.message });
    }
  });
  app.post("/api/update/apply", (req, res) => {
    try {
      const { filename, clientDbState } = req.body;
      if (!filename) {
        return res.status(400).json({ error: "\u0646\u0627\u0645 \u0641\u0627\u06CC\u0644 \u0645\u0631\u062C\u0639 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const zipPath = import_path.default.join(uploadsDir, filename);
      if (!import_fs.default.existsSync(zipPath)) {
        return res.status(404).json({ error: "\u0641\u0627\u06CC\u0644 \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0622\u067E\u062F\u06CC\u062A \u0631\u0648 \u0633\u0631\u0648\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
      }
      const zip = new import_adm_zip.default(zipPath);
      const zipEntries = zip.getEntries();
      let manifestEntry = zipEntries.find((entry) => {
        const info = classifyZipEntry(entry.entryName);
        return info.type === "meta";
      });
      let manifestData = null;
      if (manifestEntry) {
        try {
          manifestData = JSON.parse(manifestEntry.getData().toString("utf8"));
        } catch (e) {
          return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 manifest.json \u062F\u0631 \u0628\u0633\u062A\u0647 \u0622\u067E\u062F\u06CC\u062A \u06CC\u0627\u0641\u062A \u0634\u062F \u0627\u0645\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 JSON \u0622\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u06CC\u0627 \u062E\u0631\u0627\u0628 \u0627\u0633\u062A." });
        }
      }
      if (manifestData && manifestData.fileHashes) {
        console.log("Applying robust integrity verification of manifest.json hashes...");
        const fileHashes = manifestData.fileHashes;
        for (const [relativePath, expectedHash] of Object.entries(fileHashes)) {
          if (typeof expectedHash !== "string") continue;
          const matchedEntry = zipEntries.find((entry) => {
            const info = classifyZipEntry(entry.entryName);
            return info.targetRelativePath === relativePath;
          });
          if (!matchedEntry) {
            return res.status(400).json({
              error: `\u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u0645\u0627\u0646\u06CC\u0641\u0633\u062A \u0634\u06A9\u0633\u062A \u062E\u0648\u0631\u062F: \u0641\u0627\u06CC\u0644 '${relativePath}' \u062F\u0631 \u0628\u0633\u062A\u0647 \u0622\u067E\u062F\u06CC\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.`,
              integrityFailure: true
            });
          }
          const fileBuffer = matchedEntry.getData();
          const calculatedHash = import_crypto.default.createHash("sha256").update(fileBuffer).digest("hex");
          if (calculatedHash !== expectedHash) {
            return res.status(400).json({
              error: `\u062E\u0637\u0627\u06CC \u06CC\u06A9\u067E\u0627\u0631\u0686\u06AF\u06CC \u062F\u0627\u062F\u0647\u200C\u0647\u0627 (Hash Mismatch): \u0647\u0634 \u0641\u0627\u06CC\u0644 '${relativePath}' \u062F\u0631 \u0628\u0633\u062A\u0647 \u0622\u067E\u062F\u06CC\u062A \u0628\u0627 \u0645\u0642\u062F\u0627\u0631 \u0645\u0627\u0646\u06CC\u0641\u0633\u062A \u0645\u0637\u0627\u0628\u0642\u062A \u0646\u062F\u0627\u0631\u062F. \u0628\u0633\u062A\u0647 \u062E\u0631\u0627\u0628 \u0627\u0633\u062A.`,
              integrityFailure: true
            });
          }
          const localPath = import_path.default.join(distDir, relativePath);
          if (import_fs.default.existsSync(localPath)) {
            try {
              const localBuffer = import_fs.default.readFileSync(localPath);
              const localHash = import_crypto.default.createHash("sha256").update(localBuffer).digest("hex");
              console.log(`[Integrity Check] File '${relativePath}': Local Hash is ${localHash.slice(0, 8)}... | Incoming Expected Hash is ${expectedHash.slice(0, 8)}...`);
            } catch (err) {
              return res.status(400).json({
                error: `\u062E\u0637\u0627 \u062F\u0631 \u062E\u0648\u0627\u0646\u062F\u0646 \u0641\u0627\u06CC\u0644 \u0645\u062D\u0644\u06CC \u067E\u06CC\u0634 \u0627\u0632 \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646\u06CC \u0628\u0631\u0627\u06CC \u0633\u0646\u062C\u0634 \u0647\u0634: ${relativePath}. \u062E\u0637\u0627: ${err.message}`,
                integrityFailure: true
              });
            }
          }
        }
        console.log("Integrity verification of manifest.json successfully completed. Package is 100% integral.");
      }
      const timestamp = Date.now();
      const restorePointFilename = `pre_update_restore_${timestamp}.json`;
      const restorePointPath = import_path.default.join(backupsDir, restorePointFilename);
      const dbBackupState = clientDbState || {};
      const mediaBackupDirName = `pre_update_restore_${timestamp}_media`;
      const mediaBackupDirPath = import_path.default.join(backupsDir, mediaBackupDirName);
      const distBackupDirName = `pre_update_restore_${timestamp}_dist`;
      const distBackupDirPath = import_path.default.join(backupsDir, distBackupDirName);
      try {
        if (import_fs.default.existsSync(uploadsDir)) {
          import_fs.default.mkdirSync(mediaBackupDirPath, { recursive: true });
          copyDirRecursiveSync(uploadsDir, mediaBackupDirPath);
        }
      } catch (backupErr) {
        console.error("Failed to make physical media backup folder:", backupErr);
      }
      try {
        if (import_fs.default.existsSync(distDir)) {
          import_fs.default.mkdirSync(distBackupDirPath, { recursive: true });
          copyDirRecursiveSync(distDir, distBackupDirPath);
        }
      } catch (backupDistErr) {
        console.error("Failed to make physical dist backup folder:", backupDistErr);
      }
      const preUpdateSnapshot = {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        version: "3.2-pre-update-backup",
        dbState: dbBackupState,
        mediaBackupDir: mediaBackupDirName,
        distBackupDir: distBackupDirName
      };
      import_fs.default.writeFileSync(restorePointPath, JSON.stringify(preUpdateSnapshot, null, 2), "utf8");
      const lastRestoreRefPath = import_path.default.join(backupsDir, "last_pre_update_restore.json");
      import_fs.default.writeFileSync(lastRestoreRefPath, JSON.stringify({
        restorePointFilename,
        affectedFilename: filename,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }, null, 2), "utf8");
      let extractedWebFilesCount = 0;
      let extractedMediaCount = 0;
      let databaseUpdatesFound = null;
      for (const entry of zipEntries) {
        const info = classifyZipEntry(entry.entryName);
        if (info.type === "meta") {
          continue;
        }
        if (info.type === "db") {
          try {
            databaseUpdatesFound = JSON.parse(entry.getData().toString("utf8"));
          } catch (e) {
            console.error("Error reading db updates inside ZIP", e);
          }
          continue;
        }
        if (info.type === "dist") {
          if (!info.targetRelativePath) continue;
          const fileDestPath = import_path.default.join(distDir, info.targetRelativePath);
          const resolvedDestPath = import_path.default.resolve(fileDestPath);
          if (resolvedDestPath.startsWith(distDir)) {
            if (entry.isDirectory) {
              if (!import_fs.default.existsSync(resolvedDestPath)) {
                import_fs.default.mkdirSync(resolvedDestPath, { recursive: true });
              }
            } else {
              const parentDir = import_path.default.dirname(resolvedDestPath);
              if (!import_fs.default.existsSync(parentDir)) {
                import_fs.default.mkdirSync(parentDir, { recursive: true });
              }
              import_fs.default.writeFileSync(resolvedDestPath, entry.getData());
              extractedWebFilesCount++;
            }
          }
        } else if (info.type === "uploads") {
          if (!info.targetRelativePath) continue;
          const fileDestPath = import_path.default.join(uploadsDir, info.targetRelativePath);
          const resolvedDestPath = import_path.default.resolve(fileDestPath);
          if (resolvedDestPath.startsWith(uploadsDir)) {
            if (entry.isDirectory) {
              if (!import_fs.default.existsSync(resolvedDestPath)) {
                import_fs.default.mkdirSync(resolvedDestPath, { recursive: true });
              }
            } else {
              const parentDir = import_path.default.dirname(resolvedDestPath);
              if (!import_fs.default.existsSync(parentDir)) {
                import_fs.default.mkdirSync(parentDir, { recursive: true });
              }
              import_fs.default.writeFileSync(resolvedDestPath, entry.getData());
              extractedMediaCount++;
            }
          }
        }
      }
      res.json({
        success: true,
        message: "\u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0631 \u0631\u0648\u06CC \u06A9\u062F\u0647\u0627\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0627\u0639\u0645\u0627\u0644 \u06AF\u0631\u062F\u06CC\u062F.",
        extractedWebFilesCount,
        extractedMediaCount,
        databaseUpdates: databaseUpdatesFound,
        restorePointFilename,
        reloadRequired: true
      });
    } catch (err) {
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0645\u06A9\u0627\u0646\u06CC\u0632\u0645 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0648 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC: " + err.message });
    }
  });
  app.post("/api/update/rollback", (req, res) => {
    try {
      const lastRestoreRefPath = import_path.default.join(backupsDir, "last_pre_update_restore.json");
      if (!import_fs.default.existsSync(lastRestoreRefPath)) {
        return res.status(400).json({ error: "\u0647\u06CC\u0686 \u0646\u0642\u0637\u0647 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0627\u0645\u0646\u06CC\u062A\u06CC \u067E\u06CC\u0634 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u062B\u0628\u062A \u0646\u06AF\u0631\u062F\u06CC\u062F\u0647 \u0627\u0633\u062A." });
      }
      const refRef = JSON.parse(import_fs.default.readFileSync(lastRestoreRefPath, "utf8"));
      const restorePointPath = import_path.default.join(backupsDir, refRef.restorePointFilename);
      if (!import_fs.default.existsSync(restorePointPath)) {
        return res.status(404).json({ error: "\u0641\u0627\u06CC\u0644 \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u067E\u06CC\u0634\u06CC\u0646 \u062F\u0631 \u0628\u0627\u0646\u06A9 \u062F\u0627\u062F\u0647 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
      }
      const snapshot = JSON.parse(import_fs.default.readFileSync(restorePointPath, "utf8"));
      if (snapshot.mediaBackupDir) {
        const mediaBackupDirPath = import_path.default.join(backupsDir, snapshot.mediaBackupDir);
        if (import_fs.default.existsSync(mediaBackupDirPath)) {
          if (!import_fs.default.existsSync(uploadsDir)) {
            import_fs.default.mkdirSync(uploadsDir, { recursive: true });
          }
          copyDirRecursiveSync(mediaBackupDirPath, uploadsDir);
        }
      }
      if (snapshot.distBackupDir) {
        const distBackupDirPath = import_path.default.join(backupsDir, snapshot.distBackupDir);
        if (import_fs.default.existsSync(distBackupDirPath)) {
          if (!import_fs.default.existsSync(distDir)) {
            import_fs.default.mkdirSync(distDir, { recursive: true });
          }
          copyDirRecursiveSync(distBackupDirPath, distDir);
        }
      }
      res.json({
        success: true,
        message: "\u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0627\u0636\u0637\u0631\u0627\u0631\u06CC \u0648 \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u0628\u0631\u0646\u0627\u0645\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0647 \u0627\u062A\u0645\u0627\u0645 \u0631\u0633\u06CC\u062F.",
        dbState: snapshot.dbState,
        timestamp: snapshot.timestamp
      });
    } catch (err) {
      res.status(500).json({ error: "\u0628\u0631\u0648\u0632 \u062E\u0637\u0627 \u062F\u0631 \u0639\u0645\u0644\u06CC\u0627\u062A \u0631\u0648\u0644\u200C\u0628\u06A9 \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC: " + err.message });
    }
  });
  app.post("/api/upload", (req, res, next) => {
    upload.single("image")(req, res, (err) => {
      if (err) {
        console.error("Primary upload handler error:", err);
        if (s3Upload && localUpload) {
          console.log("S3 upload failed. Retrying transparently with local fallback storage...");
          return localUpload.single("image")(req, res, (localErr) => {
            if (localErr) {
              console.error("Local fallback upload also failed:", localErr);
              return res.status(500).json({ error: "Upload failed: " + localErr.message });
            }
            if (!req.file) {
              return res.status(400).json({ error: "No file uploaded in fallback mechanism" });
            }
            const file2 = req.file;
            return res.json({ url: `/uploads/${file2.filename}`, filename: file2.filename });
          });
        }
        return res.status(500).json({ error: err.message || "Upload failed" });
      }
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const file = req.file;
      const fileUrl = file.location ? file.location : `/uploads/${file.filename}`;
      const key = file.key || file.filename;
      res.json({ url: fileUrl, filename: key });
    });
  });
  app.get("/api/files", async (req, res) => {
    try {
      const mediaDir2 = import_path.default.join(_dirname, "public", "media");
      const uploadsDir2 = import_path.default.join(_dirname, "public", "uploads");
      const fileMap = /* @__PURE__ */ new Map();
      const scanDir = (dirPath, prefix) => {
        if (import_fs.default.existsSync(dirPath)) {
          const files = import_fs.default.readdirSync(dirPath);
          for (const f of files) {
            const ext = import_path.default.extname(f).toLowerCase();
            if ([".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"].includes(ext)) {
              try {
                const stat = import_fs.default.statSync(import_path.default.join(dirPath, f));
                if (stat.isFile()) {
                  fileMap.set(f, {
                    url: `/${prefix}/${f}`,
                    filename: f,
                    mtime: stat.mtimeMs
                  });
                }
              } catch (e) {
              }
            }
          }
        }
      };
      scanDir(mediaDir2, "media");
      scanDir(uploadsDir2, "uploads");
      const sorted = Array.from(fileMap.values()).sort((a, b) => b.mtime - a.mtime);
      res.json(sorted);
    } catch (err) {
      console.error("Failed to read files directory", err);
      res.status(500).json({ error: "Failed to read files directory" });
    }
  });
  app.delete("/api/files/:filename", (req, res) => {
    const filename = req.params.filename;
    const safeFilename = import_path.default.basename(filename);
    const targetPath1 = import_path.default.join(uploadsDir, safeFilename);
    const targetPath2 = import_path.default.join(_dirname, "public", "uploads", safeFilename);
    let deleted = false;
    if (import_fs.default.existsSync(targetPath1)) {
      try {
        import_fs.default.unlinkSync(targetPath1);
        deleted = true;
      } catch (e) {
      }
    }
    if (import_fs.default.existsSync(targetPath2)) {
      try {
        import_fs.default.unlinkSync(targetPath2);
        deleted = true;
      } catch (e) {
      }
    }
    if (deleted) {
      res.json({ success: true, message: "\u0641\u0627\u06CC\u0644 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u0634\u062F" });
    } else {
      res.status(404).json({ error: "\u0641\u0627\u06CC\u0644 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
    }
  });
  app.post("/api/files/cleanup", (req, res) => {
    try {
      const dirs = [uploadsDir, import_path.default.join(_dirname, "public", "uploads")];
      let deletedCount = 0;
      const now = Date.now();
      const maxAgeMs = 30 * 24 * 60 * 60 * 1e3;
      for (const dir of dirs) {
        if (import_fs.default.existsSync(dir)) {
          const files = import_fs.default.readdirSync(dir);
          for (const f of files) {
            if (f.startsWith("temp_") || f.includes("tmp_")) {
              const filePath = import_path.default.join(dir, f);
              try {
                const stat = import_fs.default.statSync(filePath);
                if (now - stat.mtimeMs > maxAgeMs) {
                  import_fs.default.unlinkSync(filePath);
                  deletedCount++;
                }
              } catch (e) {
              }
            }
          }
        }
      }
      res.json({ success: true, deletedCount, message: `\u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u0627\u0646\u062C\u0627\u0645 \u0634\u062F. ${deletedCount} \u0641\u0627\u06CC\u0644 \u0627\u0636\u0627\u0641\u06CC \u067E\u0627\u06A9 \u0634\u062F.` });
    } catch (err) {
      console.error("Error during file cleanup:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u0641\u0631\u0622\u06CC\u0646\u062F \u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u0641\u0627\u06CC\u0644\u200C\u0647\u0627" });
    }
  });
  app.post("/api/upload-base64", import_express3.default.json({ limit: "50mb" }), (req, res) => {
    try {
      const { image, filename } = req.body;
      if (!image || typeof image !== "string") {
        return res.status(400).json({ error: "No base64 image data provided" });
      }
      const matches = image.match(/^data:(image\/[a-zA-Z0-9\+\-\.]+);base64,(.+)$/);
      let buffer;
      let ext = ".webp";
      if (matches) {
        const mimeType = matches[1];
        if (mimeType.includes("jpeg") || mimeType.includes("jpg")) ext = ".jpg";
        else if (mimeType.includes("png")) ext = ".png";
        else if (mimeType.includes("gif")) ext = ".gif";
        else if (mimeType.includes("webp")) ext = ".webp";
        buffer = Buffer.from(matches[2], "base64");
      } else {
        buffer = Buffer.from(image, "base64");
      }
      const cleanName = filename ? String(filename).replace(/[^a-zA-Z0-9_\-]/g, "_") : "catalog_page";
      const uniqueName = `${cleanName}-${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`;
      const filePath = import_path.default.join(uploadsDir, uniqueName);
      import_fs.default.writeFileSync(filePath, buffer);
      const fileUrl = `/uploads/${uniqueName}`;
      res.json({ url: fileUrl, filename: uniqueName });
    } catch (err) {
      console.error("Error in upload-base64:", err);
      res.status(500).json({ error: err.message || "Failed to save base64 image on host" });
    }
  });
  const catalogsFilePath = import_path.default.join(uploadsDir, "custom_catalogs.json");
  function getHostCatalogsWithAutoDiscovery() {
    let catalogs = [];
    if (import_fs.default.existsSync(catalogsFilePath)) {
      try {
        const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) catalogs = parsed;
      } catch (_) {
      }
    }
    const rootCatalogsPath = import_path.default.join(process.cwd(), "catalogs.json");
    if (import_fs.default.existsSync(rootCatalogsPath)) {
      try {
        const content = import_fs.default.readFileSync(rootCatalogsPath, "utf-8");
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          const catMap = /* @__PURE__ */ new Map();
          catalogs.forEach((c) => {
            if (c && c.id) catMap.set(String(c.id), c);
          });
          parsed.forEach((c) => {
            if (c && c.id && !catMap.has(String(c.id))) catMap.set(String(c.id), c);
          });
          catalogs = Array.from(catMap.values());
        }
      } catch (_) {
      }
    }
    if (import_fs.default.existsSync(uploadsDir)) {
      try {
        const files = import_fs.default.readdirSync(uploadsDir);
        const imageFiles = [];
        const pdfFiles = [];
        files.forEach((file) => {
          if (file === "." || file === ".." || file.endsWith(".json")) return;
          const ext = import_path.default.extname(file).toLowerCase();
          if ([".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"].includes(ext)) {
            imageFiles.push(`uploads/${file}`);
          } else if (ext === ".pdf") {
            pdfFiles.push({
              id: `pdf_${file.replace(/[^a-zA-Z0-9_-]/g, "_")}`,
              title: import_path.default.basename(file, ext),
              description: "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0641\u0627\u06CC\u0644 PDF \u0645\u0648\u062C\u0648\u062F \u062F\u0631 \u067E\u0648\u0634\u0647 uploads",
              category: "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0635\u0646\u0639\u062A\u06CC",
              coverImage: `/uploads/${file}`,
              pdfUrl: `/uploads/${file}`,
              pageCount: 1,
              isPublished: true,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              pages: []
            });
          }
        });
        const referencedUrls = /* @__PURE__ */ new Set();
        catalogs.forEach((cat) => {
          if (cat.coverImage) referencedUrls.add(cat.coverImage.replace(/^\/+/, ""));
          if (cat.thumbnailUrl) referencedUrls.add(cat.thumbnailUrl.replace(/^\/+/, ""));
          if (Array.isArray(cat.pages)) {
            cat.pages.forEach((p) => {
              if (typeof p === "string") referencedUrls.add(p.replace(/^\/+/, ""));
              else if (p && p.imageUrl) referencedUrls.add(p.imageUrl.replace(/^\/+/, ""));
            });
          }
        });
        const unreferencedImages = imageFiles.filter((img) => !referencedUrls.has(img));
        if (unreferencedImages.length > 0) {
          const imageGroups = /* @__PURE__ */ new Map();
          unreferencedImages.forEach((imgPath) => {
            const filename = import_path.default.basename(imgPath, import_path.default.extname(imgPath));
            const cleanBase = filename.replace(/[-_]?(page|p)?[-_]?\d+$/i, "").replace(/[-_]+$/, "");
            const groupKey = cleanBase.length >= 3 ? cleanBase : filename;
            if (!imageGroups.has(groupKey)) {
              imageGroups.set(groupKey, []);
            }
            imageGroups.get(groupKey).push(imgPath);
          });
          imageGroups.forEach((groupImages, groupKey) => {
            groupImages.sort((a, b) => a.localeCompare(b, void 0, { numeric: true, sensitivity: "base" }));
            const formattedTitle = groupKey.replace(/[-_]+/g, " ").replace(/catalog/i, "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF").trim();
            const title = formattedTitle.startsWith("\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF") ? formattedTitle : `\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF ${formattedTitle}`;
            const catalogId = `auto_cat_${groupKey.replace(/[^a-zA-Z0-9_-]/g, "_")}`;
            const distinctCatalog = {
              id: catalogId,
              title,
              description: `\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0628\u0627 ${groupImages.length} \u0635\u0641\u062D\u0647 \u0645\u0648\u062C\u0648\u062F \u062F\u0631 \u067E\u0648\u0634\u0647 uploads`,
              category: "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0635\u0646\u0639\u062A\u06CC",
              coverImage: `/${groupImages[0]}`,
              thumbnailUrl: `/${groupImages[0]}`,
              pageCount: groupImages.length,
              isPublished: true,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              pages: groupImages.map((imgUrl, idx) => ({
                pageNumber: idx + 1,
                imageUrl: `/${imgUrl}`,
                thumbnailUrl: `/${imgUrl}`,
                title: `\u0635\u0641\u062D\u0647 ${idx + 1}`
              }))
            };
            const existingIdx = catalogs.findIndex((c) => String(c.id) === catalogId);
            if (existingIdx >= 0) {
              catalogs[existingIdx] = distinctCatalog;
            } else {
              catalogs.unshift(distinctCatalog);
            }
          });
        }
        pdfFiles.forEach((pdfCat) => {
          if (!catalogs.some((c) => String(c.id) === String(pdfCat.id))) {
            catalogs.push(pdfCat);
          }
        });
      } catch (e) {
        console.warn("Auto discovery in uploads dir error:", e);
      }
    }
    return catalogs;
  }
  app.get("/api/catalogs", (req, res) => {
    try {
      const list = getHostCatalogsWithAutoDiscovery();
      return res.json(list);
    } catch (err) {
      console.error("Failed reading host catalogs:", err);
      return res.status(500).json({ error: "Failed to read catalogs from host" });
    }
  });
  app.post("/api/catalogs", import_express3.default.json({ limit: "50mb" }), (req, res) => {
    try {
      const catalog = req.body;
      if (!catalog || !catalog.id) {
        return res.status(400).json({ error: "Invalid catalog data" });
      }
      let catalogs = [];
      if (import_fs.default.existsSync(catalogsFilePath)) {
        try {
          const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
          catalogs = JSON.parse(content);
        } catch (_) {
          catalogs = [];
        }
      }
      const existingIndex = catalogs.findIndex((c) => String(c.id) === String(catalog.id));
      if (existingIndex >= 0) {
        catalogs[existingIndex] = { ...catalogs[existingIndex], ...catalog };
      } else {
        catalogs.unshift(catalog);
      }
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      import_fs.default.writeFileSync(catalogsFilePath, JSON.stringify(catalogs, null, 2), "utf-8");
      return res.json({ success: true, catalog });
    } catch (err) {
      console.error("Failed saving catalog to host:", err);
      return res.status(500).json({ error: "Failed to save catalog to host: " + err.message });
    }
  });
  app.delete("/api/catalogs/:id", (req, res) => {
    try {
      const { id } = req.params;
      if (!id) return res.status(400).json({ error: "Missing catalog ID" });
      if (import_fs.default.existsSync(catalogsFilePath)) {
        const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
        let catalogs = JSON.parse(content);
        catalogs = catalogs.filter((c) => String(c.id) !== String(id));
        import_fs.default.writeFileSync(catalogsFilePath, JSON.stringify(catalogs, null, 2), "utf-8");
      }
      return res.json({ success: true, deletedId: id });
    } catch (err) {
      console.error("Failed deleting catalog from host:", err);
      return res.status(500).json({ error: "Failed to delete catalog from host: " + err.message });
    }
  });
  const saveBase64ToFileNode = (base64Str, prefix) => {
    if (!base64Str || typeof base64Str !== "string" || !base64Str.startsWith("data:image/")) {
      return base64Str;
    }
    const matches = base64Str.match(/^data:image\/([a-zA-Z0-9\+\-\.]+);base64,(.+)$/);
    if (!matches) {
      return base64Str;
    }
    const origExtension = matches[1].toLowerCase();
    const data = matches[2];
    const buffer = Buffer.from(data, "base64");
    let ext = "webp";
    if (origExtension.includes("jpeg") || origExtension.includes("jpg")) ext = "jpg";
    else if (origExtension.includes("png")) ext = "png";
    else if (origExtension.includes("gif")) ext = "gif";
    const filename = `${prefix}_${Date.now()}_${Math.round(Math.random() * 899 + 100)}.${ext}`;
    const filePath = import_path.default.join(uploadsDir, filename);
    try {
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      import_fs.default.writeFileSync(filePath, buffer);
      return `uploads/${filename}`;
    } catch (err) {
      console.error("Failed to write decoded base64 image file:", err);
      return base64Str;
    }
  };
  app.get("/save_catalog.php", (req, res) => {
    try {
      const list = getHostCatalogsWithAutoDiscovery();
      return res.json(list);
    } catch (err) {
      return res.json([]);
    }
  });
  app.post("/save_catalog.php", import_express3.default.json({ limit: "50mb" }), (req, res) => {
    try {
      const input = req.body;
      if (!input) {
        return res.status(400).json({ error: "Empty request payload" });
      }
      if (input.action === "upload_image" && input.image) {
        const url = saveBase64ToFileNode(input.image, "img");
        return res.json({ url });
      }
      const cat = input.catalog ? input.catalog : input;
      const catId = cat.id ? cat.id : "cat_" + Date.now();
      if (cat.coverImage) {
        cat.coverImage = saveBase64ToFileNode(cat.coverImage, `cover_${catId}`);
      }
      if (cat.thumbnailUrl) {
        cat.thumbnailUrl = saveBase64ToFileNode(cat.thumbnailUrl, `thumb_${catId}`);
      }
      if (cat.pages && Array.isArray(cat.pages)) {
        cat.pages.forEach((page, idx) => {
          if (page.imageUrl) {
            page.imageUrl = saveBase64ToFileNode(page.imageUrl, `p_${catId}_${idx + 1}`);
          }
          if (page.thumbnailUrl) {
            page.thumbnailUrl = saveBase64ToFileNode(page.thumbnailUrl, `pt_${catId}_${idx + 1}`);
          }
        });
      }
      let catalogs = [];
      if (import_fs.default.existsSync(catalogsFilePath)) {
        try {
          const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
          catalogs = JSON.parse(content);
        } catch (_) {
          catalogs = [];
        }
      }
      const existingIndex = catalogs.findIndex((c) => String(c.id) === String(catId));
      if (existingIndex >= 0) {
        catalogs[existingIndex] = { ...catalogs[existingIndex], ...cat };
      } else {
        catalogs.unshift(cat);
      }
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      import_fs.default.writeFileSync(catalogsFilePath, JSON.stringify(catalogs, null, 2), "utf-8");
      return res.json({ success: true, catalog: cat });
    } catch (err) {
      console.error("Failed saving catalog inside save_catalog.php Node handler:", err);
      return res.status(500).json({ error: "Failed to save catalog: " + err.message });
    }
  });
  app.delete("/save_catalog.php", (req, res) => {
    try {
      const id = req.query.id;
      if (id && import_fs.default.existsSync(catalogsFilePath)) {
        const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
        let catalogs = JSON.parse(content);
        catalogs = catalogs.filter((c) => String(c.id) !== String(id));
        import_fs.default.writeFileSync(catalogsFilePath, JSON.stringify(catalogs, null, 2), "utf-8");
      }
      return res.json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: "Failed to delete" });
    }
  });
  app.post("/api/catalogs/:id/analytics", import_express3.default.json(), (req, res) => {
    try {
      const { id } = req.params;
      const { action } = req.body;
      if (!import_fs.default.existsSync(catalogsFilePath)) return res.json({ success: true });
      const content = import_fs.default.readFileSync(catalogsFilePath, "utf-8");
      let catalogs = JSON.parse(content);
      const cat = catalogs.find((c) => String(c.id) === String(id));
      if (cat) {
        if (action === "view") cat.views = (cat.views || 0) + 1;
        if (action === "download") cat.downloads = (cat.downloads || 0) + 1;
        import_fs.default.writeFileSync(catalogsFilePath, JSON.stringify(catalogs, null, 2), "utf-8");
      }
      return res.json({ success: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });
  app.post("/api/catalogs/ai-assistant", import_express3.default.json({ limit: "50mb" }), async (req, res) => {
    try {
      const { catalogTitle, category, description, currentPageText, allPagesText, userPrompt } = req.body;
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        return res.json({
          reply: `\u062F\u0631 \u0645\u0648\u0631\u062F "${catalogTitle}" \u062F\u0631 \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC ${category}\u060C \u0645\u062C\u062A\u0645\u0639 \u0686\u0627\u067E \u0648 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0634\u06A9 \u0642\u0644\u0645 \u0628\u0631 \u0627\u0633\u0627\u0633 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0627\u0641\u0633\u062A \u0648 \u0633\u0627\u062E\u062A \u0647\u0627\u0631\u062F\u0628\u0627\u06A9\u0633 \u0627\u0645\u06A9\u0627\u0646 \u062A\u0648\u0644\u06CC\u062F \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0627\u06CC\u0646 \u0633\u0631\u0641\u0635\u0644 \u0631\u0627 \u062F\u0627\u0631\u062F.`
        });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const systemInstruction = `\u0634\u0645\u0627 \u062F\u0633\u062A\u06CC\u0627\u0631 \u062A\u062E\u0635\u0635\u06CC \u0648 \u0641\u0648\u0642\u200C\u0627\u0644\u0639\u0627\u062F\u0647 \u0628\u0627\u0647\u0648\u0634 \u0645\u062C\u062A\u0645\u0639 \u0686\u0627\u067E \u0648 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0634\u06A9 \u0642\u0644\u0645 \u0647\u0633\u062A\u06CC\u062F.
\u0639\u0646\u0648\u0627\u0646 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF: ${catalogTitle}
\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC: ${category}
\u062A\u0648\u0636\u06CC\u062D\u0627\u062A: ${description}
\u0645\u062A\u0646 \u0635\u0641\u062D\u0647 \u0641\u0639\u0644\u06CC: ${currentPageText}
\u06A9\u0644 \u0645\u062A\u0646 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF: ${allPagesText}

\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u067E\u0627\u0633\u062E \u062F\u0642\u06CC\u0642\u060C \u0645\u062D\u062A\u0631\u0645\u0627\u0646\u0647\u060C \u0641\u0646\u06CC \u0648 \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u0628\u0647 \u0633\u0648\u0627\u0644 \u06A9\u0627\u0631\u0628\u0631 \u0627\u0633\u062A. \u0627\u06AF\u0631 \u0633\u0648\u0627\u0644 \u062F\u0631\u0628\u0627\u0631\u0647 \u0642\u06CC\u0645\u062A \u0627\u0633\u062A\u060C \u0631\u0627\u0647\u0646\u0645\u0627\u06CC\u06CC \u06A9\u0646\u06CC\u062F \u06A9\u0647 \u0628\u0631 \u0627\u0633\u0627\u0633 \u062A\u06CC\u0631\u0627\u0698\u060C \u06AF\u0631\u0627\u0645\u0627\u0698 \u06A9\u0627\u063A\u0630 \u0648 \u0646\u0648\u0639 \u062F\u0627\u06CC\u06A9\u0627\u062A \u0642\u06CC\u0645\u062A \u0645\u062D\u0627\u0633\u0628\u0647 \u0645\u06CC\u200C\u0634\u0648\u062F \u0648 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0622\u0646\u0644\u0627\u06CC\u0646 \u0627\u0632 \u0648\u0627\u062D\u062F \u0641\u0631\u0648\u0634 \u0628\u062F\u0647\u06CC\u062F. \u067E\u0627\u0633\u062E \u062E\u0644\u0627\u0635\u0647 \u0648 \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC (\u062D\u062F\u0627\u06A9\u062B\u0631 \u06F3 \u067E\u0627\u0631\u0627\u06AF\u0631\u0627\u0641) \u0627\u0631\u0627\u0626\u0647 \u062F\u0647\u06CC\u062F.`;
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: userPrompt || "\u062E\u0644\u0627\u0635\u0647 \u0645\u0634\u062E\u0635\u0627\u062A \u0641\u0646\u06CC \u0627\u06CC\u0646 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0686\u06CC\u0633\u062A\u061F",
        config: {
          systemInstruction,
          temperature: 0.3
        }
      });
      return res.json({ reply: response.text || "\u067E\u0627\u0633\u062E \u0647\u0648\u0634\u0645\u0646\u062F \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0627\u0633\u062A." });
    } catch (err) {
      console.error("AI Catalog Assistant error:", err);
      return res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/cms/content-types", (req, res) => {
    res.json([
      { id: 1, name: "Article", slug: "article", schema: { fields: [] } },
      { id: 2, name: "Landing Page", slug: "landing_page", schema: { fields: [] } }
    ]);
  });
  app.get("/api/cms/entries/:contentType", (req, res) => {
    res.json([]);
  });
  app.post("/api/cms/entries/:contentType", (req, res) => {
    res.json({ success: true, status: "draft" });
  });
  app.post("/api/cms/ai/seo", async (req, res) => {
    res.json({ success: true, seoData: {} });
  });
  app.post("/api/cms/ai/factory", async (req, res) => {
    res.json({ success: true, status: "generated" });
  });
  function generateElegantMinimalSvgCover(title, category, isBack) {
    const primaryColor = "#F59E0B";
    const bgColor = "#0d1324";
    const strokeColor = "rgba(245, 158, 11, 0.25)";
    const rectGradId = `grad-${Date.now()}`;
    let subtitle = "\u0637\u0631\u0627\u062D\u06CC \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC";
    let promptCategoryDecor = category;
    if (category === "Packaging") {
      subtitle = "\u0635\u0646\u0627\u06CC\u0639 \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0647\u0627\u0631\u062F\u0628\u0627\u06A9\u0633 \u0648 \u0644\u0648\u06A9\u0633";
      promptCategoryDecor = "\u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u062E\u0644\u0627\u0642\u0627\u0646\u0647";
    } else if (category === "Branding") {
      subtitle = "\u0647\u0648\u06CC\u062A \u0628\u0635\u0631\u06CC \u0648 \u0633\u062A \u0627\u062F\u0627\u0631\u06CC \u0644\u0648\u06A9\u0633";
      promptCategoryDecor = "\u0628\u0631\u0646\u062F\u06CC\u0646\u06AF \u062A\u062E\u0635\u0635\u06CC";
    } else if (category === "Luxury") {
      subtitle = "\u062C\u0639\u0628\u0647 \u0648 \u0628\u0633\u062A\u0647\u200C\u0647\u0627\u06CC \u0627\u062F\u06A9\u0644\u0646 \u0648 \u0627\u0631\u0627\u06CC\u0634\u06CC \u0644\u0627\u06A9\u0686\u0631\u06CC";
      promptCategoryDecor = "\u0639\u0637\u0631 \u0648 \u0645\u0644\u0632\u0648\u0645\u0627\u062A \u0644\u0648\u06A9\u0633";
    } else if (category === "Industrial") {
      subtitle = "\u0644\u06CC\u0628\u0644\u200C\u0647\u0627\u06CC \u0645\u062A\u0627\u0644\u0627\u06CC\u0632 \u0648 \u0686\u0627\u067E \u0641\u0631\u0627\u062F\u0633\u062A\u06AF\u0627\u0647\u06CC";
      promptCategoryDecor = "\u0628\u062E\u0634 \u0635\u0646\u0639\u062A\u06CC \u062F\u0627\u06CC\u06A9\u0627\u062A";
    } else if (category === "Eco") {
      subtitle = "\u067E\u0627\u06A9\u062A\u200C\u0647\u0627\u06CC \u06AF\u0631\u0627\u0641\u06CC\u06A9\u06CC \u06A9\u0631\u0627\u0641\u062A \u0648 \u062D\u0627\u0645\u06CC \u0637\u0628\u06CC\u0639\u062A";
      promptCategoryDecor = "\u0633\u0628\u0632 \u0648 \u0645\u062D\u06CC\u0637 \u0632\u06CC\u0633\u062A";
    } else if (category === "Print") {
      subtitle = "\u0645\u0646\u0648 \u0648 \u0628\u0633\u062A\u0647\u200C\u0647\u0627\u06CC \u067E\u0630\u06CC\u0631\u0627\u06CC\u06CC \u0644\u0648\u06A9\u0633";
      promptCategoryDecor = "\u0635\u0646\u0627\u06CC\u0639 \u0686\u0627\u067E \u0646\u0641\u06CC\u0633";
    }
    if (isBack) {
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
        <rect width="600" height="800" fill="${bgColor}"/>
        <!-- Minimal Back Cover Graphics -->
        <circle cx="300" cy="400" r="180" fill="none" stroke="${strokeColor}" stroke-width="1.5" />
        <circle cx="300" cy="400" r="120" fill="none" stroke="${strokeColor}" stroke-width="0.5" stroke-dasharray="5,5" />
        <line x1="300" y1="180" x2="300" y2="620" stroke="${strokeColor}" stroke-width="0.75" />
        <line x1="120" y1="400" x2="480" y2="400" stroke="${strokeColor}" stroke-width="0.75" />
        
        <!-- Brand stamp -->
        <g transform="translate(300, 400)">
          <polygon points="0,-18 15,10 -15,10" fill="none" stroke="${primaryColor}" stroke-width="2" />
          <circle cx="0" cy="0" r="4" fill="${primaryColor}" />
        </g>
        
        <!-- Footer details -->
        <text x="300" y="700" fill="rgba(255,255,255,0.4)" font-family="system-ui, sans-serif" font-size="10" font-weight="bold" letter-spacing="4" text-anchor="middle">ASHK GHALAM INDUSTRIES</text>
        <text x="300" y="720" fill="rgba(255,255,255,0.25)" font-family="system-ui, sans-serif" font-size="9" text-anchor="middle">DESIGNED BY ASHK AI ENGINE</text>
        
        <!-- Barcode simulation -->
        <g transform="translate(250, 740)" opacity="0.3">
          <rect x="0" y="0" width="3" height="20" fill="white" />
          <rect x="5" y="0" width="1" height="20" fill="white" />
          <rect x="8" y="0" width="4" height="20" fill="white" />
          <rect x="15" y="0" width="2" height="20" fill="white" />
          <rect x="20" y="0" width="3" height="20" fill="white" />
          <rect x="25" y="0" width="1" height="20" fill="white" />
          <rect x="28" y="0" width="4" height="20" fill="white" />
          <rect x="35" y="0" width="2" height="20" fill="white" />
          <rect x="40" y="0" width="3" height="20" fill="white" />
          <rect x="45" y="0" width="1" height="20" fill="white" />
          <rect x="48" y="0" width="4" height="20" fill="white" />
          <rect x="55" y="0" width="2" height="20" fill="white" />
          <text x="50" y="28" fill="white" font-size="6" font-family="monospace" text-anchor="middle">06052026</text>
        </g>
      </svg>`;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
      <defs>
        <linearGradient id="${rectGradId}" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#0f172a" />
          <stop offset="100%" stop-color="#020617" />
        </linearGradient>
      </defs>
      
      <rect width="600" height="800" fill="url(#${rectGradId})"/>
      
      <!-- Sophisticated Abstract Art Background -->
      <g opacity="0.8">
        <!-- Spiral/Golden ratio curves -->
        <path d="M 100,550 A 200,200 0 0,1 300,350 A 150,150 0 0,1 450,450 A 100,100 0 0,1 350,550" fill="none" stroke="${strokeColor}" stroke-width="1" />
        <circle cx="300" cy="450" r="230" fill="none" stroke="${strokeColor}" stroke-width="0.5" />
        <circle cx="300" cy="450" r="160" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1.5" />
        <polygon points="300,120 480,450 120,450" fill="none" stroke="${strokeColor}" stroke-width="1" stroke-dasharray="10,5" />
        <circle cx="300" cy="120" r="6" fill="${primaryColor}" />
        <circle cx="480" cy="450" r="4" fill="${primaryColor}" />
        <circle cx="120" cy="450" r="4" fill="${primaryColor}" />
      </g>

      <!-- Content Title Overlays -->
      <rect x="60" y="580" width="480" height="150" rx="10" fill="rgba(15, 23, 42, 0.85)" stroke="rgba(255,255,255,0.08)" stroke-width="1" />
      
      <!-- Branding identity -->
      <text x="300" y="620" fill="${primaryColor}" font-family="'Vazirmatn', system-ui, sans-serif" font-weight="900" font-size="28" text-anchor="middle" direction="rtl">${title}</text>
      <text x="300" y="655" fill="white" font-family="'Vazirmatn', system-ui, sans-serif" font-weight="500" font-size="14" text-anchor="middle" opacity="0.9" direction="rtl">\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC: ${promptCategoryDecor}</text>
      <text x="300" y="685" fill="rgba(255, 255, 255, 0.5)" font-family="'Vazirmatn', system-ui, sans-serif" font-size="12" text-anchor="middle" direction="rtl">${subtitle}</text>
      
      <!-- Elegant border frame line -->
      <rect x="30" y="30" width="540" height="740" fill="none" stroke="${strokeColor}" stroke-width="2" />
      <rect x="38" y="38" width="524" height="724" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="0.5" />
      
      <!-- Small top credit label -->
      <text x="300" y="70" fill="rgba(255,255,255,0.5)" font-family="system-ui, sans-serif" font-weight="bold" font-size="8" letter-spacing="3" text-anchor="middle">ASHK GHALAM STUDIO \u2022 C_A_D</text>
    </svg>`;
  }
  app.post("/api/analyze-page", import_express3.default.json({ limit: "50mb" }), async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ error: "\u0647\u06CC\u0686 \u062A\u0635\u0648\u06CC\u0631\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        console.warn("GEMINI_API_KEY missing for analyze-page, sending intelligent visual catalog page analysis summary fallback.");
        return res.json({
          text: "\u0635\u0641\u062D\u0647 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0634\u06A9 \u0642\u0644\u0645: \u0634\u0627\u0645\u0644 \u062A\u0635\u0627\u0648\u06CC\u0631 \u0628\u0627\u06A9\u06CC\u0641\u06CC\u062A \u0633\u0627\u062E\u062A\u0627\u0631\u0647\u0627\u06CC \u06A9\u0627\u0631\u062A\u0646 \u0648 \u062C\u0639\u0628\u0647\u060C \u0645\u062A\u0648\u0646 \u062A\u0648\u0636\u06CC\u062D\u06CC \u0645\u0634\u062E\u0635\u0627\u062A \u0641\u0646\u06CC\u060C \u0645\u062A\u0631\u06CC\u0627\u0644 \u0645\u0642\u0648\u0627\u06CC \u0627\u06CC\u0646\u062F\u0631\u0628\u0631\u062F \u0648 \u06AF\u0644\u0627\u0633\u0647 \u0628\u0627 \u062C\u0644\u0648\u0647\u200C\u0647\u0627\u06CC \u0648\u06CC\u0698\u0647 \u0637\u0644\u0627\u06A9\u0648\u0628 \u0648 \u06CC\u0648\u0648\u06CC \u0645\u0648\u0636\u0639\u06CC."
        });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } }
      });
      const systemInstruction = `\u0634\u0645\u0627 \u06CC\u06A9 \u0645\u0648\u062A\u0648\u0631 \u062A\u062E\u0635\u0635\u06CC \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0628\u0631\u0627\u06CC \u0622\u0646\u0627\u0644\u06CC\u0632 \u0648 \u062A\u0648\u0635\u06CC\u0641 \u0645\u062D\u062A\u0648\u0627\u06CC \u062A\u0635\u0627\u0648\u06CC\u0631 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF\u200C\u0647\u0627\u06CC \u0635\u0646\u0639\u062A\u06CC \u0648 \u062A\u062C\u0627\u0631\u06CC \u0647\u0633\u062A\u06CC\u062F.
\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u0628\u0631\u0631\u0633\u06CC \u062F\u0642\u06CC\u0642 \u062A\u0635\u0648\u06CC\u0631 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F\u0647\u060C \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0645\u062D\u0635\u0648\u0644\u0627\u062A\u060C \u062E\u0648\u0627\u0646\u062F\u0646 \u062A\u06CC\u062A\u0631\u0647\u0627 \u0648 \u0645\u062A\u0648\u0646 \u0645\u0647\u0645 \u062F\u0627\u062E\u0644 \u062A\u0635\u0648\u06CC\u0631\u060C \u0648 \u0627\u0631\u0627\u0626\u0647 \u06CC\u06A9 \u062A\u0648\u0635\u06CC\u0641 \u06A9\u0648\u062A\u0627\u0647\u060C \u0632\u06CC\u0628\u0627\u060C \u062D\u0631\u0641\u0647\u200C\u0627\u06CC \u0648 \u06A9\u0627\u0645\u0644 \u0627\u0632 \u0635\u0641\u062D\u0647 \u0627\u0633\u062A. \u0627\u06CC\u0646 \u0645\u062A\u0646 \u062F\u0631 \u06A9\u0646\u0627\u0631 \u062A\u0635\u0648\u06CC\u0631 \u0628\u0647 \u06A9\u0627\u0631\u0628\u0631 \u0646\u0645\u0627\u06CC\u0634 \u062F\u0627\u062F\u0647 \u062E\u0648\u0627\u0647\u062F \u0634\u062F.
\u0645\u062A\u0646 \u062E\u0631\u0648\u062C\u06CC \u0628\u0627\u06CC\u062F \u062A\u0645\u06CC\u0632\u060C \u0628\u062F\u0648\u0646 \u0645\u0642\u062F\u0645\u0647 \u0648 \u0628\u0627 \u0646\u06AF\u0627\u0631\u0634 \u0635\u062D\u06CC\u062D \u0641\u0627\u0631\u0633\u06CC \u0628\u0627\u0634\u062F. \u062D\u062A\u0645\u0627\u064B \u0648\u06CC\u0698\u06AF\u06CC\u200C\u0647\u0627\u06CC \u06A9\u0644\u06CC\u062F\u06CC \u062A\u0635\u0648\u06CC\u0631 \u0631\u0627 \u0646\u0627\u0645 \u0628\u0628\u0631\u06CC\u062F.`;
      let mimeType = "image/jpeg";
      let base64Data = image;
      if (image.startsWith("data:")) {
        const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
        if (matches) {
          mimeType = matches[1];
          base64Data = matches[2];
        }
      }
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: {
          role: "user",
          parts: [
            { text: "\u0644\u0637\u0641\u0627\u064B \u0645\u062D\u062A\u0648\u0627\u06CC \u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0627\u0632 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0631\u0627 \u0628\u0647 \u0635\u0648\u0631\u062A \u06A9\u0627\u0645\u0644\u060C \u0628\u0627 \u062C\u0632\u0626\u06CC\u0627\u062A \u0648 \u0628\u0647 \u0634\u06A9\u0644 \u0645\u062A\u0646\u06CC \u062C\u0630\u0627\u0628 \u0648 \u062D\u0631\u0641\u0647\u200C\u0627\u06CC \u062A\u0648\u0635\u06CC\u0641 \u06A9\u0646\u06CC\u062F." },
            { inlineData: { mimeType, data: base64Data } }
          ]
        },
        config: {
          systemInstruction: { parts: [{ text: systemInstruction }] },
          temperature: 0.3
        }
      });
      res.json({ text: response.text || "\u0635\u0641\u062D\u0647 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0635\u0646\u0639\u062A\u06CC \u0628\u0627 \u0686\u06CC\u062F\u0645\u0627\u0646 \u06AF\u0631\u0627\u0641\u06CC\u06A9\u06CC \u0644\u0648\u06A9\u0633 \u0648 \u0645\u0634\u062E\u0635\u0627\u062A \u0641\u0646\u06CC." });
    } catch (err) {
      console.error("Analyze Page Error:", err);
      res.json({ text: "\u0635\u0641\u062D\u0647 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0628\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0648 \u0686\u0627\u067E \u0627\u0634\u06A9 \u0642\u0644\u0645: \u0634\u0627\u0645\u0644 \u0646\u0645\u0648\u0646\u0647 \u06A9\u0627\u0631\u0647\u0627\u06CC \u0635\u0646\u0639\u062A\u06CC\u060C \u062C\u0639\u0628\u0647 \u0647\u0627\u0631\u062F\u0628\u0627\u06A9\u0633 \u0648 \u0645\u062A\u0631\u06CC\u0627\u0644\u200C\u0647\u0627\u06CC \u0686\u0627\u067E \u0646\u0641\u06CC\u0633." });
    }
  });
  app.post("/api/analyze-catalog", import_express3.default.json({ limit: "50mb" }), async (req, res) => {
    try {
      const { images } = req.body;
      if (!images || !Array.isArray(images) || images.length === 0) {
        return res.status(400).json({ error: "\u0647\u06CC\u0686 \u062A\u0635\u0648\u06CC\u0631\u06CC \u0628\u0631\u0627\u06CC \u0622\u0646\u0627\u0644\u06CC\u0632 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        const fallbackTexts = images.map((_, i) => `\u0635\u0641\u062D\u0647 ${i + 1}: \u0622\u0646\u0627\u0644\u06CC\u0632 \u0633\u0627\u062E\u062A\u0627\u0631 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0635\u0646\u0639\u062A\u06CC\u060C \u0645\u062A\u0631\u06CC\u0627\u0644 \u06AF\u0644\u0627\u0633\u0647 \u0648 \u0637\u0644\u0627\u06A9\u0648\u0628 \u0628\u0627 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F\u0647\u0627\u06CC \u062F\u0627\u06CC\u06A9\u0627\u062A.`);
        return res.json({ texts: fallbackTexts });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const systemInstruction = `\u0634\u0645\u0627 \u06CC\u06A9 \u0645\u0648\u062A\u0648\u0631 \u0641\u0648\u0642 \u067E\u06CC\u0634\u0631\u0641\u062A\u0647 \u0648 \u0647\u0648\u0634\u0645\u0646\u062F \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0648 \u062A\u062D\u0644\u06CC\u0644 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0635\u0646\u0639\u062A\u06CC \u0647\u0633\u062A\u06CC\u062F.
\u0648\u0638\u06CC\u0641\u0647 \u0634\u0645\u0627 \u0628\u0631\u0631\u0633\u06CC \u062F\u0642\u06CC\u0642 \u062A\u0635\u0627\u0648\u06CC\u0631 \u0627\u0631\u0633\u0627\u0644\u06CC (\u0635\u0641\u062D\u0627\u062A \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF) \u0648 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0644\u06CC\u062F\u06CC \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0639\u0646\u0648\u0627\u0646 \u062F\u0642\u06CC\u0642 (title)\u060C \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0635\u0646\u0639\u062A\u06CC \u06CC\u0627 \u062A\u062C\u0627\u0631\u06CC (category)\u060C \u062A\u0648\u0636\u06CC\u062D \u062C\u0630\u0627\u0628 \u0648 \u062D\u0631\u0641\u0647\u200C\u0627\u06CC \u0627\u0632 \u0645\u062D\u062A\u0648\u0627\u06CC \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF (description) \u0648 \u0644\u06CC\u0633\u062A\u06CC \u0627\u0632 \u0648\u06CC\u0698\u06AF\u06CC\u200C\u0647\u0627\u06CC \u0628\u0631\u062C\u0633\u062A\u0647 \u06CC\u0627 \u0645\u062D\u0635\u0648\u0644\u0627\u062A \u06A9\u0644\u06CC\u062F\u06CC (highlights) \u0631\u0627 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06A9\u0646\u06CC\u062F.
\u067E\u0627\u0633\u062E \u0634\u0645\u0627 \u0628\u0627\u06CC\u062F \u0641\u0642\u0637 \u0648 \u0641\u0642\u0637 \u06CC\u06A9 \u0634\u06CC\u0621 JSON \u0628\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 \u0645\u0639\u062A\u0628\u0631 \u0632\u06CC\u0631 \u0628\u0627\u0634\u062F:
{
  "title": "\u0639\u0646\u0648\u0627\u0646 \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF",
  "category": "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC",
  "description": "\u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u062C\u0630\u0627\u0628 \u0648 \u062E\u0644\u0627\u0635\u0647",
  "highlights": ["\u0648\u06CC\u0698\u06AF\u06CC \u06F1", "\u0648\u06CC\u0698\u06AF\u06CC \u06F2"]
}`;
      const promptText = "\u0644\u0637\u0641\u0627\u064B \u0635\u0641\u062D\u0627\u062A \u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0636\u0645\u06CC\u0645\u0647 \u0634\u062F\u0647 \u0631\u0627 \u0628\u0631\u0631\u0633\u06CC \u06A9\u0631\u062F\u0647 \u0648 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u06CC \u0631\u0627 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06A9\u0646\u06CC\u062F.";
      const parts = [
        { text: promptText }
      ];
      for (let i = 0; i < Math.min(images.length, 3); i++) {
        const imgData = images[i];
        let mimeType = "image/jpeg";
        let base64Data = imgData;
        if (imgData.startsWith("data:")) {
          const matches = imgData.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
          if (matches) {
            mimeType = matches[1];
            base64Data = matches[2];
          }
        }
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data
          }
        });
      }
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: {
          role: "user",
          parts
        },
        config: {
          systemInstruction: {
            parts: [{ text: systemInstruction }]
          },
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });
      let responseText = response.text || "";
      let parsed = {};
      try {
        parsed = JSON.parse(responseText);
      } catch (e) {
        console.warn("Failed to parse JSON natively, trying markdown extraction");
        const jsonMatch = responseText.match(/```(?:json)?([sS]*?)```/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[1].trim());
        } else {
          parsed = JSON.parse(responseText.trim());
        }
      }
      res.json({ data: parsed });
    } catch (err) {
      console.error("Analyze Catalog Error:", err);
      res.status(500).json({ error: "\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC: " + err.message });
    }
  });
  app.post("/api/generate-cover", async (req, res) => {
    try {
      const { title, category, type } = req.body;
      const activeCategory = category || "Packaging";
      const activeTitle = title || "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u062C\u062F\u06CC\u062F";
      const promptText = `A premium, ultra-minimalist, editorial and modern graphic design for a catalog of "${activeCategory}" products. 
  Title of catalog: "${activeTitle}". 
  Type: ${type === "back" ? "back cover" : "front cover"}. 
  Visual style: clean geometric patterns, spacious negative space, gold/amber accents, professional print shop layout, high contrast, non-distracting artwork, no realistic human faces, elegant graphic abstraction. Ensure premium texture and luxury look suitable for high-end catalog branding. No text on back cover, only geometric minimal motif.`;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY implementation secret is missing on host environment container.");
      }
      console.log(`Starting server-side Cover Generative process with Gemini 2.5 Image engine for Category: ${activeCategory}`);
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-image",
        contents: {
          parts: [
            {
              text: promptText
            }
          ]
        },
        config: {
          imageConfig: {
            aspectRatio: "3:4"
          }
        }
      });
      let imageUrl = "";
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            break;
          }
        }
      }
      if (!imageUrl) {
        throw new Error("The image parts pipeline returned empty byte channels.");
      }
      console.log("Successfully generated AI cover image using Gemini model.");
      res.json({ success: true, url: imageUrl, isFallback: false });
    } catch (apiError) {
      const isQuota = apiError?.status === 429 || typeof apiError?.message === "string" && (apiError.message.includes("429") || apiError.message.includes("quota"));
      const briefReason = isQuota ? "\u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0627\u0632 \u0633\u06CC\u0633\u062A\u0645 \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646 \u06A9\u0627\u0648\u0631 \u0628\u0631\u062F\u0627\u0631\u06CC \u0648\u06A9\u062A\u0648\u0631 \u0628\u0647 \u062F\u0644\u06CC\u0644 \u0633\u0642\u0641 \u0633\u0647\u0645\u06CC\u0647" : apiError?.message ? String(apiError.message).slice(0, 120) : "\u0633\u06CC\u0633\u062A\u0645 \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646 \u0628\u0631\u062F\u0627\u0631\u06CC";
      console.log("Serving vector SVG cover for catalog. Reason:", briefReason);
      const { title, category, type } = req.body;
      const activeCategory = category || "Packaging";
      const activeTitle = title || "\u06A9\u0627\u062A\u0627\u0644\u0648\u06AF \u0628\u06CC \u0639\u0646\u0648\u0627\u0646";
      const svgCover = generateElegantMinimalSvgCover(activeTitle, activeCategory, type === "back");
      const base64Svg = Buffer.from(svgCover).toString("base64");
      const fallbackUrl = `data:image/svg+xml;base64,${base64Svg}`;
      res.json({
        success: true,
        url: fallbackUrl,
        isFallback: true,
        fallbackMessage: briefReason
      });
    }
  });
  app.use((err, req, res, next) => {
    console.error("API SERVER ERROR:", err);
    res.status(err.status || 500).json({
      error: err.message || "Internal Server Error",
      stack: process.env.NODE_ENV !== "production" ? err.stack : void 0
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    app.use(import_express3.default.static(import_path.default.join(_dirname, "dist"), {
      maxAge: "30d",
      setHeaders: (res, filePath) => {
        if (filePath.endsWith("index.html") || filePath.endsWith(".html")) {
          res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        } else {
          res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
        }
      }
    }));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(_dirname, "dist", "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
