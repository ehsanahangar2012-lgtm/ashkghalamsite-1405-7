import{c as d,r as i,j as x}from"./index-BIlWnnOM.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]],_=d("coins",M);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]],j=d("link",b);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],R=d("trending-up",E),I=({value:n,onChange:f,className:y="",placeholder:k="",min:s,max:o})=>{const[p,l]=i.useState(!1),[g,c]=i.useState(String(n??"")),a=i.useRef(!1),u=i.useRef(!1);i.useEffect(()=>{p||c(String(n??""))},[n,p]);const m=e=>e.replace(/[۰-۹]/g,t=>"۰۱۲۳۴۵۶۷۸۹".indexOf(t).toString()).replace(/[٠-٩]/g,t=>"٠١٢٣٤٥٦٧٨٩".indexOf(t).toString()).replace(/[٫/]/g,"."),N=e=>{l(!0),a.current=!0,u.current=!1;const t=e.currentTarget;t.select(),requestAnimationFrame(()=>{document.activeElement===t&&!u.current&&t.select()})},v=e=>{(a.current||!u.current)&&(e.preventDefault(),a.current=!1,e.currentTarget.select())},F=e=>{u.current=!0,a.current=!1;const t=m(e.target.value);if(!/^-?[\d]*\.?[\d]*$/.test(t)||(c(t),t===""||t==="-"||t==="."))return;const r=parseFloat(t);if(!isNaN(r)){if(s!==void 0&&r<s||o!==void 0&&r>o)return;f(r)}},h=()=>{const e=m(g),t=parseFloat(e);if(isNaN(t)||e===""||e==="-"||e==="."){c(String(n??""));return}let r=t;s!==void 0&&r<s&&(r=s),o!==void 0&&r>o&&(r=o),c(String(r)),f(r)},D=()=>{l(!1),a.current=!1,u.current=!1,h()},S=e=>{e.key==="Enter"?(e.preventDefault(),h(),l(!1),e.currentTarget.blur()):e.key==="Escape"&&(e.preventDefault(),c(String(n??"")),l(!1),e.currentTarget.blur())};return x.jsxDEV("input",{type:"text",inputMode:"decimal",value:g,onChange:F,onFocus:N,onMouseUp:v,onBlur:D,onKeyDown:S,placeholder:k,className:y},void 0,!1,{fileName:"/app/applet/src/components/NumericFormatInput.tsx",lineNumber:112,columnNumber:5},void 0)};export{_ as C,j as L,I as N,R as T};
